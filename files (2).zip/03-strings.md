*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 3 — Strings

## 3.1 Intuition

A Java `String` is **an immutable, read-only array of characters wearing a nice coat.**

Two words in that sentence do all the work: **array** and **immutable**.

**"Array"** means everything you learned in Module 2 applies. `charAt(i)` is O(1) address arithmetic. Scanning is O(n). There's a `length` known upfront.

**"Immutable"** means once created, the contents can **never** change. Not "shouldn't". *Cannot.* There is no method on `String` that modifies it. `toUpperCase()`, `trim()`, `replace()`, `substring()` — every one of them returns a **brand new String** and leaves the original untouched.

```java
String s = "hello";
s.toUpperCase();          // returns "HELLO" — and we THREW IT AWAY
System.out.println(s);    // "hello"  <- unchanged. Beginners find this shocking.

s = s.toUpperCase();      // now s REFERENCES the new object
System.out.println(s);    // "HELLO"
```

Notice what the second version actually does. It didn't change the string. It changed **which string `s` points at**. The old `"hello"` object still exists (in the string pool, in fact) — `s` just stopped looking at it.

```
   BEFORE  s = s.toUpperCase()

   s ---------> ["h","e","l","l","o"]      (immutable object A)

   DURING: toUpperCase() allocates a whole new object

   s ---------> ["h","e","l","l","o"]      (object A, untouched)
                ["H","E","L","L","O"]      (object B, freshly allocated)

   AFTER: the assignment repoints the reference

   s -----+     ["h","e","l","l","o"]      (object A — now maybe unreferenced)
          |
          +---> ["H","E","L","L","O"]      (object B)
```

**Why on earth would Java do this?** Four excellent reasons:

1. **Thread safety for free.** An immutable object can be shared across any number of threads with zero locking. Nothing can change, so nothing can race.
2. **Safe caching of the hash code.** `String.hashCode()` is computed once and stored in a field. This is why `HashMap<String, V>` is fast — the key's hash is already sitting there. A mutable key would invalidate its own hash bucket.
3. **Interning / the string pool.** Because contents can't change, identical literals can safely share one object (§3.3).
4. **Security.** If `String` were mutable, a malicious thread could change a filename or SQL query *after* it was validated but *before* it was used. That's a real attack class, eliminated by design.

**And the cost.** Every "modification" allocates. Which produces the single most common Java performance bug in the world:

```java
String s = "";
for (int i = 0; i < n; i++) s += "x";     // O(n²). See §1.5 Example H.
```

Understanding *why* that's O(n²) — and reflexively reaching for `StringBuilder` — is the practical payoff of this module.

## 3.2 Mental Model

**Model 1 — "String is a `final char[]` I can read but not write."**

(Since Java 9 it's actually a `byte[]` plus a coder flag — see §3.3 — but the mental model holds.)

**Model 2 — "Every String method that sounds like a mutation is actually a constructor."**

Rewrite them in your head:
- `s.trim()` → `new String(s without edge whitespace)`
- `s.replace('a','b')` → `new String(s with a→b)`
- `s.substring(2,5)` → `new String(s[2..5))`

Once you read them as allocations, you naturally start asking "am I allocating inside a loop?" — which is the right question.

**Model 3 — "For any building or repeated editing, leave `String` immediately."**

```
   Reading / comparing / passing around  ->  String
   Building character by character       ->  StringBuilder
   Building across threads               ->  StringBuffer (synchronized, rarely needed)
   Heavy char math / in-place algorithms ->  char[]  (via s.toCharArray())
```

Choosing correctly among those four is 90% of practical Java string competence.

## 3.3 Internal Working

### The modern String layout (Java 9+: Compact Strings)

Before Java 9, `String` held a `char[]`, and a Java `char` is **2 bytes** (UTF-16). So `"hello"` used 10 bytes of payload — even though every character fits in one byte. Studies at Oracle found most heap strings were pure Latin-1, meaning **half of all string memory in the average Java heap was zero bytes.**

Java 9 introduced **Compact Strings** (JEP 254):

```java
public final class String {
    private final byte[] value;   // <- byte[], not char[]
    private final byte coder;     // 0 = LATIN1 (1 byte/char), 1 = UTF16 (2 bytes/char)
    private int hash;             // cached; 0 means "not yet computed"
}
```

```
   "hello"  (all chars < 256)          "héllo₹"  (contains a non-Latin-1 char)
   coder = LATIN1                      coder = UTF16
   +---+---+---+---+---+               +---+---+ +---+---+ +---+---+ ...
   | h | e | l | l | o |               | 00| h | | 00| é | | 00| l |
   +---+---+---+---+---+               +---+---+ +---+---+ +---+---+
   5 bytes                             12 bytes (2 per char)
```

Real consequences:
- Typical Java applications saw **10–15% heap reduction** for free on upgrading to Java 9. This is one of the highest-impact JVM changes ever shipped.
- `charAt(i)` must branch on `coder`, but the JIT makes this essentially free.
- **`String.length()` returns the number of UTF-16 code units, not the number of visible characters.** An emoji like 😀 is a *surrogate pair* — 2 code units — so `"😀".length() == 2`. Use `s.codePointCount(0, s.length())` for actual character count. **Interviewers at companies with international products ask about this.**

### `hash` is lazily computed and cached

```java
public int hashCode() {
    int h = hash;
    if (h == 0 && !hashIsZero) {
        h = isLatin1() ? StringLatin1.hashCode(value) : StringUTF16.hashCode(value);
        hash = h;
    }
    return h;
}
```
The formula is `s[0]*31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]`. Computed **once**, then cached forever — legal only because the object is immutable. First `hashCode()` is O(n); every subsequent call is O(1). This is precisely why `String` is the ideal `HashMap` key.

(Why 31? It's an odd prime, `31 * x` compiles to the fast `(x << 5) - x`, and it empirically distributes English text well.)

### The String Pool — and the `==` trap

The JVM keeps a **string pool** (in the heap since Java 7) holding one canonical instance of each string *literal*.

```java
String a = "hello";                    // literal -> goes to the pool
String b = "hello";                    // literal -> finds the SAME pooled object
String c = new String("hello");        // 'new' FORCES a fresh heap object
String d = c.intern();                 // returns the pooled instance

a == b        // true   (same pooled object)
a == c        // FALSE  (different objects!)
a.equals(c)   // true   (same contents)
a == d        // true   (intern() returned the pooled one)
```

```
                  STRING POOL (in heap)
                 +----------------------+
   a ----------->|      "hello"         |<---------- b
                 +----------------------+<---------- d
                          ^
                          | intern()
                 REGULAR HEAP
                 +----------------------+
   c ----------->|      "hello"         |   separate object, same contents
                 +----------------------+
```

> **The rule, no exceptions: compare strings with `.equals()`, never with `==`.**

`==` compares references — *are these the same object?* `.equals()` compares contents — *do these say the same thing?* The reason `==` sometimes appears to work is the pool, and that's a trap: your code passes tests with literals and fails in production the moment a string arrives from a file, a socket, a database, or `Scanner`. **Never use `==` on strings.** Use `equals()`, or `Objects.equals(a, b)` when either may be null.

**Compile-time concatenation of literals is folded:**
```java
String x = "he" + "llo";     // compiler folds to the literal "hello" -> pooled
x == a                       // true

String part = "he";
String y = part + "llo";     // runtime concat -> new object
y == a                       // false
```
This distinction is a classic interview question, and the answer is "constant folding happens at compile time; runtime concatenation allocates."

### What `s += "x"` actually compiles to

```java
s += "x";
```
Java has no operator overloading, so the compiler rewrites this. On modern javac it becomes an invokedynamic call to `StringConcatFactory`, but semantically it is:

```java
s = new StringBuilder().append(s).append("x").toString();
```

Read that carefully and the O(n²) becomes obvious. Every iteration:
1. allocates a fresh `StringBuilder`,
2. copies **all `i` existing characters** into it,
3. appends one char,
4. calls `toString()`, which **copies everything again** into a new String,
5. abandons the builder and the old string as garbage.

```
   Iteration:   1    2    3    4    ...    n
   Chars copied: 1    2    3    4    ...    n
   Total = 1+2+3+...+n = n(n+1)/2 = O(n²)

   Objects allocated: 2 per iteration = 2n objects of average size n/2
   -> O(n²) bytes of garbage churned through the GC
```

For n = 100,000 that's ~5 billion character copies and gigabytes of garbage. It will take minutes. `StringBuilder` does the same job in milliseconds.

### `StringBuilder` — the mutable counterpart

```java
public final class StringBuilder extends AbstractStringBuilder {
    byte[] value;      // NOT final — this is the point
    int count;         // number of chars actually used
    byte coder;
}
```

It is exactly the dynamic array from Module 2, specialised for characters:

```
   capacity = 16 (default), count = 5

   +---+---+---+---+---+---+---+---+ ... +
   | h | e | l | l | o |   |   |   | ... |
   +---+---+---+---+---+---+---+---+ ... +
   <---- count ---->|<---- spare room ---->

   append('!') -> write at index 5, count -> 6.  O(1) amortized.
   When full   -> grow to (2 × old + 2), copy across. Amortized O(1) overall.
```

Note the growth rule: **`newCapacity = 2 * oldCapacity + 2`**. The `+2` guarantees growth from capacity 0. Multiplicative → geometric series → amortized O(1) (§1.4).

`toString()` copies the used region into a new immutable String — **one O(n) copy at the end**, instead of one per iteration.

```
   Building an n-character string:

   s += "x"  in a loop   ->  O(n²) time, O(n²) garbage
   sb.append in a loop   ->  O(n)  time, O(n)  memory
```

### `substring` — and a piece of history worth knowing

**Before Java 7u6**, `substring` was O(1): it created a String sharing the *same* backing array with an offset and count. Fast — but it caused a notorious memory leak:

```java
String huge = readFile();          // 100 MB string
String tiny = huge.substring(0, 5);
// huge is now unreachable, BUT tiny holds its 100 MB array alive!
```

**Since Java 7u6**, `substring` **copies**, making it **O(k)** where k is the substring length. Slower per call, but no leak and no surprise retention.

The interview-relevant consequence:

```java
// O(n²) — allocates and copies a new string on EVERY iteration
for (int i = 0; i < s.length(); i++) {
    process(s.substring(i, i + 3));
}

// O(n) — no allocation, just index arithmetic
for (int i = 0; i + 3 <= s.length(); i++) {
    process(s, i, i + 3);           // pass indices, not copies
}
```

> **Rule: `substring` inside a loop is a code smell. Pass indices instead.** State this in an interview when you avoid a substring and you'll get credit for it.

## 3.4 Java Implementation — core string utilities

Let's implement the operations that appear constantly, with real care.

```java
package com.dsa.strings;

public final class StringOps {

    private StringOps() { }   // utility class: prevent instantiation

    /** Reverses a string. O(n) time, O(n) space. */
    public static String reverse(String s) {
        if (s == null || s.length() <= 1) return s;
        char[] c = s.toCharArray();
        int lo = 0, hi = c.length - 1;
        while (lo < hi) {
            char tmp = c[lo];
            c[lo++] = c[hi];
            c[hi--] = tmp;
        }
        return new String(c);
    }

    /** Palindrome check ignoring non-alphanumerics and case. O(n) time, O(1) space. */
    public static boolean isPalindrome(String s) {
        if (s == null) return false;
        int lo = 0, hi = s.length() - 1;
        while (lo < hi) {
            while (lo < hi && !Character.isLetterOrDigit(s.charAt(lo)))  lo++;
            while (lo < hi && !Character.isLetterOrDigit(s.charAt(hi)))  hi--;
            if (Character.toLowerCase(s.charAt(lo)) != Character.toLowerCase(s.charAt(hi))) {
                return false;
            }
            lo++;
            hi--;
        }
        return true;
    }

    /** Anagram check for ASCII lowercase input. O(n) time, O(1) space. */
    public static boolean isAnagram(String a, String b) {
        if (a == null || b == null) return a == b;
        if (a.length() != b.length()) return false;          // cheap early exit

        int[] freq = new int[26];
        for (int i = 0; i < a.length(); i++) {
            freq[a.charAt(i) - 'a']++;
            freq[b.charAt(i) - 'a']--;                       // one pass, both strings
        }
        for (int f : freq) {
            if (f != 0) return false;
        }
        return true;
    }

    /** Frequency map for full Unicode-agnostic ASCII. O(n) time, O(1) space. */
    public static int[] asciiFrequency(String s) {
        int[] freq = new int[128];
        for (int i = 0; i < s.length(); i++) {
            freq[s.charAt(i)]++;
        }
        return freq;
    }

    /** Efficient repeat without O(n^2) concatenation. */
    public static String repeat(String unit, int times) {
        if (times <= 0 || unit == null || unit.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(unit.length() * times);   // pre-sized
        for (int i = 0; i < times; i++) {
            sb.append(unit);
        }
        return sb.toString();
    }
}
```

## 3.5 Line-by-Line Code Explanation

**`private StringOps() { }`**
A private constructor on a class of static methods. Prevents `new StringOps()`, which would be meaningless. Standard practice — see `java.util.Arrays` and `java.util.Collections`, both of which do exactly this.

**`char[] c = s.toCharArray();`**
Allocates an `n`-element `char[]` and copies. This is where the O(n) space in `reverse` comes from, and it's **unavoidable**: `String` is immutable, so we cannot reverse in place. If an interviewer says "reverse a string in O(1) space", the honest answer is "impossible for `String` in Java; possible for a `char[]`, which is what I'd ask for."

**`c[lo++] = c[hi];` then `c[hi--] = tmp;`**
Compressed but standard. `c[lo++] = c[hi]` means: write to index `lo`, *then* increment `lo`. Combining the swap with pointer movement is idiomatic; just be sure the read of `c[hi]` happens before `c[hi--]` writes to it — which it does, because the statements are sequenced.

**`return new String(c);`**
Copies the char array into a fresh immutable String. Yes, a second O(n) copy — one for `toCharArray`, one here. Both unavoidable given immutability. (Internally, `new String(char[])` also decides whether it can compact to LATIN1.)

**`while (lo < hi && !Character.isLetterOrDigit(s.charAt(lo))) lo++;`**
The inner skip loops in `isPalindrome`. Three things to notice:

1. **`lo < hi` must be re-checked inside the inner loop.** Consider the input `",,,"` — with no bound check, `lo` would march past `hi` and off the end. This is the classic crash in this problem.
2. `Character.isLetterOrDigit` is Unicode-aware, unlike a hand-rolled `c >= 'a' && c <= 'z'`. Use the library; it handles Devanagari, Cyrillic, and digits from every script.
3. **The outer `while` plus two inner `while`s is still O(n), not O(n²)** — because `lo` only ever increases and `hi` only ever decreases. Together they traverse the string **once**. Total pointer movement is bounded by n. Say this out loud in an interview: *"nested loops, but the pointers are monotonic, so it's O(n) total."*

**`if (a == null || b == null) return a == b;`**
A neat idiom: if either is null, they're "equal" only if both are null (`null == null` is true). Handles all four null combinations in one line.

**`if (a.length() != b.length()) return false;`**
An O(1) early exit before any O(n) work. Anagrams must be the same length. **Always look for a cheap disqualifying check first** — interviewers notice this instinct.

**`freq[a.charAt(i) - 'a']++;`**
The most important line in the module. `char` arithmetic: in Java, `char` is a numeric type (an unsigned 16-bit integer). `'a'` is 97. So:
```
   'a' - 'a' = 0
   'b' - 'a' = 1
   'z' - 'a' = 25
```
This maps 26 letters to array indices 0–25 in **O(1) with no HashMap**. It's the classic **frequency array** trick — a fixed-size table used as a perfect hash for a known small alphabet.

```
   "aabc"  ->  freq = [2, 1, 1, 0, 0, ... 0]
                       a  b  c  d  e
```

**`freq[b.charAt(i)]--;` in the same loop**
The elegant part. Instead of two arrays or two passes, **increment for `a` and decrement for `b` simultaneously.** If they're anagrams, every count cancels to exactly zero. One pass, one array. Explaining this cancellation is a strong interview moment.

**Caution:** `- 'a'` assumes lowercase a–z. If input can be uppercase, mixed, or Unicode, use `int[128]` (ASCII) or `HashMap<Character,Integer>` (full Unicode). **Always state your alphabet assumption out loud** — "I'm assuming lowercase English letters; if it's full Unicode I'd switch to a HashMap." That single sentence prevents a whole category of interview failure.

**`new StringBuilder(unit.length() * times)`**
Pre-sizing to the exact final capacity means **zero internal resizes** — no copying at all during the build. When you know the final size, always pass it. Free performance.

## 3.6 Complexity Analysis

| Operation | Time | Notes |
|---|---|---|
| `s.charAt(i)` | O(1) | Array indexing (plus a coder branch). |
| `s.length()` | O(1) | Stored field. |
| `s.equals(t)` | O(n) | Length check first, then char-by-char. Fast reject on length mismatch. |
| `s.hashCode()` | O(n) first call, **O(1)** after | Cached. Legal only due to immutability. |
| `s.substring(a,b)` | **O(b-a)** | **Copies** since Java 7u6. Not O(1). |
| `s.indexOf(t)` | O(n·m) worst | Naive scan in the JDK. Use KMP for guaranteed O(n+m). |
| `s + t` | O(n+m) | Allocates. In a loop → O(n²). |
| `sb.append(x)` | Amortized O(1) | Geometric growth. |
| `sb.toString()` | O(n) | One copy at the end. |
| `s.toCharArray()` | O(n) | Allocates. |
| `s.split(regex)` | O(n) to O(n²) | Compiles a regex each call unless the pattern is a single non-meta char. Pre-compile a `Pattern` in hot loops. |

**The two headline facts:** building with `+=` in a loop is O(n²); building with `StringBuilder` is O(n). And `substring` in a loop turns an O(n) algorithm into O(n²).

## 3.7 Common Mistakes

1. **`==` instead of `.equals()`** — §3.3. The most consequential Java bug of all time.
2. **`s.toUpperCase();` with no assignment** — does nothing observable. Immutability means you must capture the return value.
3. **`+=` in a loop** — O(n²).
4. **`substring` in a loop** — O(n²). Pass indices.
5. **`s.length` instead of `s.length()`** — arrays use the field, strings use the method.
6. **Assuming `length()` equals character count** — emoji and other supplementary characters are 2 code units.
7. **`s.charAt(i) - 'a'` on unsanitised input** — an uppercase `'A'` gives `-32` → `ArrayIndexOutOfBoundsException`.
8. **Forgetting `lo < hi` inside skip loops** — crashes on all-punctuation input.
9. **`s.split(",")` losing trailing empties** — `"a,b,,".split(",")` yields `["a","b"]`, dropping the trailing blanks. Use `split(",", -1)` to keep them. A real data-parsing bug.
10. **Using `String.format` in a hot loop** — it parses the format string every call. Fine for logging, terrible for tight loops.

## 3.8 Interview Perspective

Strings are the most common interview *medium*, because they let interviewers test array skills, hashing, two pointers, and sliding windows all at once — with inputs that are easy to say out loud.

**Four questions to ask before writing any string code.** Ask these aloud; each one earns credit:
1. **What's the alphabet?** Lowercase a–z? ASCII? Full Unicode? This decides `int[26]` vs `int[128]` vs `HashMap`.
2. **Case-sensitive?**
3. **Can it be null or empty?**
4. **Are non-alphanumerics relevant?** (Spaces, punctuation.)

**The string pattern checklist** — run this mentally on any string problem:
```
  Compare/reorganise chars?         -> frequency array int[26] or HashMap
  Two ends moving inward?           -> two pointers (palindrome, reverse)
  Contiguous substring + condition? -> sliding window
  Prefix matching, autocomplete?    -> Trie
  Pattern search?                   -> KMP / Rabin-Karp
  Group by "same letters"?          -> sorted string or freq-signature as HashMap key
  Building output?                  -> StringBuilder, always
```

**The single highest-value Java-specific signal you can give.** When you reach for `StringBuilder` instead of `+=`, *say why*: "I'll use StringBuilder here — string concatenation in a loop would be O(n²) because each `+=` copies the whole accumulated string." That sentence tells the interviewer you understand immutability, allocation, and amortized cost, all at once. It takes eight seconds and it materially changes their assessment.

## 3.9 Practice Problems

### Easy — Valid Anagram
Given two strings `s` and `t`, return true if `t` is an anagram of `s`. Assume lowercase English letters.
```
"anagram", "nagaram" -> true
"rat", "car"         -> false
```

### Medium — Longest Substring Without Repeating Characters
Given a string, find the length of the longest substring with no repeated characters.
```
"abcabcbb" -> 3   ("abc")
"bbbbb"    -> 1   ("b")
"pwwkew"   -> 3   ("wke")
```

### Hard — Minimum Window Substring
Given strings `s` and `t`, return the shortest substring of `s` containing **all characters of `t`, including duplicates**. Return `""` if none exists.
```
s = "ADOBECODEBANC", t = "ABC"  ->  "BANC"
s = "a", t = "aa"               ->  ""
```

## 3.10 Solution Walkthrough

### Easy — Valid Anagram

Already implemented as `isAnagram` in §3.4. Let's discuss the alternatives, because interviewers ask "can you do better?"

**Approach 1 — sort both, compare.**
```java
char[] a = s.toCharArray(), b = t.toCharArray();
Arrays.sort(a); Arrays.sort(b);
return Arrays.equals(a, b);
```
O(n log n) time, O(n) space. Correct, three lines, works for any alphabet. **Say this first**, then improve.

**Approach 2 — frequency array (the answer).** O(n) time, O(1) space (26 ints is constant regardless of n). This is optimal: you must read both strings, so Ω(n) is a hard floor.

**Approach 3 — HashMap** for arbitrary Unicode. O(n) time, O(k) space where k is the distinct character count.

**The interview arc to perform:** "Sorting works in O(n log n). But since the alphabet is fixed at 26 letters, I can count frequencies in O(n) with O(1) space, incrementing for `s` and decrementing for `t` in a single pass — anagrams cancel to all zeros." Then write it. That's a complete, senior-sounding answer in twenty seconds.

### Medium — Longest Substring Without Repeating Characters

**This is the canonical sliding window problem.** Learn the shape here and you'll recognise it forever.

**Brute force first (always state it):** check all O(n²) substrings, each O(n) to validate → O(n³). Or O(n²) with a rolling set. Too slow for n = 10⁵.

**The insight.** Consider `"abcabcbb"`. Suppose our window is `"abc"` (indices 0–2) and we try to extend to index 3, which is `'a'`.

We already have an `'a'` at index 0. Now the crucial question: **should we shrink the window one step at a time, or can we jump?**

Since the duplicate `'a'` sits at index 0, *any* window containing both index 0 and index 3 is invalid. So the new window must start at index 1 or later. We don't need to slide one at a time — **we can jump `left` directly past the previous occurrence.**

That's the optimisation that makes this O(n).

```java
public int lengthOfLongestSubstring(String s) {
    if (s == null || s.isEmpty()) return 0;

    int[] lastSeen = new int[128];          // ASCII; stores (index + 1), 0 = never seen
    int best = 0;
    int left = 0;                            // window is [left, right]

    for (int right = 0; right < s.length(); right++) {
        char c = s.charAt(right);
        if (lastSeen[c] > left) {            // duplicate INSIDE current window
            left = lastSeen[c];              // jump past it
        }
        lastSeen[c] = right + 1;             // store index+1 so 0 means "unseen"
        best = Math.max(best, right - left + 1);
    }
    return best;
}
```

**Dry run on `"abcabcbb"`.** Trace with your finger; the window is shown as `[...]`.

```
 idx:  0   1   2   3   4   5   6   7
 chr:  a   b   c   a   b   c   b   b

right=0, c='a': lastSeen['a']=0, not > left(0) -> no jump
                lastSeen['a'] = 1
                window [a]        len = 0-0+1 = 1   best = 1

right=1, c='b': lastSeen['b']=0, not > 0 -> no jump
                lastSeen['b'] = 2
                window [ab]       len = 1-0+1 = 2   best = 2

right=2, c='c': lastSeen['c']=0, not > 0 -> no jump
                lastSeen['c'] = 3
                window [abc]      len = 2-0+1 = 3   best = 3

right=3, c='a': lastSeen['a']=1, and 1 > left(0)  -> DUPLICATE in window!
                left = 1          <-- JUMPED past index 0 in ONE step
                lastSeen['a'] = 4
                window a[bca]     len = 3-1+1 = 3   best = 3

right=4, c='b': lastSeen['b']=2, and 2 > left(1)  -> duplicate
                left = 2
                lastSeen['b'] = 5
                window ab[cab]    len = 4-2+1 = 3   best = 3

right=5, c='c': lastSeen['c']=3, and 3 > left(2)  -> duplicate
                left = 3
                lastSeen['c'] = 6
                window abc[abc]   len = 5-3+1 = 3   best = 3

right=6, c='b': lastSeen['b']=5, and 5 > left(3)  -> duplicate
                left = 5
                lastSeen['b'] = 7
                window abcab[cb]  len = 6-5+1 = 2   best = 3

right=7, c='b': lastSeen['b']=7, and 7 > left(5)  -> duplicate
                left = 7
                lastSeen['b'] = 8
                window abcabcb[b] len = 7-7+1 = 1   best = 3

Answer: 3. Correct.
```

**The three details that matter:**

**1. Why store `index + 1` instead of `index`?** Because `int[]` is zero-initialised (Module 2), and 0 would be ambiguous — it could mean "character at index 0" or "never seen". Storing `index + 1` makes 0 unambiguously mean "unseen." This is a **sentinel-value** technique and it appears constantly. The alternative is `Arrays.fill(lastSeen, -1)`, which is equally valid and arguably clearer.

**2. Why `lastSeen[c] > left` and not `>= left`?** With the `index+1` encoding, `lastSeen[c] == left` means the previous occurrence was at index `left - 1`, which is **outside** the window `[left, right]`. Only `> left` means genuinely inside. Getting this comparison wrong produces windows that are too small — and the bug is subtle enough to pass small test cases. Draw the indices when you're unsure.

**3. Why is `left` never decreased?** Because `left = lastSeen[c]` only fires when `lastSeen[c] > left`, i.e. the new value is strictly larger. `left` is **monotonically non-decreasing**. That's what makes this O(n) rather than O(n²) — each pointer traverses the string at most once.

**Complexity:** **O(n) time** — `right` advances n times, `left` never retreats, so total pointer movement is ≤ 2n. **O(1) space** — a fixed 128-int array, constant regardless of input size.

**The sliding-window template you should memorise:**
```
for (right = 0 .. n-1):
    expand window to include s[right]
    while (window is invalid):
        shrink from left            // or: JUMP left, when you can compute the target
    update answer with current window
```
That skeleton solves dozens of problems. We'll formalise it in Module 22.

### Hard — Minimum Window Substring

Same window skeleton, but now the logic inverts: we **expand until valid, then shrink while still valid.** In the previous problem we shrank to *restore* validity; here we shrink to *minimise* an already-valid window. Recognising which of those two modes a problem is in is the real skill.

```java
public String minWindow(String s, String t) {
    if (s == null || t == null || s.length() < t.length() || t.isEmpty()) return "";

    int[] need = new int[128];
    for (int i = 0; i < t.length(); i++) {
        need[t.charAt(i)]++;
    }

    int required = t.length();      // total chars still needed (counts duplicates)
    int left = 0;
    int bestLen = Integer.MAX_VALUE;
    int bestStart = 0;

    for (int right = 0; right < s.length(); right++) {
        char c = s.charAt(right);
        if (need[c] > 0) {          // this char was genuinely needed
            required--;
        }
        need[c]--;                  // may go negative = surplus of this char

        while (required == 0) {     // window is VALID -> try to shrink it
            if (right - left + 1 < bestLen) {
                bestLen = right - left + 1;
                bestStart = left;
            }
            char lc = s.charAt(left);
            need[lc]++;
            if (need[lc] > 0) {     // we just gave up a NEEDED char
                required++;         // window becomes invalid; inner loop exits
            }
            left++;
        }
    }
    return bestLen == Integer.MAX_VALUE ? "" : s.substring(bestStart, bestStart + bestLen);
}
```

**The idea that makes this work: `need[]` is allowed to go negative.**

```
   t = "ABC", so need = { A:1, B:1, C:1 }

   need[c] >  0  ->  we still need more of c
   need[c] == 0  ->  we have exactly enough c
   need[c] <  0  ->  we have SURPLUS c (extra copies we could drop)
```

The magic of `if (need[c] > 0) required--;` **before** the decrement: we only credit progress when the character was actually wanted. A surplus `'A'` drives `need['A']` from 0 to −1 without touching `required`. That single guard is what makes duplicate handling correct — and it's what candidates get wrong.

Symmetrically, `need[lc]++` then `if (need[lc] > 0) required++;` on removal: pushing a count from −1 back to 0 is harmless (we only dropped a surplus), but pushing from 0 to 1 means we lost something essential.

**Dry run on `s = "ADOBECODEBANC", t = "ABC"`.** Abbreviated to the decisive moments.

```
 idx:  0  1  2  3  4  5  6  7  8  9 10 11 12
 chr:  A  D  O  B  E  C  O  D  E  B  A  N  C

Initial: need = {A:1, B:1, C:1}, required = 3, left = 0

right=0 'A': need[A]=1>0 -> required=2.  need[A]=0
right=1 'D': need[D]=0, not >0 -> required stays 2.  need[D]=-1
right=2 'O': need[O]=-1, required=2
right=3 'B': need[B]=1>0 -> required=1.  need[B]=0
right=4 'E': need[E]=-1, required=1
right=5 'C': need[C]=1>0 -> required=0.  need[C]=0
             *** WINDOW VALID: s[0..5] = "ADOBEC", len 6 ***
             best = "ADOBEC" (len 6, start 0)

             Try shrinking. left=0, char 'A'.
             need[A]: 0 -> 1.  1 > 0 -> we lost a needed char. required=1. left=1.
             Inner loop exits (required != 0).

             Window now A[DOBEC], missing an A.

right=6..9: 'O','D','E' add nothing needed.
right=9 'B': need[B] is 0 -> not >0 -> required stays 1. need[B]=-1  (surplus B!)
right=10 'A': need[A]=1>0 -> required=0.  need[A]=0
             *** VALID: s[1..10] = "DOBECODEBA", len 10 ***
             10 > 6, so best stays "ADOBEC".

             Shrink aggressively:
               left=1 'D': need[D] -1->0, not >0 -> harmless surplus dropped. left=2
               left=2 'O': need[O] -1->0, harmless. left=3
               left=3 'B': need[B] -1->0, harmless (we still have the B at index 9!). left=4
               left=4 'E': need[E] -1->0, harmless. left=5
               left=5 'C': need[C]  0->1, 1>0 -> LOST a needed char. required=1. left=6
             Window now ADOBE[CODEBA] -> after left=6: ADOBEC[ODEBA], missing C.
             During shrinking we recorded len 10, 9, 8, 7, 6 -> the len-6 window
             s[5..10]="CODEBA" ties best; we keep the earlier one (strict <).

right=11 'N': nothing needed. need[N]=-1
right=12 'C': need[C]=1>0 -> required=0. need[C]=0
             *** VALID: s[6..12] = "ODEBANC", len 7 ***  (7 > 6, best unchanged)

             Shrink:
               left=6 'O': harmless. left=7
               left=7 'D': harmless. left=8
               left=8 'E': harmless. left=9
               left=9 'B': need[B] 0->1 -> LOST. required=1. left=10
             During shrinking, at left=9 the window was s[9..12] = "BANC", len 4.
             4 < 6  ->  *** NEW BEST: "BANC" ***

Loop ends. Answer: "BANC". Correct.
```

Notice how the shrink phase did the real work: it recorded lengths 7, 6, 5, **4** as it walked `left` forward, and 4 was the winner. **The answer was found by shrinking, not by expanding.** That's the essential character of this problem type.

**Complexity:** `right` advances n times; `left` advances at most n times in total across all inner-loop executions. Every character is added once and removed at most once → **O(n) time**. (The nested `while` does *not* make it O(n²), for exactly the monotonic-pointer reason from §3.5. Be ready to defend this — it's the follow-up question.) **O(1) space** for the fixed 128-int table, plus O(k) for the returned substring.

**The one-line generalisation to carry forward:**

> **"Longest valid window" → shrink only when invalid. "Shortest valid window" → shrink while still valid.**
>
> Same loop skeleton, inverted shrink condition. Recognise which mode you're in and the code writes itself.

---
---
