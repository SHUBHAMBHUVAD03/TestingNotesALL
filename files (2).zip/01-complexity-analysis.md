*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 1 — Complexity Analysis

## 1.1 Intuition

Forget formulas. Start with a story.

You have a phone book with 1,000,000 names in it, sorted alphabetically. I ask you to find "Ramesh".

**Strategy A:** Start at page 1, name 1. Read every name until you hit Ramesh.
**Strategy B:** Open the middle. Is Ramesh before or after? Throw away half. Open the middle of what's left. Repeat.

Strategy A might read 1,000,000 names. Strategy B reads about 20.

Now here's the part everyone misses. The interesting question is **not** "how many names did you read?" The interesting question is **"what happens when the phone book doubles in size?"**

```
Phone book size    Strategy A reads    Strategy B reads
-----------------  ------------------  ------------------
     1,000,000            1,000,000                  20
     2,000,000            2,000,000                  21
     4,000,000            4,000,000                  22
 1,000,000,000        1,000,000,000                  30
```

Look at those columns. Strategy A's work **doubles when the input doubles**. Strategy B's work **increases by one when the input doubles**.

That relationship — *how does the work grow as the input grows* — is the entire subject of complexity analysis. That's it. That's the whole idea.

> **Complexity analysis is not about measuring speed. It is about measuring the *shape of growth*.**

This is why we don't measure in seconds. Seconds depend on your CPU, on whether Chrome is open, on the JIT compiler's mood. But the *shape* — "doubling the input doubles the work" — is a permanent mathematical property of the algorithm. It's true on your laptop, on a supercomputer, and on a machine built in 2090.

## 1.2 Mental Model

Here is the model I want burned into your head. **Count the operations that grow with the input, ignore everything else.**

Three concrete habits:

**Habit 1 — Ask "how many times does the innermost line run?"**

```java
for (int i = 0; i < n; i++) {        // outer
    for (int j = 0; j < n; j++) {    // inner
        sum += arr[i][j];            // <-- THIS LINE. How many times?
    }
}
```
The inner line runs `n` times for each of `n` outer iterations, so `n × n = n²` times. That's your answer: **O(n²)**. You didn't need math. You needed to ask which line is hottest.

**Habit 2 — Throw away constants and small terms.**

If you count exactly `3n² + 50n + 700` operations, the answer is **O(n²)**.

Why is that legitimate? Because for large `n`, `n²` bullies everything else:

```
n = 10       3n² = 300        50n = 500      700 = 700     <- 700 dominates!
n = 100      3n² = 30,000     50n = 5,000    700 = 700     <- n² takes over
n = 1,000    3n² = 3,000,000  50n = 50,000   700 = 700     <- n² is 98% of the work
n = 10,000   3n² = 300 MILLION           ...              <- n² is everything
```

The `50n` and `700` become rounding errors. And the `3`? A constant multiplier doesn't change the *shape* of growth — doubling `n` still quadruples `3n²`, exactly as it quadruples `n²`. We care about shape, so the 3 goes.

**Habit 3 — Know the ladder by heart.**

```
        FAST                                                     SLOW
         |                                                         |
    O(1) < O(log n) < O(n) < O(n log n) < O(n²) < O(n³) < O(2^n) < O(n!)
```

Feel these with real numbers. Assume 10⁸ simple operations per second (a realistic figure for Java):

```
n           O(log n)   O(n)      O(n log n)   O(n²)          O(2^n)
----------  ---------  --------  -----------  -------------  --------------------
10          3          10        33           100            1,024
100         7          100       664          10,000         10^30  (heat death)
1,000       10         1,000     9,966        1,000,000      forget it
1,000,000   20         10^6      2 × 10^7     10^12          forget it
                                              ~2.8 hours
```

**The single most useful line in this table:** at `n = 1,000,000`, an O(n log n) algorithm finishes in about 0.2 seconds and an O(n²) algorithm takes about 2.8 hours. Same problem. Same computer. That gap is why this module exists.

## 1.3 Internal Working — the four notations

Students confuse O, Ω, and Θ endlessly. Here's the fix: **they are not about best/average/worst case.** That is the classic misconception. They are about **bounds on a function**.

Think of it as describing someone's height:

- **Big O** = "he is *at most* 6 feet tall" — an **upper** bound (a ceiling).
- **Big Ω (Omega)** = "he is *at least* 5 feet tall" — a **lower** bound (a floor).
- **Big Θ (Theta)** = "he is *exactly* 5'10", give or take an inch" — a **tight** bound (both at once).

```
   work
    ^
    |                                      . c2·g(n)     <-- Big O ceiling
    |                                  .
    |                              .
    |                          .  ___---  f(n)  actual algorithm
    |                      . ___---
    |                  ._--
    |              .--          ______ c1·g(n)  <-- Big Ω floor
    |          .--      ______--
    |      .--   ______--
    |  .--_____--
    +------------------------------------------> n
             ^
             n0 (bounds only need to hold beyond here)
```

Formally, for `n` beyond some threshold `n₀`:

- `f(n) = O(g(n))` if `f(n) ≤ c · g(n)` for some constant `c > 0`
- `f(n) = Ω(g(n))` if `f(n) ≥ c · g(n)` for some constant `c > 0`
- `f(n) = Θ(g(n))` if both hold — the function is sandwiched

Now, the sentence that makes this click:

> **You can talk about the Big O of the best case, and the Big Ω of the worst case.** The notation and the case are independent axes.

Example — linear search for a target in an unsorted array of `n` elements:

```
Best case:    target is at index 0        -> 1 comparison     -> Θ(1)
Worst case:   target absent               -> n comparisons    -> Θ(n)
Average case: uniformly random position   -> n/2 comparisons  -> Θ(n)
```

The *worst case* of linear search is `Θ(n)`. It is also `O(n)`, and also `O(n²)` (a ceiling of n² is technically true — just useless, like saying a person is at most 900 feet tall). And it is `Ω(n)`.

**Why does industry say "O" for everything?** Because we mostly care about worst-case guarantees, and `O` is the notation for "no worse than." It's slightly sloppy — when we say "quicksort is O(n log n)" we usually mean "Θ(n log n) on average" — but everybody understands it. In an interview, say O, but if the interviewer probes, show that you know the difference. That single distinction separates candidates who memorised from candidates who understand.

### 1.4 Amortized Analysis — the one that gets people the job

This is subtle, important, and heavily tested. Let's build it properly.

Java's `ArrayList` is backed by a plain array. Arrays are fixed-size. So what happens when you `add()` to a full ArrayList?

```
Step 1: ArrayList is full, capacity 4
    +---+---+---+---+
    | A | B | C | D |   size = 4, capacity = 4
    +---+---+---+---+

Step 2: add("E") -> no room. Allocate a NEW array, 1.5x bigger (capacity 6)
    +---+---+---+---+---+---+
    |   |   |   |   |   |   |   new array, empty
    +---+---+---+---+---+---+

Step 3: COPY all 4 old elements across  <-- this costs 4 operations!
    +---+---+---+---+---+---+
    | A | B | C | D |   |   |
    +---+---+---+---+---+---+

Step 4: NOW write E
    +---+---+---+---+---+---+
    | A | B | C | D | E |   |   size = 5, capacity = 6
    +---+---+---+---+---+---+

Step 5: old array becomes garbage -> eligible for GC
```

So one `add()` cost 5 operations, not 1. That's O(n) for that call. Does that mean `ArrayList.add()` is O(n)?

**No.** And here's the reasoning that matters.

Let's use doubling (simpler arithmetic; the logic is identical for 1.5×). Track the cost of each of 17 `add` calls starting from capacity 1:

```
add #   capacity before   resize?   copies   total cost
-----   ---------------   -------   ------   ----------
  1            1            no        0          1
  2            1           YES ->2    1          2
  3            2           YES ->4    2          3
  4            4            no        0          1
  5            4           YES ->8    4          5
  6            8            no        0          1
  7            8            no        0          1
  8            8            no        0          1
  9            8           YES ->16   8          9
 10..16       16            no        0          1  (x7)
 17           16           YES ->32  16         17
```

The expensive calls are rare, and they get **exponentially rarer** as they get more expensive. Total copy work for `n` inserts:

```
1 + 2 + 4 + 8 + 16 + ... + n/2 + n  <  2n
```

That's a geometric series. Its sum is less than `2n`. So `n` inserts cost less than `n + 2n = 3n` operations total.

```
Average cost per insert = 3n / n = 3 = O(1)
```

**That is amortized O(1).** The definition:

> **Amortized complexity** = total cost of a sequence of operations, divided by the number of operations. It is a *guaranteed average over the sequence*, not a probabilistic average.

Visualise the cost of each individual insert:

```
cost
 |
16-|                                                 X          <- rare, expensive
 8-|                       X
 4-|           X
 2-|     X
 1-| X X   X X   X X X X X   X X X X X X X X X X X X X X X X X  <- common, cheap
   +---------------------------------------------------------> insert #
     The spikes are so rare that the AREA under this whole
     graph is still only about 3n. Flat on average.
```

**The distinction that wins interviews.** If an interviewer asks "what's the difference between average-case and amortized?", say this:

- **Average case** is probabilistic. It assumes a distribution over inputs. An adversary who knows your algorithm can feed you bad input every single time and you'll never get the average. (Quicksort's O(n log n) is average-case: an adversary can force O(n²).)
- **Amortized** is a worst-case guarantee about a *sequence*. There is no probability involved and no adversary can break it. If you do `n` ArrayList inserts, you *will* pay less than 3n — guaranteed, always.

Amortized is a much stronger promise than average case. Say that sentence in an interview and watch the interviewer's face change.

**Why 1.5× and not +1?** Because growing by a constant amount destroys the geometric series:

```
Growth by +1 each time:  copies = 1+2+3+...+n = n(n+1)/2 = O(n²) total
                         -> amortized O(n) per insert. Terrible.

Growth by x1.5 or x2:    copies = geometric series < 2n or < 3n total
                         -> amortized O(1) per insert. Excellent.
```

Multiplicative growth is what buys the O(1). This is a real engineering insight, not trivia.

## 1.5 Reading complexity off real code — a drill

Let's do these fast. Cover the answers with your hand.

**Example A**
```java
int sum = 0;
for (int i = 0; i < n; i++) {
    sum += i;
}
```
`n` iterations, O(1) work each → **O(n)** time, **O(1)** space.

**Example B**
```java
for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
        System.out.println(i + "," + j);
    }
}
```
→ **O(n²)**. Nested independent loops multiply.

**Example C — the trap**
```java
for (int i = 0; i < n; i++) {
    for (int j = i; j < n; j++) {   // note: j starts at i, not 0
        doWork();
    }
}
```
Count honestly:
```
i=0   -> j runs n times
i=1   -> j runs n-1 times
i=2   -> j runs n-2 times
...
i=n-1 -> j runs 1 time

Total = n + (n-1) + (n-2) + ... + 1 = n(n+1)/2 = n²/2 + n/2
```
Drop constants → **O(n²)**. Yes, it does half the work of Example B. Half of n² is still n². **Constant factors do not change the class.** Beginners answer "O(n²/2)" — that's not a thing. Write O(n²).

**Example D — the other trap**
```java
for (int i = 1; i < n; i = i * 2) {
    doWork();
}
```
`i` takes values 1, 2, 4, 8, 16, ... How many steps until `i ≥ n`? We need `2^k ≥ n`, so `k = log₂ n`. → **O(log n)**.

> **Rule of thumb: whenever a variable is multiplied or divided each step instead of incremented, a logarithm appears.** Halving → log n. Doubling → log n. This is the fingerprint of a logarithm; learn to spot it instantly.

**Example E — sequential, not nested**
```java
for (int i = 0; i < n; i++) { a(); }     // O(n)
for (int i = 0; i < n; i++) { b(); }     // O(n)
```
→ O(n) + O(n) = O(2n) = **O(n)**. Sequential loops **add**; nested loops **multiply**. Addition of same-class terms collapses.

**Example F — two different inputs**
```java
for (int i = 0; i < n; i++)
    for (int j = 0; j < m; j++)
        doWork();
```
→ **O(n·m)**. Do *not* write O(n²). If `n` and `m` are independent, keep both letters. Interviewers notice this.

**Example G — the classic mistake**
```java
List<Integer> list = new ArrayList<>();
for (int i = 0; i < n; i++) {
    if (list.contains(i)) { ... }        // <-- contains() is O(n) itself!
}
```
The loop is O(n), but the body is O(n), not O(1). → **O(n²)**. This bug appears in real production code constantly. Swapping `ArrayList` for `HashSet` makes `contains` O(1) and the whole thing O(n). **Always know the complexity of the library methods you call.**

**Example H — string concatenation in a loop**
```java
String s = "";
for (int i = 0; i < n; i++) {
    s += "x";              // creates a NEW String every time
}
```
Java `String` is immutable. Iteration `i` copies `i` characters into a fresh object. Total = 1+2+...+n = **O(n²)** time and O(n²) total allocation churn. Use `StringBuilder` → O(n). We'll cover this in Module 3; it is one of the most common Java performance bugs in existence.

## 1.6 Space Complexity — and the part everyone forgets

Space complexity = **extra** memory used, as a function of input size. The input itself is usually not counted (it's called *auxiliary space*).

```java
// O(1) auxiliary space - a fixed number of variables regardless of n
int max(int[] arr) {
    int best = arr[0];        // 1 int
    for (int x : arr)         // 1 more int
        if (x > best) best = x;
    return best;
}
```

```java
// O(n) auxiliary space - allocation scales with input
int[] doubled(int[] arr) {
    int[] out = new int[arr.length];   // n ints on the heap
    ...
}
```

**The forgotten one: the call stack counts as space.**

```java
int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n - 1);
}
```

This allocates no arrays, no objects. Students confidently say O(1) space. **Wrong.** There are `n` nested stack frames alive simultaneously:

```
  |  factorial(1)  |  <- top of stack
  |  factorial(2)  |
  |  factorial(3)  |
  |     ...        |   n frames, each holding a copy of n and a return address
  |  factorial(n)  |
  +----------------+
```

→ **O(n) space.** And when `n` is large enough, those frames exhaust the JVM's thread stack and you get `StackOverflowError`. On a default JVM that's roughly 10,000–20,000 frames deep. This is exactly why recursion depth matters and why we care about tail-call-shaped rewrites and iterative conversions (Module 4).

## 1.7 Common Mistakes

1. **"O(2n) is faster than O(n²)"** — mixing up notation with measurement. O(2n) *is* O(n). Simplify before comparing.
2. **Writing O(n²/2) or O(3n)** — these aren't valid answers. Drop constants. Always.
3. **Confusing worst case with Big O** — they're different axes. See §1.3.
4. **Forgetting the call stack in space analysis** — see §1.6.
5. **Ignoring the cost of library calls** — `list.contains`, `String.substring`, `map.containsKey` all have complexities. Know them.
6. **Assuming `log` means log₁₀** — in DSA, `log n` means log₂ n unless stated. (It doesn't actually matter for Big O, since log bases differ by a constant factor, but say "log base 2" out loud so the interviewer knows you know.)
7. **Analysing the code you *meant* to write** — analyse the code on the screen, line by line, counting the innermost line.

## 1.8 Interview Perspective

**What interviewers are actually testing.** Nobody cares if you can recite "O(n log n)". They care about three things:

1. **Can you derive it, live, from unfamiliar code?** They will show you code you've never seen and watch your process. Talk out loud: "the outer loop is n... the inner loop depends on i... let me sum that..."
2. **Do you volunteer it?** Finish every solution with "this is O(n log n) time and O(n) space, because ___." Unprompted. Every single time. It signals seniority.
3. **Can you use it to choose?** "Brute force is O(n²). Given n can be 10⁵, that's 10¹⁰ operations — far too slow. So I need at least O(n log n), which suggests sorting or a heap." **This is the money move.** Complexity analysis isn't a post-hoc label; it's how you *narrow the search space of possible solutions before writing code.*

**The constraint-to-algorithm cheat sheet.** Interviewers give you constraints for a reason. Read them as hints:

```
n <= 10           -> O(n!) or O(2^n) is fine. Think permutations / backtracking.
n <= 25           -> O(2^n) fine. Subset enumeration, bitmask DP.
n <= 100          -> O(n^3) fine. Floyd-Warshall, interval DP.
n <= 1,000        -> O(n^2) fine. Nested loops, most DP.
n <= 100,000      -> Need O(n log n). Sorting, heap, binary search, two pointers.
n <= 1,000,000    -> Need O(n) or O(n log n). Hashing, sliding window, prefix sum.
n >= 10^9         -> Need O(log n) or O(1). Binary search on answer, math formula.
```

Memorise this table. When an interviewer says "n can be up to 10⁵", they have just told you the answer is O(n log n). Say that out loud — "given n up to 10⁵, an O(n²) approach would be ~10¹⁰ operations, too slow, so I'm targeting O(n log n)" — and you have demonstrated engineering judgment in one sentence.

## 1.9 Practice Problems

### Easy 1
```java
void f(int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < 100; j++)
            System.out.println(i * j);
}
```
Time complexity?

### Easy 2
```java
void f(int n) {
    int i = n;
    while (i > 0) {
        System.out.println(i);
        i = i / 2;
    }
}
```
Time complexity?

### Medium 1
```java
void f(int n) {
    for (int i = 0; i < n; i++)
        for (int j = 1; j < n; j = j * 2)
            doWork();
}
```
Time complexity?

### Medium 2
An `ArrayList` grows by 1.5× when full. Starting empty, you perform `n` `add()` calls followed by `n` `remove(0)` calls. What is the total time complexity of the whole sequence? Is `remove(0)` amortized O(1)?

### Hard 1
```java
void f(int n) {
    if (n <= 1) return;
    f(n / 2);
    f(n / 2);
    for (int i = 0; i < n; i++) doWork();
}
```
Time complexity? Space complexity?

### Hard 2
You must process `n` = 200,000 queries on an array of 200,000 integers. Each query asks for the sum of a subrange. A naive loop per query is O(n) per query. Compute the total, decide if it passes within roughly 10⁸ operations, and name the technique that fixes it.

## 1.10 Solution Walkthrough

### Easy 1 — Answer: O(n)

The inner loop runs exactly 100 times **regardless of n**. It does not grow with the input, so it is a constant.

```
Total operations = n × 100 = 100n
Drop the constant       -> O(n)
```
The trap is seeing two nested loops and reflexively saying O(n²). **A loop is only O(n) if its bound depends on n.** A loop bounded by a literal constant is O(1). Check the bound, not the nesting depth.

### Easy 2 — Answer: O(log n)

Trace it for n = 16:
```
i = 16 -> print -> i = 8
i = 8  -> print -> i = 4
i = 4  -> print -> i = 2
i = 2  -> print -> i = 1
i = 1  -> print -> i = 0   (integer division: 1/2 = 0)
i = 0  -> loop exits
```
5 iterations for n = 16. For n = 32 you'd get 6. Each doubling of `n` adds exactly one iteration — the signature of a logarithm.

Formally: after `k` iterations, `i = n / 2^k`. The loop ends when `n / 2^k < 1`, i.e. `2^k > n`, i.e. `k > log₂ n`. → **O(log n)**.

Recognise the fingerprint: `i = i / 2` in a loop condition → log n. Every time.

### Medium 1 — Answer: O(n log n)

Analyse from the inside out. This is the discipline: **always innermost first.**

- Inner loop: `j = 1, 2, 4, 8, ... < n`. Multiplicative → runs `log₂ n` times.
- Outer loop: runs `n` times.
- Nested → multiply: `n × log n`.

→ **O(n log n)**.

Note this is the exact complexity of a good sort, and this loop shape is why "n log n" feels natural: it's "do a logarithmic thing, n times."

### Medium 2 — Answer: O(n²) total; `remove(0)` is NOT amortized O(1)

Two halves:

**The n adds:** amortized O(1) each, as derived in §1.4 → **O(n) total**. Fine.

**The n `remove(0)` calls:** this is the interesting half. `ArrayList.remove(0)` deletes the first element, which forces every remaining element to shift left one slot:

```
Before remove(0):   [A][B][C][D][E]
                        \  \  \  \
                         v  v  v  v      4 elements must physically move
After:              [B][C][D][E][ ]
```

Cost of `remove(0)` = O(size). So the sequence costs:
```
n-1 shifts, then n-2, then n-3, ... then 0
= (n-1) + (n-2) + ... + 1 + 0
= n(n-1)/2
= O(n²)
```

Whole sequence: O(n) + O(n²) = **O(n²)**.

Is `remove(0)` amortized O(1)? **No.** Amortization works when expensive operations are *rare*. Here *every* operation is expensive — there's no cheap majority to average against. Contrast with `remove(size-1)` (removing from the end), which shifts nothing and is genuinely O(1).

**The engineering lesson:** if you need to repeatedly remove from the front, `ArrayList` is the wrong data structure. Use `ArrayDeque` or `LinkedList`, where front removal is O(1). This exact mistake — using `ArrayList` as a queue — is a real, common, production performance bug.

### Hard 1 — Answer: O(n log n) time, O(log n) space

Set up a recurrence. Let `T(n)` be the cost on input `n`:
```
T(n) = 2·T(n/2) + n
       ^^^^^^^^   ^
       two calls   the loop
```

Unroll it by drawing the recursion tree. Each level's total work is the sum of `n` across that level:

```
Level 0:                    T(n)                        work = n
                          /      \
Level 1:            T(n/2)        T(n/2)                work = n/2 + n/2 = n
                    /    \        /    \
Level 2:        T(n/4) T(n/4)  T(n/4) T(n/4)            work = 4 × n/4 = n
                  ...    ...     ...    ...
Level log n:    T(1) T(1) ...................T(1)       work = n
                <-------- n leaves -------->
```

**Every level does exactly `n` work.** The tree has `log₂ n` levels (because n halves each level until it hits 1). So:

```
Total = n work/level × log n levels = O(n log n)
```

This is the Master Theorem case `a = 2, b = 2, f(n) = n` → `Θ(n log n)`. But notice you did **not** need the theorem. Drawing the tree and summing per level is faster, more reliable, and far more impressive in an interview because it shows you understand *why*.

**Space:** No arrays are allocated, so the only space is the call stack. Critically, the two recursive calls happen **sequentially, not simultaneously** — the first `f(n/2)` fully returns and its frames are popped before the second begins. So the stack depth is the *height* of the tree, not the *number of nodes*:

```
Maximum simultaneous depth = log n  ->  O(log n) space
```

Students almost always answer O(n) here. Getting O(log n) right — and explaining *why* (sequential calls share stack space) — is a genuine differentiator.

### Hard 2 — Answer: naive is 4×10¹⁰ (far too slow); use a **prefix sum array**

The arithmetic first, because interviewers want to see you do exactly this:
```
200,000 queries × 200,000 elements per query = 4 × 10^10 operations
Budget: ~10^8 operations
Over budget by 400x  ->  will time out. Definitively.
```

Now consult the constraint table from §1.8: `n = 2×10⁵` on both axes means we need roughly O(n) or O(n log n) *total*, which means **O(1) per query** after preprocessing.

The fix — precompute cumulative sums once:

```
arr    =  [ 3,  1,  4,  1,  5,  9 ]
prefix =  [ 0,  3,  4,  8,  9, 14, 23 ]
            ^                        ^
        prefix[0]=0            prefix[i] = sum of first i elements
```

Then the sum of `arr[l..r]` inclusive is a single subtraction:

```java
sum(l, r) = prefix[r + 1] - prefix[l];
```

Verify on `arr[2..4]` = 4 + 1 + 5 = 10:
```
prefix[5] - prefix[2] = 14 - 4 = 10   ✓
```

Why it works, visually — you're taking a long bar and cutting off the part you don't want:

```
prefix[5] covers:  |--- 3 --- 1 --- 4 --- 1 --- 5 ---|
prefix[2] covers:  |--- 3 --- 1 ---|
subtract        :                  |--- 4 --- 1 --- 5 ---|   <- exactly arr[2..4]
```

New total complexity: **O(n) preprocessing + O(1) per query = O(n + q)** ≈ 4×10⁵ operations. Comfortably fast — a 100,000× improvement, achieved purely by counting operations before writing code.

This is Module 27 (Prefix Sum) arriving early, and that's deliberate: I want you to see that complexity analysis *generates* algorithms. It isn't bookkeeping you do at the end. It's the tool that tells you what to build.

---
---
