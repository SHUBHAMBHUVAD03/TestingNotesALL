# The Complete DSA Course in Java
### Taught from first principles, as a live classroom lecture

---

## How to read this document

I am your instructor. You are sitting in front of me with a laptop open, Java 17 installed, and no prior DSA knowledge. Everything below is written the way I would actually say it out loud.

Three rules before we start:

**Rule 1 — Do not skim.** This document is not notes. If you skim it, you will learn nothing. Every dry run in here is meant to be traced with your finger on the screen.

**Rule 2 — Type the code, don't copy it.** Your fingers need to learn `int mid = lo + (hi - lo) / 2;` so that it comes out under interview pressure. Copy-paste teaches you nothing.

**Rule 3 — Stop at every "Your turn" box.** Attempt it before reading the solution. Struggle is the mechanism of learning; reading a solution feels like learning but isn't.

### What's in this file

This is **Part 1** of the course, covering the foundation layer end to end at full lecture depth:

| Module | Topic |
|---|---|
| 1 | Complexity Analysis — Big O, Ω, Θ, Amortized |
| 2 | Arrays |
| 3 | Strings |
| 4 | Recursion |
| 5 | Searching + the Binary Search Pattern |
| 6 | Sorting — Bubble, Selection, Insertion, Merge, Quick, Heap, Counting, Radix |
| 7 | Linked Lists — Singly, Doubly, Circular |

A deliberate word about scope. You asked for 35 topics at this depth. Taught properly — intuition, memory model, ASCII diagrams, dry runs, line-by-line code, edge cases, interview framing, and graded problems for each — that is a 900-page book, not one file. I refuse to give you 35 thin sections, because you explicitly said "do NOT give short definitions and move on," and I agree with you. Thin coverage of everything is how people end up recognising algorithms without being able to write them.

So: this part teaches modules 1–7 at the depth you asked for. Say **"continue"** and I will append the next block (Stacks, Queues, Hashing, Trees) to this same file, and keep going until all 35 are done at this standard.

---
---

# MODULE 1 — Complexity Analysis

## 1.1 Intuition

Forget formulas. Start with a story.

You have a phone book with 1,000,000 names in it, sorted alphabetically. I ask you to find "Ramesh".

**Strategy A:** Start at page 1, name 1. Read every name until you hit Ramesh.
**Strategy B:** Open the middle. Is Ramesh before or after? Throw away half. Open the middle of what's left. Repeat.

Strategy A might read 1,000,000 names. Strategy B reads about 20.

Now here's the part everyone misses. The interesting question is **not** "how many names did you read?" The interesting question is **"what happens when the phone book doubles in size?"**

```
Phone book size    Strategy A reads    Strategy B reads
-----------------  ------------------  ------------------
     1,000,000            1,000,000                  20
     2,000,000            2,000,000                  21
     4,000,000            4,000,000                  22
 1,000,000,000        1,000,000,000                  30
```

Look at those columns. Strategy A's work **doubles when the input doubles**. Strategy B's work **increases by one when the input doubles**.

That relationship — *how does the work grow as the input grows* — is the entire subject of complexity analysis. That's it. That's the whole idea.

> **Complexity analysis is not about measuring speed. It is about measuring the *shape of growth*.**

This is why we don't measure in seconds. Seconds depend on your CPU, on whether Chrome is open, on the JIT compiler's mood. But the *shape* — "doubling the input doubles the work" — is a permanent mathematical property of the algorithm. It's true on your laptop, on a supercomputer, and on a machine built in 2090.

## 1.2 Mental Model

Here is the model I want burned into your head. **Count the operations that grow with the input, ignore everything else.**

Three concrete habits:

**Habit 1 — Ask "how many times does the innermost line run?"**

```java
for (int i = 0; i < n; i++) {        // outer
    for (int j = 0; j < n; j++) {    // inner
        sum += arr[i][j];            // <-- THIS LINE. How many times?
    }
}
```
The inner line runs `n` times for each of `n` outer iterations, so `n × n = n²` times. That's your answer: **O(n²)**. You didn't need math. You needed to ask which line is hottest.

**Habit 2 — Throw away constants and small terms.**

If you count exactly `3n² + 50n + 700` operations, the answer is **O(n²)**.

Why is that legitimate? Because for large `n`, `n²` bullies everything else:

```
n = 10       3n² = 300        50n = 500      700 = 700     <- 700 dominates!
n = 100      3n² = 30,000     50n = 5,000    700 = 700     <- n² takes over
n = 1,000    3n² = 3,000,000  50n = 50,000   700 = 700     <- n² is 98% of the work
n = 10,000   3n² = 300 MILLION           ...              <- n² is everything
```

The `50n` and `700` become rounding errors. And the `3`? A constant multiplier doesn't change the *shape* of growth — doubling `n` still quadruples `3n²`, exactly as it quadruples `n²`. We care about shape, so the 3 goes.

**Habit 3 — Know the ladder by heart.**

```
        FAST                                                     SLOW
         |                                                         |
    O(1) < O(log n) < O(n) < O(n log n) < O(n²) < O(n³) < O(2^n) < O(n!)
```

Feel these with real numbers. Assume 10⁸ simple operations per second (a realistic figure for Java):

```
n           O(log n)   O(n)      O(n log n)   O(n²)          O(2^n)
----------  ---------  --------  -----------  -------------  --------------------
10          3          10        33           100            1,024
100         7          100       664          10,000         10^30  (heat death)
1,000       10         1,000     9,966        1,000,000      forget it
1,000,000   20         10^6      2 × 10^7     10^12          forget it
                                              ~2.8 hours
```

**The single most useful line in this table:** at `n = 1,000,000`, an O(n log n) algorithm finishes in about 0.2 seconds and an O(n²) algorithm takes about 2.8 hours. Same problem. Same computer. That gap is why this module exists.

## 1.3 Internal Working — the four notations

Students confuse O, Ω, and Θ endlessly. Here's the fix: **they are not about best/average/worst case.** That is the classic misconception. They are about **bounds on a function**.

Think of it as describing someone's height:

- **Big O** = "he is *at most* 6 feet tall" — an **upper** bound (a ceiling).
- **Big Ω (Omega)** = "he is *at least* 5 feet tall" — a **lower** bound (a floor).
- **Big Θ (Theta)** = "he is *exactly* 5'10", give or take an inch" — a **tight** bound (both at once).

```
   work
    ^
    |                                      . c2·g(n)     <-- Big O ceiling
    |                                  .
    |                              .
    |                          .  ___---  f(n)  actual algorithm
    |                      . ___---
    |                  ._--
    |              .--          ______ c1·g(n)  <-- Big Ω floor
    |          .--      ______--
    |      .--   ______--
    |  .--_____--
    +------------------------------------------> n
             ^
             n0 (bounds only need to hold beyond here)
```

Formally, for `n` beyond some threshold `n₀`:

- `f(n) = O(g(n))` if `f(n) ≤ c · g(n)` for some constant `c > 0`
- `f(n) = Ω(g(n))` if `f(n) ≥ c · g(n)` for some constant `c > 0`
- `f(n) = Θ(g(n))` if both hold — the function is sandwiched

Now, the sentence that makes this click:

> **You can talk about the Big O of the best case, and the Big Ω of the worst case.** The notation and the case are independent axes.

Example — linear search for a target in an unsorted array of `n` elements:

```
Best case:    target is at index 0        -> 1 comparison     -> Θ(1)
Worst case:   target absent               -> n comparisons    -> Θ(n)
Average case: uniformly random position   -> n/2 comparisons  -> Θ(n)
```

The *worst case* of linear search is `Θ(n)`. It is also `O(n)`, and also `O(n²)` (a ceiling of n² is technically true — just useless, like saying a person is at most 900 feet tall). And it is `Ω(n)`.

**Why does industry say "O" for everything?** Because we mostly care about worst-case guarantees, and `O` is the notation for "no worse than." It's slightly sloppy — when we say "quicksort is O(n log n)" we usually mean "Θ(n log n) on average" — but everybody understands it. In an interview, say O, but if the interviewer probes, show that you know the difference. That single distinction separates candidates who memorised from candidates who understand.

### 1.4 Amortized Analysis — the one that gets people the job

This is subtle, important, and heavily tested. Let's build it properly.

Java's `ArrayList` is backed by a plain array. Arrays are fixed-size. So what happens when you `add()` to a full ArrayList?

```
Step 1: ArrayList is full, capacity 4
    +---+---+---+---+
    | A | B | C | D |   size = 4, capacity = 4
    +---+---+---+---+

Step 2: add("E") -> no room. Allocate a NEW array, 1.5x bigger (capacity 6)
    +---+---+---+---+---+---+
    |   |   |   |   |   |   |   new array, empty
    +---+---+---+---+---+---+

Step 3: COPY all 4 old elements across  <-- this costs 4 operations!
    +---+---+---+---+---+---+
    | A | B | C | D |   |   |
    +---+---+---+---+---+---+

Step 4: NOW write E
    +---+---+---+---+---+---+
    | A | B | C | D | E |   |   size = 5, capacity = 6
    +---+---+---+---+---+---+

Step 5: old array becomes garbage -> eligible for GC
```

So one `add()` cost 5 operations, not 1. That's O(n) for that call. Does that mean `ArrayList.add()` is O(n)?

**No.** And here's the reasoning that matters.

Let's use doubling (simpler arithmetic; the logic is identical for 1.5×). Track the cost of each of 17 `add` calls starting from capacity 1:

```
add #   capacity before   resize?   copies   total cost
-----   ---------------   -------   ------   ----------
  1            1            no        0          1
  2            1           YES ->2    1          2
  3            2           YES ->4    2          3
  4            4            no        0          1
  5            4           YES ->8    4          5
  6            8            no        0          1
  7            8            no        0          1
  8            8            no        0          1
  9            8           YES ->16   8          9
 10..16       16            no        0          1  (x7)
 17           16           YES ->32  16         17
```

The expensive calls are rare, and they get **exponentially rarer** as they get more expensive. Total copy work for `n` inserts:

```
1 + 2 + 4 + 8 + 16 + ... + n/2 + n  <  2n
```

That's a geometric series. Its sum is less than `2n`. So `n` inserts cost less than `n + 2n = 3n` operations total.

```
Average cost per insert = 3n / n = 3 = O(1)
```

**That is amortized O(1).** The definition:

> **Amortized complexity** = total cost of a sequence of operations, divided by the number of operations. It is a *guaranteed average over the sequence*, not a probabilistic average.

Visualise the cost of each individual insert:

```
cost
 |
16-|                                                 X          <- rare, expensive
 8-|                       X
 4-|           X
 2-|     X
 1-| X X   X X   X X X X X   X X X X X X X X X X X X X X X X X  <- common, cheap
   +---------------------------------------------------------> insert #
     The spikes are so rare that the AREA under this whole
     graph is still only about 3n. Flat on average.
```

**The distinction that wins interviews.** If an interviewer asks "what's the difference between average-case and amortized?", say this:

- **Average case** is probabilistic. It assumes a distribution over inputs. An adversary who knows your algorithm can feed you bad input every single time and you'll never get the average. (Quicksort's O(n log n) is average-case: an adversary can force O(n²).)
- **Amortized** is a worst-case guarantee about a *sequence*. There is no probability involved and no adversary can break it. If you do `n` ArrayList inserts, you *will* pay less than 3n — guaranteed, always.

Amortized is a much stronger promise than average case. Say that sentence in an interview and watch the interviewer's face change.

**Why 1.5× and not +1?** Because growing by a constant amount destroys the geometric series:

```
Growth by +1 each time:  copies = 1+2+3+...+n = n(n+1)/2 = O(n²) total
                         -> amortized O(n) per insert. Terrible.

Growth by x1.5 or x2:    copies = geometric series < 2n or < 3n total
                         -> amortized O(1) per insert. Excellent.
```

Multiplicative growth is what buys the O(1). This is a real engineering insight, not trivia.

## 1.5 Reading complexity off real code — a drill

Let's do these fast. Cover the answers with your hand.

**Example A**
```java
int sum = 0;
for (int i = 0; i < n; i++) {
    sum += i;
}
```
`n` iterations, O(1) work each → **O(n)** time, **O(1)** space.

**Example B**
```java
for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
        System.out.println(i + "," + j);
    }
}
```
→ **O(n²)**. Nested independent loops multiply.

**Example C — the trap**
```java
for (int i = 0; i < n; i++) {
    for (int j = i; j < n; j++) {   // note: j starts at i, not 0
        doWork();
    }
}
```
Count honestly:
```
i=0   -> j runs n times
i=1   -> j runs n-1 times
i=2   -> j runs n-2 times
...
i=n-1 -> j runs 1 time

Total = n + (n-1) + (n-2) + ... + 1 = n(n+1)/2 = n²/2 + n/2
```
Drop constants → **O(n²)**. Yes, it does half the work of Example B. Half of n² is still n². **Constant factors do not change the class.** Beginners answer "O(n²/2)" — that's not a thing. Write O(n²).

**Example D — the other trap**
```java
for (int i = 1; i < n; i = i * 2) {
    doWork();
}
```
`i` takes values 1, 2, 4, 8, 16, ... How many steps until `i ≥ n`? We need `2^k ≥ n`, so `k = log₂ n`. → **O(log n)**.

> **Rule of thumb: whenever a variable is multiplied or divided each step instead of incremented, a logarithm appears.** Halving → log n. Doubling → log n. This is the fingerprint of a logarithm; learn to spot it instantly.

**Example E — sequential, not nested**
```java
for (int i = 0; i < n; i++) { a(); }     // O(n)
for (int i = 0; i < n; i++) { b(); }     // O(n)
```
→ O(n) + O(n) = O(2n) = **O(n)**. Sequential loops **add**; nested loops **multiply**. Addition of same-class terms collapses.

**Example F — two different inputs**
```java
for (int i = 0; i < n; i++)
    for (int j = 0; j < m; j++)
        doWork();
```
→ **O(n·m)**. Do *not* write O(n²). If `n` and `m` are independent, keep both letters. Interviewers notice this.

**Example G — the classic mistake**
```java
List<Integer> list = new ArrayList<>();
for (int i = 0; i < n; i++) {
    if (list.contains(i)) { ... }        // <-- contains() is O(n) itself!
}
```
The loop is O(n), but the body is O(n), not O(1). → **O(n²)**. This bug appears in real production code constantly. Swapping `ArrayList` for `HashSet` makes `contains` O(1) and the whole thing O(n). **Always know the complexity of the library methods you call.**

**Example H — string concatenation in a loop**
```java
String s = "";
for (int i = 0; i < n; i++) {
    s += "x";              // creates a NEW String every time
}
```
Java `String` is immutable. Iteration `i` copies `i` characters into a fresh object. Total = 1+2+...+n = **O(n²)** time and O(n²) total allocation churn. Use `StringBuilder` → O(n). We'll cover this in Module 3; it is one of the most common Java performance bugs in existence.

## 1.6 Space Complexity — and the part everyone forgets

Space complexity = **extra** memory used, as a function of input size. The input itself is usually not counted (it's called *auxiliary space*).

```java
// O(1) auxiliary space - a fixed number of variables regardless of n
int max(int[] arr) {
    int best = arr[0];        // 1 int
    for (int x : arr)         // 1 more int
        if (x > best) best = x;
    return best;
}
```

```java
// O(n) auxiliary space - allocation scales with input
int[] doubled(int[] arr) {
    int[] out = new int[arr.length];   // n ints on the heap
    ...
}
```

**The forgotten one: the call stack counts as space.**

```java
int factorial(int n) {
    if (n == 0) return 1;
    return n * factorial(n - 1);
}
```

This allocates no arrays, no objects. Students confidently say O(1) space. **Wrong.** There are `n` nested stack frames alive simultaneously:

```
  |  factorial(1)  |  <- top of stack
  |  factorial(2)  |
  |  factorial(3)  |
  |     ...        |   n frames, each holding a copy of n and a return address
  |  factorial(n)  |
  +----------------+
```

→ **O(n) space.** And when `n` is large enough, those frames exhaust the JVM's thread stack and you get `StackOverflowError`. On a default JVM that's roughly 10,000–20,000 frames deep. This is exactly why recursion depth matters and why we care about tail-call-shaped rewrites and iterative conversions (Module 4).

## 1.7 Common Mistakes

1. **"O(2n) is faster than O(n²)"** — mixing up notation with measurement. O(2n) *is* O(n). Simplify before comparing.
2. **Writing O(n²/2) or O(3n)** — these aren't valid answers. Drop constants. Always.
3. **Confusing worst case with Big O** — they're different axes. See §1.3.
4. **Forgetting the call stack in space analysis** — see §1.6.
5. **Ignoring the cost of library calls** — `list.contains`, `String.substring`, `map.containsKey` all have complexities. Know them.
6. **Assuming `log` means log₁₀** — in DSA, `log n` means log₂ n unless stated. (It doesn't actually matter for Big O, since log bases differ by a constant factor, but say "log base 2" out loud so the interviewer knows you know.)
7. **Analysing the code you *meant* to write** — analyse the code on the screen, line by line, counting the innermost line.

## 1.8 Interview Perspective

**What interviewers are actually testing.** Nobody cares if you can recite "O(n log n)". They care about three things:

1. **Can you derive it, live, from unfamiliar code?** They will show you code you've never seen and watch your process. Talk out loud: "the outer loop is n... the inner loop depends on i... let me sum that..."
2. **Do you volunteer it?** Finish every solution with "this is O(n log n) time and O(n) space, because ___." Unprompted. Every single time. It signals seniority.
3. **Can you use it to choose?** "Brute force is O(n²). Given n can be 10⁵, that's 10¹⁰ operations — far too slow. So I need at least O(n log n), which suggests sorting or a heap." **This is the money move.** Complexity analysis isn't a post-hoc label; it's how you *narrow the search space of possible solutions before writing code.*

**The constraint-to-algorithm cheat sheet.** Interviewers give you constraints for a reason. Read them as hints:

```
n <= 10           -> O(n!) or O(2^n) is fine. Think permutations / backtracking.
n <= 25           -> O(2^n) fine. Subset enumeration, bitmask DP.
n <= 100          -> O(n^3) fine. Floyd-Warshall, interval DP.
n <= 1,000        -> O(n^2) fine. Nested loops, most DP.
n <= 100,000      -> Need O(n log n). Sorting, heap, binary search, two pointers.
n <= 1,000,000    -> Need O(n) or O(n log n). Hashing, sliding window, prefix sum.
n >= 10^9         -> Need O(log n) or O(1). Binary search on answer, math formula.
```

Memorise this table. When an interviewer says "n can be up to 10⁵", they have just told you the answer is O(n log n). Say that out loud — "given n up to 10⁵, an O(n²) approach would be ~10¹⁰ operations, too slow, so I'm targeting O(n log n)" — and you have demonstrated engineering judgment in one sentence.

## 1.9 Practice Problems

### Easy 1
```java
void f(int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < 100; j++)
            System.out.println(i * j);
}
```
Time complexity?

### Easy 2
```java
void f(int n) {
    int i = n;
    while (i > 0) {
        System.out.println(i);
        i = i / 2;
    }
}
```
Time complexity?

### Medium 1
```java
void f(int n) {
    for (int i = 0; i < n; i++)
        for (int j = 1; j < n; j = j * 2)
            doWork();
}
```
Time complexity?

### Medium 2
An `ArrayList` grows by 1.5× when full. Starting empty, you perform `n` `add()` calls followed by `n` `remove(0)` calls. What is the total time complexity of the whole sequence? Is `remove(0)` amortized O(1)?

### Hard 1
```java
void f(int n) {
    if (n <= 1) return;
    f(n / 2);
    f(n / 2);
    for (int i = 0; i < n; i++) doWork();
}
```
Time complexity? Space complexity?

### Hard 2
You must process `n` = 200,000 queries on an array of 200,000 integers. Each query asks for the sum of a subrange. A naive loop per query is O(n) per query. Compute the total, decide if it passes within roughly 10⁸ operations, and name the technique that fixes it.

## 1.10 Solution Walkthrough

### Easy 1 — Answer: O(n)

The inner loop runs exactly 100 times **regardless of n**. It does not grow with the input, so it is a constant.

```
Total operations = n × 100 = 100n
Drop the constant       -> O(n)
```
The trap is seeing two nested loops and reflexively saying O(n²). **A loop is only O(n) if its bound depends on n.** A loop bounded by a literal constant is O(1). Check the bound, not the nesting depth.

### Easy 2 — Answer: O(log n)

Trace it for n = 16:
```
i = 16 -> print -> i = 8
i = 8  -> print -> i = 4
i = 4  -> print -> i = 2
i = 2  -> print -> i = 1
i = 1  -> print -> i = 0   (integer division: 1/2 = 0)
i = 0  -> loop exits
```
5 iterations for n = 16. For n = 32 you'd get 6. Each doubling of `n` adds exactly one iteration — the signature of a logarithm.

Formally: after `k` iterations, `i = n / 2^k`. The loop ends when `n / 2^k < 1`, i.e. `2^k > n`, i.e. `k > log₂ n`. → **O(log n)**.

Recognise the fingerprint: `i = i / 2` in a loop condition → log n. Every time.

### Medium 1 — Answer: O(n log n)

Analyse from the inside out. This is the discipline: **always innermost first.**

- Inner loop: `j = 1, 2, 4, 8, ... < n`. Multiplicative → runs `log₂ n` times.
- Outer loop: runs `n` times.
- Nested → multiply: `n × log n`.

→ **O(n log n)**.

Note this is the exact complexity of a good sort, and this loop shape is why "n log n" feels natural: it's "do a logarithmic thing, n times."

### Medium 2 — Answer: O(n²) total; `remove(0)` is NOT amortized O(1)

Two halves:

**The n adds:** amortized O(1) each, as derived in §1.4 → **O(n) total**. Fine.

**The n `remove(0)` calls:** this is the interesting half. `ArrayList.remove(0)` deletes the first element, which forces every remaining element to shift left one slot:

```
Before remove(0):   [A][B][C][D][E]
                        \  \  \  \
                         v  v  v  v      4 elements must physically move
After:              [B][C][D][E][ ]
```

Cost of `remove(0)` = O(size). So the sequence costs:
```
n-1 shifts, then n-2, then n-3, ... then 0
= (n-1) + (n-2) + ... + 1 + 0
= n(n-1)/2
= O(n²)
```

Whole sequence: O(n) + O(n²) = **O(n²)**.

Is `remove(0)` amortized O(1)? **No.** Amortization works when expensive operations are *rare*. Here *every* operation is expensive — there's no cheap majority to average against. Contrast with `remove(size-1)` (removing from the end), which shifts nothing and is genuinely O(1).

**The engineering lesson:** if you need to repeatedly remove from the front, `ArrayList` is the wrong data structure. Use `ArrayDeque` or `LinkedList`, where front removal is O(1). This exact mistake — using `ArrayList` as a queue — is a real, common, production performance bug.

### Hard 1 — Answer: O(n log n) time, O(log n) space

Set up a recurrence. Let `T(n)` be the cost on input `n`:
```
T(n) = 2·T(n/2) + n
       ^^^^^^^^   ^
       two calls   the loop
```

Unroll it by drawing the recursion tree. Each level's total work is the sum of `n` across that level:

```
Level 0:                    T(n)                        work = n
                          /      \
Level 1:            T(n/2)        T(n/2)                work = n/2 + n/2 = n
                    /    \        /    \
Level 2:        T(n/4) T(n/4)  T(n/4) T(n/4)            work = 4 × n/4 = n
                  ...    ...     ...    ...
Level log n:    T(1) T(1) ...................T(1)       work = n
                <-------- n leaves -------->
```

**Every level does exactly `n` work.** The tree has `log₂ n` levels (because n halves each level until it hits 1). So:

```
Total = n work/level × log n levels = O(n log n)
```

This is the Master Theorem case `a = 2, b = 2, f(n) = n` → `Θ(n log n)`. But notice you did **not** need the theorem. Drawing the tree and summing per level is faster, more reliable, and far more impressive in an interview because it shows you understand *why*.

**Space:** No arrays are allocated, so the only space is the call stack. Critically, the two recursive calls happen **sequentially, not simultaneously** — the first `f(n/2)` fully returns and its frames are popped before the second begins. So the stack depth is the *height* of the tree, not the *number of nodes*:

```
Maximum simultaneous depth = log n  ->  O(log n) space
```

Students almost always answer O(n) here. Getting O(log n) right — and explaining *why* (sequential calls share stack space) — is a genuine differentiator.

### Hard 2 — Answer: naive is 4×10¹⁰ (far too slow); use a **prefix sum array**

The arithmetic first, because interviewers want to see you do exactly this:
```
200,000 queries × 200,000 elements per query = 4 × 10^10 operations
Budget: ~10^8 operations
Over budget by 400x  ->  will time out. Definitively.
```

Now consult the constraint table from §1.8: `n = 2×10⁵` on both axes means we need roughly O(n) or O(n log n) *total*, which means **O(1) per query** after preprocessing.

The fix — precompute cumulative sums once:

```
arr    =  [ 3,  1,  4,  1,  5,  9 ]
prefix =  [ 0,  3,  4,  8,  9, 14, 23 ]
            ^                        ^
        prefix[0]=0            prefix[i] = sum of first i elements
```

Then the sum of `arr[l..r]` inclusive is a single subtraction:

```java
sum(l, r) = prefix[r + 1] - prefix[l];
```

Verify on `arr[2..4]` = 4 + 1 + 5 = 10:
```
prefix[5] - prefix[2] = 14 - 4 = 10   ✓
```

Why it works, visually — you're taking a long bar and cutting off the part you don't want:

```
prefix[5] covers:  |--- 3 --- 1 --- 4 --- 1 --- 5 ---|
prefix[2] covers:  |--- 3 --- 1 ---|
subtract        :                  |--- 4 --- 1 --- 5 ---|   <- exactly arr[2..4]
```

New total complexity: **O(n) preprocessing + O(1) per query = O(n + q)** ≈ 4×10⁵ operations. Comfortably fast — a 100,000× improvement, achieved purely by counting operations before writing code.

This is Module 27 (Prefix Sum) arriving early, and that's deliberate: I want you to see that complexity analysis *generates* algorithms. It isn't bookkeeping you do at the end. It's the tool that tells you what to build.

---
---
# MODULE 2 — Arrays

## 2.1 Intuition

An array is a **row of identical mailboxes, numbered from zero, with no gaps.**

That mundane sentence contains the entire theory of arrays. Let me unpack why.

Picture a street of mailboxes. Each box is exactly the same size. They are physically adjacent. Box numbering starts at 0.

```
        index:   0      1      2      3      4
              +------+------+------+------+------+
    values:   |  10  |  20  |  30  |  40  |  50  |
              +------+------+------+------+------+
   address:    1000   1004   1008   1012   1016
                 ^      ^
                 |      +-- 4 bytes later (an int is 4 bytes)
                 +--------- base address
```

Now: I ask you for box 3. How long does it take you to find it?

You don't walk down the street counting. You **compute** where it is:

```
address of arr[i] = base_address + (i × size_of_one_element)
address of arr[3] = 1000 + (3 × 4) = 1012
```

One multiply, one add. **That's it.** Whether the array holds 5 elements or 5 billion, finding `arr[i]` is the same two arithmetic operations. That's **O(1) random access**, and it is the single reason arrays are the foundation of every other data structure.

**And now the price.** That formula only works because the boxes are adjacent and equal-sized. Which means:

- **The size is fixed at creation.** You cannot add a 6th mailbox if the neighbour's house is there. To grow, you must find a new plot and move everything.
- **Insertion in the middle is expensive.** To insert at index 1, everything from index 1 onwards must physically shift right to make a hole.

```
    Insert 15 at index 1:

    Before:  [ 10 | 20 | 30 | 40 | 50 ]
                    \    \    \    \
                     v    v    v    v      4 elements must MOVE
    After:   [ 10 | 15 | 20 | 30 | 40 ]    (50 falls off / needs bigger array)
```

Every array trade-off in existence falls out of that one geometric fact. **O(1) access, O(n) insertion/deletion, fixed size.** Not three separate facts to memorise — one fact with three consequences.

## 2.2 Mental Model

Three mental postures to adopt:

**Posture 1 — "Index is an offset, not a position."**

`arr[3]` does not mean "the 3rd thing." It means "3 elements' worth of bytes past the start." That's why arrays are 0-indexed: `arr[0]` is "0 bytes past the start" — the start itself. Once you internalise this, off-by-one errors mostly stop happening, because you start thinking in offsets and gaps rather than counting on your fingers.

**Posture 2 — "The last valid index is `n - 1`, always."**

An array of length 5 has indices 0, 1, 2, 3, 4. `arr[5]` throws `ArrayIndexOutOfBoundsException`. Write `< length`, never `<= length`. Every single time you type a loop condition, the `<` should be automatic.

**Posture 3 — "If you're scanning an array twice, ask whether one pass would do."**

Most array interview problems are secretly "can you do this in one pass with O(1) extra space?" Techniques like two pointers (Module 23), sliding window (Module 22), and prefix sums (Module 27) are all answers to that question. Arrays are where you learn the *habit* of collapsing multiple passes into one.

## 2.3 Internal Working — what the JVM actually does

This is where Java gets interesting, and where most tutorials stop far too early.

### An array in Java is an object

```java
int[] arr = new int[5];
```

Two separate things exist after this line:

```
       STACK                              HEAP
   +-------------+              +----------------------------+
   |  arr        |------------->|  Object header  (~16 bytes)|
   | (reference) |              |  - class ptr: int[]        |
   |  8 bytes    |              |  - mark word / hash / GC   |
   +-------------+              |  length: 5   (4 bytes)     |
                                +----------------------------+
                                |  [0] = 0                   |
                                |  [1] = 0                   |  contiguous
                                |  [2] = 0                   |  payload
                                |  [3] = 0                   |  5 × 4 = 20 bytes
                                |  [4] = 0                   |
                                +----------------------------+
```

Key facts, each of which has consequences:

1. **`arr` on the stack is just a reference** (a pointer, typically 8 bytes, or 4 with compressed oops). The actual data lives on the heap.
2. **`length` is stored in the object header.** This is why `arr.length` is O(1) and is a *field*, not a method — no parentheses. (`String.length()` *is* a method — an inconsistency in Java that trips up beginners constantly.)
3. **Java zero-initialises the payload.** `int[]` → all 0. `boolean[]` → all `false`. `double[]` → all 0.0. `Object[]` / `String[]` → all `null`. You never read garbage in Java, unlike C. This costs a memset at allocation time but eliminates an entire class of bugs.
4. **Every access is bounds-checked.** `arr[i]` compiles to a bytecode instruction that compares `i` against `length` and throws if out of range. This is a real cost — which the JIT compiler often eliminates when it can prove `i` is in range (loop bounds hoisting). This is why `for (int i = 0; i < arr.length; i++)` can be *faster* than caching the length in a variable: the JIT recognises the idiom.

### Object arrays are arrays of references, not objects

This is a huge one.

```java
int[]    primitives = {10, 20, 30};
String[] objects    = {"ab", "cd", "ef"};
```

```
   primitives (heap):                   objects (heap):
   +--------+                           +--------+
   | header |                           | header |
   | len 3  |                           | len 3  |
   +--------+                           +--------+
   |   10   |  <- actual value          |  ref --|---> String "ab" (elsewhere in heap)
   |   20   |  <- actual value          |  ref --|---> String "cd" (elsewhere in heap)
   |   30   |  <- actual value          |  ref --|---> String "ef" (elsewhere in heap)
   +--------+                           +--------+
   ONE contiguous block                 ONE contiguous block of POINTERS,
   Cache-friendly. Fast.                objects scattered across the heap.
```

Consequences you can state in an interview:

- `int[1000]` is one cache-friendly block; iterating it is extremely fast because the CPU prefetches the next cache line and gets 16 ints at once.
- `Integer[1000]` is 1000 pointers to 1000 separate heap objects, likely scattered. Iterating it causes **cache misses** — potentially 10–100× slower for the same logical operation.
- This is why **`int[]` beats `List<Integer>` for hot numeric loops**, and why competitive programmers religiously use primitive arrays. It's not superstition; it's memory locality.

### 2D arrays in Java are arrays of arrays

```java
int[][] grid = new int[3][4];
```

Java does **not** have true 2D arrays. It has an array of references, each pointing to a separate 1D array:

```
   grid
    |
    v
  +------+
  | ref -|---> +----+----+----+----+
  +------+     |  0 |  0 |  0 |  0 |   row 0  (separate heap object)
  | ref -|--   +----+----+----+----+
  +------+  \
  | ref -|-  \-> +----+----+----+----+
  +------+ \     |  0 |  0 |  0 |  0 |   row 1  (separate heap object)
            \    +----+----+----+----+
             \
              \> +----+----+----+----+
                 |  0 |  0 |  0 |  0 |   row 2  (separate heap object)
                 +----+----+----+----+

   That's 4 heap objects total: 1 outer + 3 rows.
```

Two practical consequences:

**(a) Jagged arrays are legal.** Rows can have different lengths:
```java
int[][] triangle = new int[3][];
triangle[0] = new int[1];   // [ _ ]
triangle[1] = new int[2];   // [ _ | _ ]
triangle[2] = new int[3];   // [ _ | _ | _ ]
```
This is exactly how you build Pascal's Triangle, and it saves memory in DP problems with triangular state spaces.

**(b) Row-major traversal is much faster than column-major.**
```java
// FAST - walks each row's contiguous memory in order
for (int i = 0; i < rows; i++)
    for (int j = 0; j < cols; j++)
        sum += grid[i][j];

// SLOW - jumps between different heap objects on every step
for (int j = 0; j < cols; j++)
    for (int i = 0; i < rows; i++)
        sum += grid[i][j];
```
Same complexity — O(rows × cols) both ways. But the first can be several times faster in wall-clock time due to cache behaviour. **Mentioning this in an interview marks you as someone who has thought about performance, not just Big O.**

## 2.4 Visual Explanation — the three core operations

### Access — O(1)

```
   arr[2]?
        |
        v  compute base + 2*4, read. Done. One step, always.
   +----+----+----+----+----+
   | 10 | 20 | 30 | 40 | 50 |
   +----+----+----+----+----+
     0    1    2    3    4
```

### Insert at index 1 — O(n)

```
Goal: insert 15 at index 1 in [10, 20, 30, 40, _] (size=4, capacity=5)

Step 1: Shift RIGHT, starting from the RIGHTMOST element.
        (Why rightmost first? Read on — this is the key insight.)

        i=3:  copy arr[3] -> arr[4]
        +----+----+----+----+----+
        | 10 | 20 | 30 | 40 | 40 |
        +----+----+----+----+----+
                              ^ copied

        i=2:  copy arr[2] -> arr[3]
        +----+----+----+----+----+
        | 10 | 20 | 30 | 30 | 40 |
        +----+----+----+----+----+
                         ^ copied

        i=1:  copy arr[1] -> arr[2]
        +----+----+----+----+----+
        | 10 | 20 | 20 | 30 | 40 |
        +----+----+----+----+----+
                    ^ copied      <- index 1 is now safe to overwrite

Step 2: write the new value
        +----+----+----+----+----+
        | 10 | 15 | 20 | 30 | 40 |
        +----+----+----+----+----+
               ^ inserted, size = 5
```

**Why right-to-left?** If you shifted left-to-right you would overwrite values before copying them:

```
   WRONG (left to right):
   arr[2] = arr[1]  ->  [10, 20, 20, 40]   <- 30 is GONE, destroyed
   arr[3] = arr[2]  ->  [10, 20, 20, 20]   <- catastrophe
```

This is the classic "shift direction" bug. The rule generalises:

> **When shifting right (making room), iterate right-to-left. When shifting left (closing a gap), iterate left-to-right.**
>
> Always copy *away from* the direction you're moving into.

### Delete at index 1 — O(n)

```
Delete arr[1] from [10, 20, 30, 40, 50]

Shift LEFT, starting from the LEFT (index 1 onwards):

   i=1: arr[1] = arr[2]  ->  [10, 30, 30, 40, 50]
   i=2: arr[2] = arr[3]  ->  [10, 30, 40, 40, 50]
   i=3: arr[3] = arr[4]  ->  [10, 30, 40, 50, 50]
                                              ^ stale duplicate

   size-- -> 4. Logically the array is [10, 30, 40, 50].
   The stale 50 at index 4 is beyond size, so it's invisible.
```

**For object arrays, you must null the trailing slot:**
```java
arr[--size] = null;   // else the array keeps a strong reference -> memory leak
```
This is a real bug class. `java.util.ArrayList.remove()` does exactly this — go read the JDK source, it's four lines and instructive.

## 2.5 Java Implementation — a production-quality dynamic array

We'll build our own `ArrayList` from scratch. Nothing teaches arrays like implementing the thing that wraps them.

```java
package com.dsa.arrays;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * A growable array of ints, built from first principles.
 * Uses int[] rather than Integer[] to avoid boxing overhead.
 */
public final class IntDynamicArray implements Iterable<Integer> {

    private static final int DEFAULT_CAPACITY = 10;
    private static final int MAX_CAPACITY = Integer.MAX_VALUE - 8;

    private int[] data;
    private int size;

    public IntDynamicArray() {
        this(DEFAULT_CAPACITY);
    }

    public IntDynamicArray(int initialCapacity) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("capacity must be >= 0: " + initialCapacity);
        }
        this.data = new int[initialCapacity];
        this.size = 0;
    }

    // ---------- O(1) operations ----------

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int get(int index) {
        checkIndex(index);
        return data[index];
    }

    public int set(int index, int value) {
        checkIndex(index);
        int old = data[index];
        data[index] = value;
        return old;
    }

    // ---------- amortized O(1) ----------

    public void add(int value) {
        ensureCapacity(size + 1);
        data[size++] = value;
    }

    // ---------- O(n) operations ----------

    public void add(int index, int value) {
        if (index < 0 || index > size) {                 // note: index == size is legal
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
        ensureCapacity(size + 1);
        System.arraycopy(data, index, data, index + 1, size - index);
        data[index] = value;
        size++;
    }

    public int removeAt(int index) {
        checkIndex(index);
        int removed = data[index];
        int elementsAfter = size - index - 1;
        if (elementsAfter > 0) {
            System.arraycopy(data, index + 1, data, index, elementsAfter);
        }
        size--;
        return removed;
    }

    public int indexOf(int value) {
        for (int i = 0; i < size; i++) {
            if (data[i] == value) return i;
        }
        return -1;
    }

    public boolean contains(int value) {
        return indexOf(value) >= 0;
    }

    // ---------- internals ----------

    private void ensureCapacity(int required) {
        if (required <= data.length) return;
        int oldCap = data.length;
        int newCap = oldCap + (oldCap >> 1);            // 1.5x growth
        if (newCap < required) newCap = required;       // handles oldCap 0 and 1
        if (newCap > MAX_CAPACITY) {
            if (required > MAX_CAPACITY) throw new OutOfMemoryError("array too large");
            newCap = MAX_CAPACITY;
        }
        data = Arrays.copyOf(data, newCap);
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
    }

    public int[] toArray() {
        return Arrays.copyOf(data, size);
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<>() {
            private int cursor = 0;
            @Override public boolean hasNext() { return cursor < size; }
            @Override public Integer next() {
                if (cursor >= size) throw new NoSuchElementException();
                return data[cursor++];
            }
        };
    }

    @Override
    public String toString() {
        if (size == 0) return "[]";
        StringBuilder sb = new StringBuilder(size * 4);
        sb.append('[');
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i < size - 1) sb.append(", ");
        }
        return sb.append(']').toString();
    }
}
```

## 2.6 Line-by-Line Code Explanation

Now I explain the choices, because *why* is the part you'll be asked about.

**`private static final int DEFAULT_CAPACITY = 10;`**
`static` → one copy for the whole class, not per instance. `final` → compile-time constant, so the JIT inlines the literal 10 with zero runtime cost. Ten is what the JDK uses; it's an empirical compromise between wasting memory on tiny lists and resizing immediately.

**`private static final int MAX_CAPACITY = Integer.MAX_VALUE - 8;`**
Why minus 8? Because the array **object header** takes bytes too, and some JVMs reserve a few words. Requesting exactly `Integer.MAX_VALUE` elements can throw `OutOfMemoryError: Requested array size exceeds VM limit`. The JDK uses this exact constant. Reproducing it signals you've read the JDK source.

**`private int[] data;`**
The backing store. `int[]`, not `Integer[]` — deliberately. `Integer[]` would mean every element is a separate heap object with a 16-byte header for 4 bytes of payload (a 5× memory blowup) plus a pointer dereference per access. For a numeric collection that's indefensible.

**`private int size;`**
The crucial invariant: **`size` is the number of live elements; `data.length` is the allocated room.** These are different numbers and confusing them is the #1 source of bugs in this class. Slots `[size, data.length)` are allocated but logically empty.

```
   data.length = 10  (capacity)
   size = 4          (live elements)

   +----+----+----+----+----+----+----+----+----+----+
   | 10 | 20 | 30 | 40 |  0 |  0 |  0 |  0 |  0 |  0 |
   +----+----+----+----+----+----+----+----+----+----+
   <---- live (size) --->|<------- allocated but dead ------>
```

**`public IntDynamicArray() { this(DEFAULT_CAPACITY); }`**
Constructor chaining via `this(...)`. One place initialises fields → no duplicated logic, no divergence between constructors.

**`if (initialCapacity < 0) throw new IllegalArgumentException(...)`**
**Fail fast.** A negative capacity is a programming error; surfacing it at the point of the mistake with the offending value in the message saves hours of debugging. Notice the message *includes the bad value*. Always include the value.

**`public int get(int index) { checkIndex(index); return data[index]; }`**
Two lines, both O(1). `checkIndex` guards against `index >= size` — because `data[7]` might be a legal *array* access (capacity 10) while being an illegal *list* access (size 4). Without our check the caller would silently read a stale 0. **The class must enforce its own invariant, not lean on the JVM's array bounds check**, because the two boundaries are in different places.

**`public void add(int value) { ensureCapacity(size + 1); data[size++] = value; }`**
`data[size++] = value` is the classic idiom. Post-increment: use the current `size` as the write index, *then* increment. Equivalent to `data[size] = value; size = size + 1;`. Amortized O(1) per §1.4.

**`if (index < 0 || index > size)` in `add(int, int)`**
Note `> size`, not `>= size`. Inserting *at* `size` means appending, which is legal. Compare with `checkIndex`, which uses `>= size` because reading at `size` is not legal. **These two boundary conditions are genuinely different and this is the exact spot where beginners write a bug.** Say it out loud: "for insertion, index == size is valid; for access, it is not."

**`System.arraycopy(data, index, data, index + 1, size - index);`**
The most important line in the file. Signature: `arraycopy(src, srcPos, dest, destPos, length)`. Here src and dest are the *same array* — a self-overlapping copy.

```
   size = 4, insert at index = 1, so we move (4 - 1) = 3 elements

   Before:  [ 10 | 20 | 30 | 40 | __ ]
                    |    |    |
                    +----+----+---> shifted one slot right
   After :  [ 10 | 20 | 20 | 30 | 40 ]
                    ^ about to be overwritten with the new value
```

`System.arraycopy` is a JVM **intrinsic** — the JIT replaces it with an optimised `memmove`, often using SIMD vector instructions. It is dramatically faster than a hand-written loop and, critically, **it handles overlapping ranges correctly** (it internally picks the right copy direction, solving the §2.4 problem for you). Still O(n), but with a tiny constant. In interviews, writing the manual loop shows you understand the mechanism; writing `arraycopy` shows you know the platform. Ideally, write `arraycopy` and *explain* the manual loop.

**`ensureCapacity`, line by line — this is the heart of the class:**

```java
if (required <= data.length) return;     // fast path: 99% of adds exit here
```
A single comparison in the common case. This is why `add` is amortized O(1): almost every call does one compare and one write.

```java
int newCap = oldCap + (oldCap >> 1);     // oldCap * 1.5
```
`oldCap >> 1` is `oldCap / 2` via bit shift. Why 1.5× and not 2×?
- **Time:** any multiplicative factor gives amortized O(1) (§1.4). Both work.
- **Memory:** 2× can waste up to 50% of allocated space; 1.5× wastes at most 33%.
- **Allocator reuse:** with 2× growth, the sum of all previously freed blocks (`n/2 + n/4 + ... < n`) is *always smaller* than the next request, so freed memory can never be reused for the new array. With 1.5×, freed blocks eventually do add up to enough. This is a real, documented reason Facebook's `folly::fbvector` and the JDK both chose 1.5×.

```java
if (newCap < required) newCap = required;
```
Guards `oldCap == 0` (where `0 + 0 = 0`, an infinite loop) and `oldCap == 1` (where `1 + 0 = 1`, no growth). Also handles bulk-add requests that jump past 1.5×. **This line is easy to omit and produces an infinite loop when you do.**

```java
data = Arrays.copyOf(data, newCap);
```
Allocates a new array of `newCap`, copies the old contents in (via `arraycopy` internally), zero-fills the tail, and reassigns `data`. The old array is now unreachable → **eligible for garbage collection**. Note the transient memory spike: for a moment both arrays are live, so growing a 1 GB list momentarily needs 2.5 GB. That's a real production consideration.

**`public int[] toArray() { return Arrays.copyOf(data, size); }`**
Returns a **defensive copy**, trimmed to `size`. Returning `data` directly would (a) leak the internal array so callers could corrupt our state, and (b) expose the dead slots past `size`. Encapsulation is not decoration; here it prevents an entire bug class.

**The anonymous `Iterator<>` with a diamond**
Java 9+ allows `new Iterator<>() { ... }` on anonymous classes — the type is inferred. The inner class captures `IntDynamicArray.this` implicitly, so it reads the live `size` and `data` fields. That's what makes `for (int x : myArray)` work. (A production version would track a `modCount` and throw `ConcurrentModificationException` on structural modification during iteration — exactly what `ArrayList` does.)

**`new StringBuilder(size * 4)` in `toString`**
Pre-sizing the builder to a good estimate avoids internal resizes. And using `StringBuilder` at all rather than `+=` avoids the O(n²) trap of §1.5 Example H.

## 2.7 Complexity Analysis

| Operation | Time | Why |
|---|---|---|
| `get(i)` / `set(i, v)` | **O(1)** | Address arithmetic: `base + i × 4`. No scanning. |
| `add(v)` (append) | **Amortized O(1)** | Usually one write. Occasionally an O(n) copy, but geometric growth means total copy work over n adds is < 3n (§1.4). |
| `add(i, v)` | **O(n)** | Must shift `size - i` elements right. Worst case i=0 → n moves. |
| `removeAt(i)` | **O(n)** | Must shift `size - i - 1` elements left. Worst case i=0 → n-1 moves. |
| `removeAt(size-1)` | **O(1)** | `elementsAfter == 0`, so `arraycopy` is skipped entirely. |
| `indexOf(v)` / `contains(v)` | **O(n)** | Unsorted data offers no shortcut — must inspect every element. |
| Space | **O(n)** | Between n and 1.5n slots. |

**The one-sentence summary to say in interviews:** *"Arrays give O(1) random access and O(1) amortized append, at the cost of O(n) middle insertion and O(n) worst-case memory copying on growth."*

## 2.8 Common Mistakes

**1. `<=` in the loop condition**
```java
for (int i = 0; i <= arr.length; i++)   // ArrayIndexOutOfBoundsException
```
Length 5 → valid indices 0..4. Use `<`. Burn this in.

**2. `arr.length()` vs `arr.length`**
Arrays: `arr.length` (field, no parens). Strings: `s.length()` (method). Collections: `list.size()`. Three different spellings for the same idea — a genuine Java wart. Memorise it.

**3. Shifting in the wrong direction** — §2.4. Destroys data silently, which is worse than crashing.

**4. Confusing `size` with `capacity`** — the invariant from §2.6. Iterating to `data.length` instead of `size` exposes dead zeros.

**5. `Arrays.asList` on a primitive array**
```java
int[] a = {1, 2, 3};
List<int[]> wrong = Arrays.asList(a);   // a List with ONE element: the array itself!
```
Generics don't accept primitives, so `int[]` is treated as a single object. Fix: `Arrays.stream(a).boxed().toList()`.

**6. Assuming `Arrays.asList` is mutable**
```java
List<String> l = Arrays.asList("a", "b");
l.add("c");    // UnsupportedOperationException
```
It's a fixed-size **view** over the array. `l.set(0, "z")` works; `add`/`remove` don't. Use `new ArrayList<>(Arrays.asList(...))` for a real list.

**7. Shallow copy of a 2D array**
```java
int[][] copy = original.clone();          // copies the OUTER array of references only
copy[0][0] = 99;                          // MUTATES original[0][0] too!
```
The rows are shared. For a deep copy:
```java
int[][] deep = new int[original.length][];
for (int i = 0; i < original.length; i++) {
    deep[i] = original[i].clone();
}
```
This bug is a favourite in DP and grid interview questions.

**8. `==` on arrays**
```java
int[] a = {1,2,3}, b = {1,2,3};
a == b               // false  (different objects)
a.equals(b)          // false  (Object.equals -> identity!)
Arrays.equals(a, b)  // true   <- the right answer
Arrays.deepEquals(x, y)  // for 2D+
```

## 2.9 Interview Perspective

Arrays are the most-tested topic in existence, because everything reduces to them. Interviewers use array problems to probe four specific things:

**(a) Do you handle edge cases without being asked?** `null` array, length 0, length 1, all-identical elements, all-negative values, integer overflow. **Say them out loud before coding.** "Let me confirm: can the array be null or empty? Can values be negative? Could the sum overflow int?" Three questions, and you've already outperformed most candidates.

**(b) Can you get to O(1) extra space?** Half of array problems have an in-place solution and interviewers wait for you to find it. If you used a `HashMap`, the follow-up will be "now do it with O(1) space."

**(c) Do you know the standard toolkit?** Given an array problem, run through this checklist mentally:
```
  Sorted?          -> binary search, two pointers
  Contiguous range? -> sliding window
  Range sums?      -> prefix sum
  Need extremes?   -> heap
  Need counts?     -> HashMap / frequency array
  Need previous
  greater/smaller? -> monotonic stack
  Values bounded
  by n?            -> index-as-hash (cyclic sort, negative marking)
```
That checklist covers roughly 80% of array interview questions. Practise running it in 15 seconds.

**(d) The "values are 1..n" superpower.** If an array of length `n` contains values in the range `1..n`, you can use **the array itself as a hash table** — because there's a natural bijection between values and indices. This unlocks O(1)-space solutions to "find the missing number", "find the duplicate", "first missing positive". We'll use it in the Hard problem below. Recognising this pattern is worth memorising as a single rule:

> **Values in range 1..n + O(1) space required → index-as-hash. Either sort by placing value v at index v-1, or mark visited by negating.**

## 2.10 Practice Problems

### Easy — Remove Duplicates from Sorted Array
Given a **sorted** `int[] nums`, remove duplicates **in place** so each element appears once. Return the new length. Elements beyond the returned length don't matter. O(1) extra space.
```
Input:  [0,0,1,1,1,2,2,3,3,4]
Output: 5, nums begins [0,1,2,3,4,...]
```

### Medium — Rotate Array by k
Rotate `int[] nums` right by `k` steps, **in place**, O(1) extra space.
```
Input:  [1,2,3,4,5,6,7], k = 3
Output: [5,6,7,1,2,3,4]
```

### Hard — First Missing Positive
Given an unsorted `int[] nums`, find the smallest **positive** integer not present. Must be **O(n) time and O(1) extra space.**
```
[1,2,0]        -> 3
[3,4,-1,1]     -> 2
[7,8,9,11,12]  -> 1
```

## 2.11 Solution Walkthrough

### Easy — Remove Duplicates

**The insight.** Maintain **two pointers with different jobs.** This is the "slow/fast" or "read/write" pattern and it appears everywhere.

- `write` — the index where the next unique element belongs. Everything left of it is finished and correct.
- `read` — scans forward, looking for something new.

Because the array is sorted, duplicates are adjacent. So "is this new?" reduces to "is it different from the last thing I wrote?" — a single comparison, no set needed.

```java
public int removeDuplicates(int[] nums) {
    if (nums == null || nums.length == 0) return 0;

    int write = 1;                                  // nums[0] is always unique
    for (int read = 1; read < nums.length; read++) {
        if (nums[read] != nums[write - 1]) {        // found something new
            nums[write] = nums[read];
            write++;
        }
    }
    return write;
}
```

**Dry run on `[0,0,1,1,2]`.** Trace this with your finger.

```
Initial:  [0, 0, 1, 1, 2]    write=1
           w
           r(next)

read=1: nums[1]=0, nums[write-1]=nums[0]=0.  0 == 0  -> duplicate, SKIP
        [0, 0, 1, 1, 2]      write=1  (unchanged)
            ^r

read=2: nums[2]=1, nums[0]=0.  1 != 0  -> NEW
        write nums[1] = 1, write -> 2
        [0, 1, 1, 1, 2]      write=2
            ^ overwritten     ^r
        (finished region: [0,1])

read=3: nums[3]=1, nums[write-1]=nums[1]=1.  1 == 1 -> duplicate, SKIP
        [0, 1, 1, 1, 2]      write=2
               ^r

read=4: nums[4]=2, nums[1]=1.  2 != 1 -> NEW
        write nums[2] = 2, write -> 3
        [0, 1, 2, 1, 2]      write=3
               ^                  ^r
        (finished region: [0,1,2])

Loop ends. Return 3. First 3 elements are [0,1,2]. Correct.
```

**Why `nums[write - 1]` and not `nums[read - 1]`?** Because `nums[read - 1]` may have been overwritten by our own writes. `nums[write - 1]` is always the last element we *committed*, which is exactly the correct comparison target. Getting this wrong is the standard bug here — and it only shows up on inputs with 3+ consecutive duplicates, so it passes naive testing.

**Complexity:** O(n) time (single pass, each element examined once), **O(1) space** (two ints). The `write` pointer never overtakes `read`, so we never clobber unread data — that's the safety proof of this pattern.

### Medium — Rotate Array by k

**The naive approaches and why they fail:**
- Rotate one step, k times → O(n·k). With n = 10⁵ and k = 10⁵ that's 10¹⁰. Dead.
- Copy into a new array at `(i + k) % n` → O(n) time but O(n) space. Violates the constraint.

**The elegant answer: three reversals.** Watch this — it's genuinely beautiful.

```
Original:                [1, 2, 3, 4, 5, 6, 7]   k = 3

Step 1 - reverse WHOLE array:
                         [7, 6, 5, 4, 3, 2, 1]

   Now the last 3 elements are at the front — correct group, wrong internal order.
   And the first 4 are at the back — also correct group, wrong internal order.

Step 2 - reverse first k = 3:
                         [5, 6, 7, 4, 3, 2, 1]
                          ^^^^^^^ fixed

Step 3 - reverse remaining n - k = 4:
                         [5, 6, 7, 1, 2, 3, 4]
                                   ^^^^^^^^^^ fixed

   Answer. Three linear passes, zero extra space.
```

**Why does this work?** Reversing the whole array puts both blocks in the right *place* but internally backwards. Reversing each block individually un-backwards them. In algebraic terms: for blocks A and B, `reverse(reverse(A) + reverse(B))` — read right to left — equals `B + A`. Rotation *is* block swapping, and reversal is how you swap blocks without extra memory.

```java
public void rotate(int[] nums, int k) {
    if (nums == null || nums.length <= 1) return;
    int n = nums.length;
    k = k % n;                          // k=10, n=7 -> k=3. Essential.
    if (k == 0) return;

    reverse(nums, 0, n - 1);            // whole
    reverse(nums, 0, k - 1);            // first k
    reverse(nums, k, n - 1);            // rest
}

private void reverse(int[] a, int lo, int hi) {
    while (lo < hi) {
        int tmp = a[lo];
        a[lo] = a[hi];
        a[hi] = tmp;
        lo++;
        hi--;
    }
}
```

**Line notes:**

`k = k % n;` — **non-negotiable.** Rotating by n is the identity, so only `k mod n` matters. Without this, `k = 10, n = 7` makes `reverse(nums, 0, 9)` read out of bounds. This single line is the most common failure in this problem.

`if (k == 0) return;` — after the modulo, `k` may be 0, and `reverse(nums, 0, -1)` would be a no-op anyway (since `0 < -1` is false), but returning early is clearer and documents the intent.

`while (lo < hi)` — strictly less-than. When `lo == hi` (odd-length middle element) there's nothing to swap; `<=` would swap the element with itself, which is harmless but wasteful and signals fuzzy thinking.

**Complexity:** three reversals each touching at most n elements → O(n) time. Each element is moved exactly twice total. **O(1) space** — one `tmp` int. 

**Interview note:** if asked for an alternative, the cyclic-replacement method also achieves O(n)/O(1) using GCD cycle counting. Mention it exists but that reversal is preferred because it's far harder to get wrong. Choosing the more robust of two equally optimal algorithms is a senior signal.

### Hard — First Missing Positive

**Start by bounding the answer** — this is the reasoning step interviewers want to see.

Array has `n` elements. The answer is a positive integer. In the best case for "large answers", the array is exactly `[1, 2, 3, ..., n]` and the answer is `n + 1`. There is no way to force the answer higher, because you'd need all of 1..n+1 present, which needs n+1 slots.

> **Therefore the answer is always in the range `[1, n+1]`.**

That's the whole problem. Values outside `1..n` (negatives, zeros, huge numbers) are **irrelevant noise**. We only need to know, for each `v` in `1..n`, whether `v` is present.

Normally you'd use a boolean array of size n+1 — but that's O(n) space. So: **use the array itself as the hash table** (the §2.9 superpower). Put value `v` at index `v - 1`:

```
   Desired state:  value 1 -> index 0
                   value 2 -> index 1
                   value v -> index v-1
```

Then one final scan: the first index `i` where `nums[i] != i + 1` tells us `i + 1` is missing.

```java
public int firstMissingPositive(int[] nums) {
    if (nums == null || nums.length == 0) return 1;
    int n = nums.length;

    // Phase 1: place each value v in [1, n] at index v-1
    for (int i = 0; i < n; i++) {
        while (nums[i] > 0 && nums[i] <= n && nums[nums[i] - 1] != nums[i]) {
            int target = nums[i] - 1;
            int tmp = nums[target];
            nums[target] = nums[i];
            nums[i] = tmp;
        }
    }

    // Phase 2: find the first index whose value is wrong
    for (int i = 0; i < n; i++) {
        if (nums[i] != i + 1) return i + 1;
    }
    return n + 1;                          // array was exactly [1..n]
}
```

**Dry run on `[3, 4, -1, 1]`,** n = 4. Follow closely — the `while` is the tricky part.

```
Start: [3, 4, -1, 1]

i=0: nums[0]=3. In [1,4]? yes. Target index = 3-1 = 2. nums[2] = -1.
     Is nums[2] != nums[0]?  -1 != 3  -> yes, swap needed.
     Swap positions 0 and 2:
     [-1, 4, 3, 1]
      ^^      ^^  3 has reached its home (index 2). Correct.

     while re-checks nums[0], which is now -1.
     -1 > 0? NO -> while exits.

i=1: nums[1]=4. In [1,4]? yes. Target = 4-1 = 3. nums[3] = 1.
     1 != 4 -> swap positions 1 and 3:
     [-1, 1, 3, 4]
         ^^     ^^  4 is home (index 3). Correct.

     while re-checks nums[1], now 1.
     1 in [1,4]? yes. Target = 0. nums[0] = -1. -1 != 1 -> swap 1 and 0:
     [1, -1, 3, 4]
      ^^ ^^^  1 is home (index 0). Correct.

     while re-checks nums[1], now -1. Not > 0 -> exit.

i=2: nums[2]=3. Target = 2. nums[2] == nums[2] -> already home -> exit immediately.
i=3: nums[3]=4. Target = 3. Already home -> exit.

Phase 1 result: [1, -1, 3, 4]

Phase 2:
  i=0: nums[0]=1, want 1. OK.
  i=1: nums[1]=-1, want 2. MISMATCH -> return 2.

Answer: 2. Correct.
```

**The three critical details:**

**1. Why `while` and not `if`?** After a swap, index `i` holds a *brand new* value that might itself belong elsewhere. In the dry run, `i=1` needed two swaps in a row. An `if` would place only one value per iteration and silently miss elements.

**2. Why the condition `nums[nums[i] - 1] != nums[i]` and not `nums[nums[i]-1] != nums[i]` expressed as "target is empty"?** Two reasons, both essential:
- It's the **duplicate guard**. Given `[1, 1]`: at i=1, `nums[1]=1`, target index 0 already holds 1. Since `nums[0] == nums[1]`, we skip. Without this check we'd swap 1 with 1 forever → **infinite loop**. This is *the* bug in this problem.
- It's also the "already correct" check, letting us skip work.

**3. Why is this O(n) when there's a loop inside a loop?** This is the question that separates a correct answer from a *convincing* answer. Use an **amortized argument** (§1.4):

> Every swap places at least one value into its permanently correct home. Once a value is home, it is never moved again. There are only `n` positions, so **across the entire run, at most `n` swaps can ever occur.** The outer loop contributes n iterations, and the inner `while` contributes at most n swaps *in total across all i* — not n per i. Total work: O(n) + O(n) = **O(n)**.

Say that out loud in an interview and you have demonstrated that you can reason about amortized complexity in a non-obvious setting, which is exactly what Module 1 was preparing you for.

**Complexity:** **O(n) time, O(1) space.** Two passes plus at most n swaps.

**The generalisable takeaway.** Whenever you see *"O(1) space"* + *"values relate to indices"*, reach for index-as-hash. Its two forms:
- **Cyclic sort** (used here) — physically move `v` to index `v-1`.
- **Negative marking** — visit index `|v|-1` and negate it as a "seen" flag. Non-destructive to magnitudes, and works when you must preserve values.

Both give O(1) space by storing bookkeeping inside the input.

---
---
# MODULE 3 — Strings

## 3.1 Intuition

A Java `String` is **an immutable, read-only array of characters wearing a nice coat.**

Two words in that sentence do all the work: **array** and **immutable**.

**"Array"** means everything you learned in Module 2 applies. `charAt(i)` is O(1) address arithmetic. Scanning is O(n). There's a `length` known upfront.

**"Immutable"** means once created, the contents can **never** change. Not "shouldn't". *Cannot.* There is no method on `String` that modifies it. `toUpperCase()`, `trim()`, `replace()`, `substring()` — every one of them returns a **brand new String** and leaves the original untouched.

```java
String s = "hello";
s.toUpperCase();          // returns "HELLO" — and we THREW IT AWAY
System.out.println(s);    // "hello"  <- unchanged. Beginners find this shocking.

s = s.toUpperCase();      // now s REFERENCES the new object
System.out.println(s);    // "HELLO"
```

Notice what the second version actually does. It didn't change the string. It changed **which string `s` points at**. The old `"hello"` object still exists (in the string pool, in fact) — `s` just stopped looking at it.

```
   BEFORE  s = s.toUpperCase()

   s ---------> ["h","e","l","l","o"]      (immutable object A)

   DURING: toUpperCase() allocates a whole new object

   s ---------> ["h","e","l","l","o"]      (object A, untouched)
                ["H","E","L","L","O"]      (object B, freshly allocated)

   AFTER: the assignment repoints the reference

   s -----+     ["h","e","l","l","o"]      (object A — now maybe unreferenced)
          |
          +---> ["H","E","L","L","O"]      (object B)
```

**Why on earth would Java do this?** Four excellent reasons:

1. **Thread safety for free.** An immutable object can be shared across any number of threads with zero locking. Nothing can change, so nothing can race.
2. **Safe caching of the hash code.** `String.hashCode()` is computed once and stored in a field. This is why `HashMap<String, V>` is fast — the key's hash is already sitting there. A mutable key would invalidate its own hash bucket.
3. **Interning / the string pool.** Because contents can't change, identical literals can safely share one object (§3.3).
4. **Security.** If `String` were mutable, a malicious thread could change a filename or SQL query *after* it was validated but *before* it was used. That's a real attack class, eliminated by design.

**And the cost.** Every "modification" allocates. Which produces the single most common Java performance bug in the world:

```java
String s = "";
for (int i = 0; i < n; i++) s += "x";     // O(n²). See §1.5 Example H.
```

Understanding *why* that's O(n²) — and reflexively reaching for `StringBuilder` — is the practical payoff of this module.

## 3.2 Mental Model

**Model 1 — "String is a `final char[]` I can read but not write."**

(Since Java 9 it's actually a `byte[]` plus a coder flag — see §3.3 — but the mental model holds.)

**Model 2 — "Every String method that sounds like a mutation is actually a constructor."**

Rewrite them in your head:
- `s.trim()` → `new String(s without edge whitespace)`
- `s.replace('a','b')` → `new String(s with a→b)`
- `s.substring(2,5)` → `new String(s[2..5))`

Once you read them as allocations, you naturally start asking "am I allocating inside a loop?" — which is the right question.

**Model 3 — "For any building or repeated editing, leave `String` immediately."**

```
   Reading / comparing / passing around  ->  String
   Building character by character       ->  StringBuilder
   Building across threads               ->  StringBuffer (synchronized, rarely needed)
   Heavy char math / in-place algorithms ->  char[]  (via s.toCharArray())
```

Choosing correctly among those four is 90% of practical Java string competence.

## 3.3 Internal Working

### The modern String layout (Java 9+: Compact Strings)

Before Java 9, `String` held a `char[]`, and a Java `char` is **2 bytes** (UTF-16). So `"hello"` used 10 bytes of payload — even though every character fits in one byte. Studies at Oracle found most heap strings were pure Latin-1, meaning **half of all string memory in the average Java heap was zero bytes.**

Java 9 introduced **Compact Strings** (JEP 254):

```java
public final class String {
    private final byte[] value;   // <- byte[], not char[]
    private final byte coder;     // 0 = LATIN1 (1 byte/char), 1 = UTF16 (2 bytes/char)
    private int hash;             // cached; 0 means "not yet computed"
}
```

```
   "hello"  (all chars < 256)          "héllo₹"  (contains a non-Latin-1 char)
   coder = LATIN1                      coder = UTF16
   +---+---+---+---+---+               +---+---+ +---+---+ +---+---+ ...
   | h | e | l | l | o |               | 00| h | | 00| é | | 00| l |
   +---+---+---+---+---+               +---+---+ +---+---+ +---+---+
   5 bytes                             12 bytes (2 per char)
```

Real consequences:
- Typical Java applications saw **10–15% heap reduction** for free on upgrading to Java 9. This is one of the highest-impact JVM changes ever shipped.
- `charAt(i)` must branch on `coder`, but the JIT makes this essentially free.
- **`String.length()` returns the number of UTF-16 code units, not the number of visible characters.** An emoji like 😀 is a *surrogate pair* — 2 code units — so `"😀".length() == 2`. Use `s.codePointCount(0, s.length())` for actual character count. **Interviewers at companies with international products ask about this.**

### `hash` is lazily computed and cached

```java
public int hashCode() {
    int h = hash;
    if (h == 0 && !hashIsZero) {
        h = isLatin1() ? StringLatin1.hashCode(value) : StringUTF16.hashCode(value);
        hash = h;
    }
    return h;
}
```
The formula is `s[0]*31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]`. Computed **once**, then cached forever — legal only because the object is immutable. First `hashCode()` is O(n); every subsequent call is O(1). This is precisely why `String` is the ideal `HashMap` key.

(Why 31? It's an odd prime, `31 * x` compiles to the fast `(x << 5) - x`, and it empirically distributes English text well.)

### The String Pool — and the `==` trap

The JVM keeps a **string pool** (in the heap since Java 7) holding one canonical instance of each string *literal*.

```java
String a = "hello";                    // literal -> goes to the pool
String b = "hello";                    // literal -> finds the SAME pooled object
String c = new String("hello");        // 'new' FORCES a fresh heap object
String d = c.intern();                 // returns the pooled instance

a == b        // true   (same pooled object)
a == c        // FALSE  (different objects!)
a.equals(c)   // true   (same contents)
a == d        // true   (intern() returned the pooled one)
```

```
                  STRING POOL (in heap)
                 +----------------------+
   a ----------->|      "hello"         |<---------- b
                 +----------------------+<---------- d
                          ^
                          | intern()
                 REGULAR HEAP
                 +----------------------+
   c ----------->|      "hello"         |   separate object, same contents
                 +----------------------+
```

> **The rule, no exceptions: compare strings with `.equals()`, never with `==`.**

`==` compares references — *are these the same object?* `.equals()` compares contents — *do these say the same thing?* The reason `==` sometimes appears to work is the pool, and that's a trap: your code passes tests with literals and fails in production the moment a string arrives from a file, a socket, a database, or `Scanner`. **Never use `==` on strings.** Use `equals()`, or `Objects.equals(a, b)` when either may be null.

**Compile-time concatenation of literals is folded:**
```java
String x = "he" + "llo";     // compiler folds to the literal "hello" -> pooled
x == a                       // true

String part = "he";
String y = part + "llo";     // runtime concat -> new object
y == a                       // false
```
This distinction is a classic interview question, and the answer is "constant folding happens at compile time; runtime concatenation allocates."

### What `s += "x"` actually compiles to

```java
s += "x";
```
Java has no operator overloading, so the compiler rewrites this. On modern javac it becomes an invokedynamic call to `StringConcatFactory`, but semantically it is:

```java
s = new StringBuilder().append(s).append("x").toString();
```

Read that carefully and the O(n²) becomes obvious. Every iteration:
1. allocates a fresh `StringBuilder`,
2. copies **all `i` existing characters** into it,
3. appends one char,
4. calls `toString()`, which **copies everything again** into a new String,
5. abandons the builder and the old string as garbage.

```
   Iteration:   1    2    3    4    ...    n
   Chars copied: 1    2    3    4    ...    n
   Total = 1+2+3+...+n = n(n+1)/2 = O(n²)

   Objects allocated: 2 per iteration = 2n objects of average size n/2
   -> O(n²) bytes of garbage churned through the GC
```

For n = 100,000 that's ~5 billion character copies and gigabytes of garbage. It will take minutes. `StringBuilder` does the same job in milliseconds.

### `StringBuilder` — the mutable counterpart

```java
public final class StringBuilder extends AbstractStringBuilder {
    byte[] value;      // NOT final — this is the point
    int count;         // number of chars actually used
    byte coder;
}
```

It is exactly the dynamic array from Module 2, specialised for characters:

```
   capacity = 16 (default), count = 5

   +---+---+---+---+---+---+---+---+ ... +
   | h | e | l | l | o |   |   |   | ... |
   +---+---+---+---+---+---+---+---+ ... +
   <---- count ---->|<---- spare room ---->

   append('!') -> write at index 5, count -> 6.  O(1) amortized.
   When full   -> grow to (2 × old + 2), copy across. Amortized O(1) overall.
```

Note the growth rule: **`newCapacity = 2 * oldCapacity + 2`**. The `+2` guarantees growth from capacity 0. Multiplicative → geometric series → amortized O(1) (§1.4).

`toString()` copies the used region into a new immutable String — **one O(n) copy at the end**, instead of one per iteration.

```
   Building an n-character string:

   s += "x"  in a loop   ->  O(n²) time, O(n²) garbage
   sb.append in a loop   ->  O(n)  time, O(n)  memory
```

### `substring` — and a piece of history worth knowing

**Before Java 7u6**, `substring` was O(1): it created a String sharing the *same* backing array with an offset and count. Fast — but it caused a notorious memory leak:

```java
String huge = readFile();          // 100 MB string
String tiny = huge.substring(0, 5);
// huge is now unreachable, BUT tiny holds its 100 MB array alive!
```

**Since Java 7u6**, `substring` **copies**, making it **O(k)** where k is the substring length. Slower per call, but no leak and no surprise retention.

The interview-relevant consequence:

```java
// O(n²) — allocates and copies a new string on EVERY iteration
for (int i = 0; i < s.length(); i++) {
    process(s.substring(i, i + 3));
}

// O(n) — no allocation, just index arithmetic
for (int i = 0; i + 3 <= s.length(); i++) {
    process(s, i, i + 3);           // pass indices, not copies
}
```

> **Rule: `substring` inside a loop is a code smell. Pass indices instead.** State this in an interview when you avoid a substring and you'll get credit for it.

## 3.4 Java Implementation — core string utilities

Let's implement the operations that appear constantly, with real care.

```java
package com.dsa.strings;

public final class StringOps {

    private StringOps() { }   // utility class: prevent instantiation

    /** Reverses a string. O(n) time, O(n) space. */
    public static String reverse(String s) {
        if (s == null || s.length() <= 1) return s;
        char[] c = s.toCharArray();
        int lo = 0, hi = c.length - 1;
        while (lo < hi) {
            char tmp = c[lo];
            c[lo++] = c[hi];
            c[hi--] = tmp;
        }
        return new String(c);
    }

    /** Palindrome check ignoring non-alphanumerics and case. O(n) time, O(1) space. */
    public static boolean isPalindrome(String s) {
        if (s == null) return false;
        int lo = 0, hi = s.length() - 1;
        while (lo < hi) {
            while (lo < hi && !Character.isLetterOrDigit(s.charAt(lo)))  lo++;
            while (lo < hi && !Character.isLetterOrDigit(s.charAt(hi)))  hi--;
            if (Character.toLowerCase(s.charAt(lo)) != Character.toLowerCase(s.charAt(hi))) {
                return false;
            }
            lo++;
            hi--;
        }
        return true;
    }

    /** Anagram check for ASCII lowercase input. O(n) time, O(1) space. */
    public static boolean isAnagram(String a, String b) {
        if (a == null || b == null) return a == b;
        if (a.length() != b.length()) return false;          // cheap early exit

        int[] freq = new int[26];
        for (int i = 0; i < a.length(); i++) {
            freq[a.charAt(i) - 'a']++;
            freq[b.charAt(i) - 'a']--;                       // one pass, both strings
        }
        for (int f : freq) {
            if (f != 0) return false;
        }
        return true;
    }

    /** Frequency map for full Unicode-agnostic ASCII. O(n) time, O(1) space. */
    public static int[] asciiFrequency(String s) {
        int[] freq = new int[128];
        for (int i = 0; i < s.length(); i++) {
            freq[s.charAt(i)]++;
        }
        return freq;
    }

    /** Efficient repeat without O(n^2) concatenation. */
    public static String repeat(String unit, int times) {
        if (times <= 0 || unit == null || unit.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(unit.length() * times);   // pre-sized
        for (int i = 0; i < times; i++) {
            sb.append(unit);
        }
        return sb.toString();
    }
}
```

## 3.5 Line-by-Line Code Explanation

**`private StringOps() { }`**
A private constructor on a class of static methods. Prevents `new StringOps()`, which would be meaningless. Standard practice — see `java.util.Arrays` and `java.util.Collections`, both of which do exactly this.

**`char[] c = s.toCharArray();`**
Allocates an `n`-element `char[]` and copies. This is where the O(n) space in `reverse` comes from, and it's **unavoidable**: `String` is immutable, so we cannot reverse in place. If an interviewer says "reverse a string in O(1) space", the honest answer is "impossible for `String` in Java; possible for a `char[]`, which is what I'd ask for."

**`c[lo++] = c[hi];` then `c[hi--] = tmp;`**
Compressed but standard. `c[lo++] = c[hi]` means: write to index `lo`, *then* increment `lo`. Combining the swap with pointer movement is idiomatic; just be sure the read of `c[hi]` happens before `c[hi--]` writes to it — which it does, because the statements are sequenced.

**`return new String(c);`**
Copies the char array into a fresh immutable String. Yes, a second O(n) copy — one for `toCharArray`, one here. Both unavoidable given immutability. (Internally, `new String(char[])` also decides whether it can compact to LATIN1.)

**`while (lo < hi && !Character.isLetterOrDigit(s.charAt(lo))) lo++;`**
The inner skip loops in `isPalindrome`. Three things to notice:

1. **`lo < hi` must be re-checked inside the inner loop.** Consider the input `",,,"` — with no bound check, `lo` would march past `hi` and off the end. This is the classic crash in this problem.
2. `Character.isLetterOrDigit` is Unicode-aware, unlike a hand-rolled `c >= 'a' && c <= 'z'`. Use the library; it handles Devanagari, Cyrillic, and digits from every script.
3. **The outer `while` plus two inner `while`s is still O(n), not O(n²)** — because `lo` only ever increases and `hi` only ever decreases. Together they traverse the string **once**. Total pointer movement is bounded by n. Say this out loud in an interview: *"nested loops, but the pointers are monotonic, so it's O(n) total."*

**`if (a == null || b == null) return a == b;`**
A neat idiom: if either is null, they're "equal" only if both are null (`null == null` is true). Handles all four null combinations in one line.

**`if (a.length() != b.length()) return false;`**
An O(1) early exit before any O(n) work. Anagrams must be the same length. **Always look for a cheap disqualifying check first** — interviewers notice this instinct.

**`freq[a.charAt(i) - 'a']++;`**
The most important line in the module. `char` arithmetic: in Java, `char` is a numeric type (an unsigned 16-bit integer). `'a'` is 97. So:
```
   'a' - 'a' = 0
   'b' - 'a' = 1
   'z' - 'a' = 25
```
This maps 26 letters to array indices 0–25 in **O(1) with no HashMap**. It's the classic **frequency array** trick — a fixed-size table used as a perfect hash for a known small alphabet.

```
   "aabc"  ->  freq = [2, 1, 1, 0, 0, ... 0]
                       a  b  c  d  e
```

**`freq[b.charAt(i)]--;` in the same loop**
The elegant part. Instead of two arrays or two passes, **increment for `a` and decrement for `b` simultaneously.** If they're anagrams, every count cancels to exactly zero. One pass, one array. Explaining this cancellation is a strong interview moment.

**Caution:** `- 'a'` assumes lowercase a–z. If input can be uppercase, mixed, or Unicode, use `int[128]` (ASCII) or `HashMap<Character,Integer>` (full Unicode). **Always state your alphabet assumption out loud** — "I'm assuming lowercase English letters; if it's full Unicode I'd switch to a HashMap." That single sentence prevents a whole category of interview failure.

**`new StringBuilder(unit.length() * times)`**
Pre-sizing to the exact final capacity means **zero internal resizes** — no copying at all during the build. When you know the final size, always pass it. Free performance.

## 3.6 Complexity Analysis

| Operation | Time | Notes |
|---|---|---|
| `s.charAt(i)` | O(1) | Array indexing (plus a coder branch). |
| `s.length()` | O(1) | Stored field. |
| `s.equals(t)` | O(n) | Length check first, then char-by-char. Fast reject on length mismatch. |
| `s.hashCode()` | O(n) first call, **O(1)** after | Cached. Legal only due to immutability. |
| `s.substring(a,b)` | **O(b-a)** | **Copies** since Java 7u6. Not O(1). |
| `s.indexOf(t)` | O(n·m) worst | Naive scan in the JDK. Use KMP for guaranteed O(n+m). |
| `s + t` | O(n+m) | Allocates. In a loop → O(n²). |
| `sb.append(x)` | Amortized O(1) | Geometric growth. |
| `sb.toString()` | O(n) | One copy at the end. |
| `s.toCharArray()` | O(n) | Allocates. |
| `s.split(regex)` | O(n) to O(n²) | Compiles a regex each call unless the pattern is a single non-meta char. Pre-compile a `Pattern` in hot loops. |

**The two headline facts:** building with `+=` in a loop is O(n²); building with `StringBuilder` is O(n). And `substring` in a loop turns an O(n) algorithm into O(n²).

## 3.7 Common Mistakes

1. **`==` instead of `.equals()`** — §3.3. The most consequential Java bug of all time.
2. **`s.toUpperCase();` with no assignment** — does nothing observable. Immutability means you must capture the return value.
3. **`+=` in a loop** — O(n²).
4. **`substring` in a loop** — O(n²). Pass indices.
5. **`s.length` instead of `s.length()`** — arrays use the field, strings use the method.
6. **Assuming `length()` equals character count** — emoji and other supplementary characters are 2 code units.
7. **`s.charAt(i) - 'a'` on unsanitised input** — an uppercase `'A'` gives `-32` → `ArrayIndexOutOfBoundsException`.
8. **Forgetting `lo < hi` inside skip loops** — crashes on all-punctuation input.
9. **`s.split(",")` losing trailing empties** — `"a,b,,".split(",")` yields `["a","b"]`, dropping the trailing blanks. Use `split(",", -1)` to keep them. A real data-parsing bug.
10. **Using `String.format` in a hot loop** — it parses the format string every call. Fine for logging, terrible for tight loops.

## 3.8 Interview Perspective

Strings are the most common interview *medium*, because they let interviewers test array skills, hashing, two pointers, and sliding windows all at once — with inputs that are easy to say out loud.

**Four questions to ask before writing any string code.** Ask these aloud; each one earns credit:
1. **What's the alphabet?** Lowercase a–z? ASCII? Full Unicode? This decides `int[26]` vs `int[128]` vs `HashMap`.
2. **Case-sensitive?**
3. **Can it be null or empty?**
4. **Are non-alphanumerics relevant?** (Spaces, punctuation.)

**The string pattern checklist** — run this mentally on any string problem:
```
  Compare/reorganise chars?         -> frequency array int[26] or HashMap
  Two ends moving inward?           -> two pointers (palindrome, reverse)
  Contiguous substring + condition? -> sliding window
  Prefix matching, autocomplete?    -> Trie
  Pattern search?                   -> KMP / Rabin-Karp
  Group by "same letters"?          -> sorted string or freq-signature as HashMap key
  Building output?                  -> StringBuilder, always
```

**The single highest-value Java-specific signal you can give.** When you reach for `StringBuilder` instead of `+=`, *say why*: "I'll use StringBuilder here — string concatenation in a loop would be O(n²) because each `+=` copies the whole accumulated string." That sentence tells the interviewer you understand immutability, allocation, and amortized cost, all at once. It takes eight seconds and it materially changes their assessment.

## 3.9 Practice Problems

### Easy — Valid Anagram
Given two strings `s` and `t`, return true if `t` is an anagram of `s`. Assume lowercase English letters.
```
"anagram", "nagaram" -> true
"rat", "car"         -> false
```

### Medium — Longest Substring Without Repeating Characters
Given a string, find the length of the longest substring with no repeated characters.
```
"abcabcbb" -> 3   ("abc")
"bbbbb"    -> 1   ("b")
"pwwkew"   -> 3   ("wke")
```

### Hard — Minimum Window Substring
Given strings `s` and `t`, return the shortest substring of `s` containing **all characters of `t`, including duplicates**. Return `""` if none exists.
```
s = "ADOBECODEBANC", t = "ABC"  ->  "BANC"
s = "a", t = "aa"               ->  ""
```

## 3.10 Solution Walkthrough

### Easy — Valid Anagram

Already implemented as `isAnagram` in §3.4. Let's discuss the alternatives, because interviewers ask "can you do better?"

**Approach 1 — sort both, compare.**
```java
char[] a = s.toCharArray(), b = t.toCharArray();
Arrays.sort(a); Arrays.sort(b);
return Arrays.equals(a, b);
```
O(n log n) time, O(n) space. Correct, three lines, works for any alphabet. **Say this first**, then improve.

**Approach 2 — frequency array (the answer).** O(n) time, O(1) space (26 ints is constant regardless of n). This is optimal: you must read both strings, so Ω(n) is a hard floor.

**Approach 3 — HashMap** for arbitrary Unicode. O(n) time, O(k) space where k is the distinct character count.

**The interview arc to perform:** "Sorting works in O(n log n). But since the alphabet is fixed at 26 letters, I can count frequencies in O(n) with O(1) space, incrementing for `s` and decrementing for `t` in a single pass — anagrams cancel to all zeros." Then write it. That's a complete, senior-sounding answer in twenty seconds.

### Medium — Longest Substring Without Repeating Characters

**This is the canonical sliding window problem.** Learn the shape here and you'll recognise it forever.

**Brute force first (always state it):** check all O(n²) substrings, each O(n) to validate → O(n³). Or O(n²) with a rolling set. Too slow for n = 10⁵.

**The insight.** Consider `"abcabcbb"`. Suppose our window is `"abc"` (indices 0–2) and we try to extend to index 3, which is `'a'`.

We already have an `'a'` at index 0. Now the crucial question: **should we shrink the window one step at a time, or can we jump?**

Since the duplicate `'a'` sits at index 0, *any* window containing both index 0 and index 3 is invalid. So the new window must start at index 1 or later. We don't need to slide one at a time — **we can jump `left` directly past the previous occurrence.**

That's the optimisation that makes this O(n).

```java
public int lengthOfLongestSubstring(String s) {
    if (s == null || s.isEmpty()) return 0;

    int[] lastSeen = new int[128];          // ASCII; stores (index + 1), 0 = never seen
    int best = 0;
    int left = 0;                            // window is [left, right]

    for (int right = 0; right < s.length(); right++) {
        char c = s.charAt(right);
        if (lastSeen[c] > left) {            // duplicate INSIDE current window
            left = lastSeen[c];              // jump past it
        }
        lastSeen[c] = right + 1;             // store index+1 so 0 means "unseen"
        best = Math.max(best, right - left + 1);
    }
    return best;
}
```

**Dry run on `"abcabcbb"`.** Trace with your finger; the window is shown as `[...]`.

```
 idx:  0   1   2   3   4   5   6   7
 chr:  a   b   c   a   b   c   b   b

right=0, c='a': lastSeen['a']=0, not > left(0) -> no jump
                lastSeen['a'] = 1
                window [a]        len = 0-0+1 = 1   best = 1

right=1, c='b': lastSeen['b']=0, not > 0 -> no jump
                lastSeen['b'] = 2
                window [ab]       len = 1-0+1 = 2   best = 2

right=2, c='c': lastSeen['c']=0, not > 0 -> no jump
                lastSeen['c'] = 3
                window [abc]      len = 2-0+1 = 3   best = 3

right=3, c='a': lastSeen['a']=1, and 1 > left(0)  -> DUPLICATE in window!
                left = 1          <-- JUMPED past index 0 in ONE step
                lastSeen['a'] = 4
                window a[bca]     len = 3-1+1 = 3   best = 3

right=4, c='b': lastSeen['b']=2, and 2 > left(1)  -> duplicate
                left = 2
                lastSeen['b'] = 5
                window ab[cab]    len = 4-2+1 = 3   best = 3

right=5, c='c': lastSeen['c']=3, and 3 > left(2)  -> duplicate
                left = 3
                lastSeen['c'] = 6
                window abc[abc]   len = 5-3+1 = 3   best = 3

right=6, c='b': lastSeen['b']=5, and 5 > left(3)  -> duplicate
                left = 5
                lastSeen['b'] = 7
                window abcab[cb]  len = 6-5+1 = 2   best = 3

right=7, c='b': lastSeen['b']=7, and 7 > left(5)  -> duplicate
                left = 7
                lastSeen['b'] = 8
                window abcabcb[b] len = 7-7+1 = 1   best = 3

Answer: 3. Correct.
```

**The three details that matter:**

**1. Why store `index + 1` instead of `index`?** Because `int[]` is zero-initialised (Module 2), and 0 would be ambiguous — it could mean "character at index 0" or "never seen". Storing `index + 1` makes 0 unambiguously mean "unseen." This is a **sentinel-value** technique and it appears constantly. The alternative is `Arrays.fill(lastSeen, -1)`, which is equally valid and arguably clearer.

**2. Why `lastSeen[c] > left` and not `>= left`?** With the `index+1` encoding, `lastSeen[c] == left` means the previous occurrence was at index `left - 1`, which is **outside** the window `[left, right]`. Only `> left` means genuinely inside. Getting this comparison wrong produces windows that are too small — and the bug is subtle enough to pass small test cases. Draw the indices when you're unsure.

**3. Why is `left` never decreased?** Because `left = lastSeen[c]` only fires when `lastSeen[c] > left`, i.e. the new value is strictly larger. `left` is **monotonically non-decreasing**. That's what makes this O(n) rather than O(n²) — each pointer traverses the string at most once.

**Complexity:** **O(n) time** — `right` advances n times, `left` never retreats, so total pointer movement is ≤ 2n. **O(1) space** — a fixed 128-int array, constant regardless of input size.

**The sliding-window template you should memorise:**
```
for (right = 0 .. n-1):
    expand window to include s[right]
    while (window is invalid):
        shrink from left            // or: JUMP left, when you can compute the target
    update answer with current window
```
That skeleton solves dozens of problems. We'll formalise it in Module 22.

### Hard — Minimum Window Substring

Same window skeleton, but now the logic inverts: we **expand until valid, then shrink while still valid.** In the previous problem we shrank to *restore* validity; here we shrink to *minimise* an already-valid window. Recognising which of those two modes a problem is in is the real skill.

```java
public String minWindow(String s, String t) {
    if (s == null || t == null || s.length() < t.length() || t.isEmpty()) return "";

    int[] need = new int[128];
    for (int i = 0; i < t.length(); i++) {
        need[t.charAt(i)]++;
    }

    int required = t.length();      // total chars still needed (counts duplicates)
    int left = 0;
    int bestLen = Integer.MAX_VALUE;
    int bestStart = 0;

    for (int right = 0; right < s.length(); right++) {
        char c = s.charAt(right);
        if (need[c] > 0) {          // this char was genuinely needed
            required--;
        }
        need[c]--;                  // may go negative = surplus of this char

        while (required == 0) {     // window is VALID -> try to shrink it
            if (right - left + 1 < bestLen) {
                bestLen = right - left + 1;
                bestStart = left;
            }
            char lc = s.charAt(left);
            need[lc]++;
            if (need[lc] > 0) {     // we just gave up a NEEDED char
                required++;         // window becomes invalid; inner loop exits
            }
            left++;
        }
    }
    return bestLen == Integer.MAX_VALUE ? "" : s.substring(bestStart, bestStart + bestLen);
}
```

**The idea that makes this work: `need[]` is allowed to go negative.**

```
   t = "ABC", so need = { A:1, B:1, C:1 }

   need[c] >  0  ->  we still need more of c
   need[c] == 0  ->  we have exactly enough c
   need[c] <  0  ->  we have SURPLUS c (extra copies we could drop)
```

The magic of `if (need[c] > 0) required--;` **before** the decrement: we only credit progress when the character was actually wanted. A surplus `'A'` drives `need['A']` from 0 to −1 without touching `required`. That single guard is what makes duplicate handling correct — and it's what candidates get wrong.

Symmetrically, `need[lc]++` then `if (need[lc] > 0) required++;` on removal: pushing a count from −1 back to 0 is harmless (we only dropped a surplus), but pushing from 0 to 1 means we lost something essential.

**Dry run on `s = "ADOBECODEBANC", t = "ABC"`.** Abbreviated to the decisive moments.

```
 idx:  0  1  2  3  4  5  6  7  8  9 10 11 12
 chr:  A  D  O  B  E  C  O  D  E  B  A  N  C

Initial: need = {A:1, B:1, C:1}, required = 3, left = 0

right=0 'A': need[A]=1>0 -> required=2.  need[A]=0
right=1 'D': need[D]=0, not >0 -> required stays 2.  need[D]=-1
right=2 'O': need[O]=-1, required=2
right=3 'B': need[B]=1>0 -> required=1.  need[B]=0
right=4 'E': need[E]=-1, required=1
right=5 'C': need[C]=1>0 -> required=0.  need[C]=0
             *** WINDOW VALID: s[0..5] = "ADOBEC", len 6 ***
             best = "ADOBEC" (len 6, start 0)

             Try shrinking. left=0, char 'A'.
             need[A]: 0 -> 1.  1 > 0 -> we lost a needed char. required=1. left=1.
             Inner loop exits (required != 0).

             Window now A[DOBEC], missing an A.

right=6..9: 'O','D','E' add nothing needed.
right=9 'B': need[B] is 0 -> not >0 -> required stays 1. need[B]=-1  (surplus B!)
right=10 'A': need[A]=1>0 -> required=0.  need[A]=0
             *** VALID: s[1..10] = "DOBECODEBA", len 10 ***
             10 > 6, so best stays "ADOBEC".

             Shrink aggressively:
               left=1 'D': need[D] -1->0, not >0 -> harmless surplus dropped. left=2
               left=2 'O': need[O] -1->0, harmless. left=3
               left=3 'B': need[B] -1->0, harmless (we still have the B at index 9!). left=4
               left=4 'E': need[E] -1->0, harmless. left=5
               left=5 'C': need[C]  0->1, 1>0 -> LOST a needed char. required=1. left=6
             Window now ADOBE[CODEBA] -> after left=6: ADOBEC[ODEBA], missing C.
             During shrinking we recorded len 10, 9, 8, 7, 6 -> the len-6 window
             s[5..10]="CODEBA" ties best; we keep the earlier one (strict <).

right=11 'N': nothing needed. need[N]=-1
right=12 'C': need[C]=1>0 -> required=0. need[C]=0
             *** VALID: s[6..12] = "ODEBANC", len 7 ***  (7 > 6, best unchanged)

             Shrink:
               left=6 'O': harmless. left=7
               left=7 'D': harmless. left=8
               left=8 'E': harmless. left=9
               left=9 'B': need[B] 0->1 -> LOST. required=1. left=10
             During shrinking, at left=9 the window was s[9..12] = "BANC", len 4.
             4 < 6  ->  *** NEW BEST: "BANC" ***

Loop ends. Answer: "BANC". Correct.
```

Notice how the shrink phase did the real work: it recorded lengths 7, 6, 5, **4** as it walked `left` forward, and 4 was the winner. **The answer was found by shrinking, not by expanding.** That's the essential character of this problem type.

**Complexity:** `right` advances n times; `left` advances at most n times in total across all inner-loop executions. Every character is added once and removed at most once → **O(n) time**. (The nested `while` does *not* make it O(n²), for exactly the monotonic-pointer reason from §3.5. Be ready to defend this — it's the follow-up question.) **O(1) space** for the fixed 128-int table, plus O(k) for the returned substring.

**The one-line generalisation to carry forward:**

> **"Longest valid window" → shrink only when invalid. "Shortest valid window" → shrink while still valid.**
>
> Same loop skeleton, inverted shrink condition. Recognise which mode you're in and the code writes itself.

---
---
# MODULE 4 — Recursion

## 4.1 Intuition

Recursion is **delegation to a slightly smaller version of yourself.**

Here's the analogy I want you to hold onto for the rest of your career. You're standing in a cinema queue and you want to know your position from the front. You can't see the front. What do you do?

You tap the person ahead of you and ask: **"What position are you?"**

You have no idea how they'll find out. You don't care. You trust that they will. When they answer "I'm 7th," you immediately know you're 8th. You add one and report it back.

Every person in that queue runs the identical algorithm:
```
   "If nobody is in front of me, I am position 1."          <- BASE CASE
   "Otherwise, ask the person ahead, add 1, report."        <- RECURSIVE CASE
```

That is recursion. Completely. And notice what you *didn't* do:

- You didn't manage a loop.
- You didn't track how many people are ahead.
- You didn't need to see the whole queue.

You solved a problem you couldn't see the whole of, by trusting a smaller instance of the same problem.

**The single hardest mental shift** — and I want to name it explicitly, because it's where everyone gets stuck — is this:

> **Stop trying to trace the whole recursion in your head.**

Beginners try to mentally simulate every call, get four levels deep, lose track, and conclude recursion is confusing. That's like trying to understand a `for` loop by visualising all million iterations simultaneously. You don't do that. You reason about *one* iteration and the invariant.

For recursion, reason about **one call**, assuming the recursive call already works. This is called the **recursive leap of faith**, and it isn't hand-waving — it's mathematical induction, the same tool that proves statements about all integers by proving one step.

## 4.2 Mental Model

Every correct recursive function has exactly three parts. Write them in this order, every time, no exceptions.

```
   +--------------------------------------------------------------+
   |  1. BASE CASE      When is the answer obvious with no        |
   |                    further work? Handle it, return.          |
   |                                                              |
   |  2. RECURSIVE CASE Assume the function works for smaller     |
   |                    input. Call it. Use the result.           |
   |                                                              |
   |  3. PROGRESS       Prove every call moves strictly closer    |
   |                    to the base case.                         |
   +--------------------------------------------------------------+
```

Miss #1 → infinite recursion → `StackOverflowError`.
Miss #3 → infinite recursion → `StackOverflowError`.
Miss #2 → you wrote a loop, badly.

**The three questions to ask out loud** (yes, in the interview — interviewers love hearing this):

1. **"What's the smallest input I can answer instantly?"** → base case.
2. **"If I had the answer for a smaller input, how would I build my answer from it?"** → recursive case.
3. **"Does my input definitely shrink toward the base case?"** → progress.

Let's apply it to `factorial(n)`:

1. Smallest input? `factorial(0) = 1`. By definition. Done.
2. If I knew `factorial(n-1)`, could I get `factorial(n)`? Yes — multiply by `n`.
3. Does `n-1` approach 0? Yes, for `n ≥ 0`.

Three sentences, and the code is already written:
```java
long factorial(int n) {
    if (n <= 1) return 1;              // 1
    return n * factorial(n - 1);       // 2, with 3 guaranteed by n-1
}
```

**The two-phase model.** This is the visualisation that fixes most confusion. Every recursion has a way **down** and a way **back up**:

```
   DOWN (the "winding" phase)          UP (the "unwinding" phase)
   calls get made, nothing returns     returns flow back, work happens
   arguments SHRINK                    results COMBINE

        f(4)                                f(4) = 4 * 6 = 24
         |                                   ^
         v                                   |  returns 6
        f(3)                                f(3) = 3 * 2 = 6
         |                                   ^
         v                                   |  returns 2
        f(2)                                f(2) = 2 * 1 = 2
         |                                   ^
         v                                   |  returns 1
        f(1) -> base case, returns 1 --------+
```

**Work done on the way down** = *pre-order* thinking (pass information downward as parameters).
**Work done on the way up** = *post-order* thinking (combine results returned from below).

Almost every recursion question is really asking: *do you compute before or after the recursive call?* Once you can answer that, tree traversals, DFS, and backtracking all become the same skill.

## 4.3 Internal Working — the Call Stack

This is the part that makes recursion *concrete* rather than magical. And it's where Java-specific interview questions live.

### What a stack frame is

Every method call — recursive or not — pushes a **stack frame** onto the current thread's **JVM stack**. A frame contains:

```
   +-----------------------------------------+
   |  STACK FRAME for factorial(3)           |
   +-----------------------------------------+
   |  Local variable array:                  |
   |     [0] n = 3          <- parameters live here too
   |  Operand stack:                         |
   |     (intermediate values for bytecode)  |
   |  Return address:                        |
   |     "resume in factorial(4) at the      |
   |      multiply instruction"              |
   |  Reference to constant pool             |
   +-----------------------------------------+
```

Crucially: **each frame has its own copy of the local variables.** When `factorial(4)` calls `factorial(3)`, there are now two `n`s in existence — one equal to 4, one equal to 3, in separate frames. They do not interfere. This is why recursion works at all, and it's why students who imagine "one shared n that keeps changing" get confused.

### Full stack trace for `factorial(4)`

Watch the stack grow, then shrink. This diagram is worth ten explanations.

```
TIME ->

t1: main calls factorial(4)
    +----------------+
    | factorial(4)   |  n=4, waiting on factorial(3)
    +----------------+
    | main           |
    +----------------+

t2: factorial(4) calls factorial(3)
    +----------------+
    | factorial(3)   |  n=3, waiting on factorial(2)
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED mid-expression
    +----------------+
    | main           |
    +----------------+

t3:
    +----------------+
    | factorial(2)   |  n=2, waiting
    +----------------+
    | factorial(3)   |  n=3, SUSPENDED
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED
    +----------------+
    | main           |
    +----------------+

t4: MAXIMUM DEPTH — base case reached
    +----------------+
    | factorial(1)   |  n=1 -> BASE CASE, returns 1 immediately
    +----------------+
    | factorial(2)   |  n=2, SUSPENDED
    +----------------+
    | factorial(3)   |  n=3, SUSPENDED
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED
    +----------------+
    | main           |
    +----------------+
    ^^^ FOUR frames alive at once. THIS is the O(n) space.

t5: factorial(1) returns 1 -> its frame is POPPED
    factorial(2) resumes: computes 2 * 1 = 2
    +----------------+
    | factorial(2)   |  about to return 2
    +----------------+
    | factorial(3)   |
    +----------------+
    | factorial(4)   |
    +----------------+
    | main           |
    +----------------+

t6: factorial(2) returns 2 -> POPPED
    factorial(3) resumes: 3 * 2 = 6
    +----------------+
    | factorial(3)   |  about to return 6
    +----------------+
    | factorial(4)   |
    +----------------+
    | main           |
    +----------------+

t7: factorial(3) returns 6 -> POPPED
    factorial(4) resumes: 4 * 6 = 24
    +----------------+
    | factorial(4)   |  about to return 24
    +----------------+
    | main           |
    +----------------+

t8: factorial(4) returns 24 -> POPPED. Stack back to just main.
    +----------------+
    | main           |  receives 24
    +----------------+
```

**Read t4 again.** Four frames coexist. That's the entire reason recursion costs O(depth) space, and the reason `StackOverflowError` exists.

### `StackOverflowError` — the practical limit

```java
static int depth = 0;
static void boom() { depth++; boom(); }
```
Run this and you'll get `StackOverflowError` at roughly **10,000–25,000** frames on a default JVM (default thread stack is typically 512 KB–1 MB; each frame is tens of bytes).

You can raise it with `java -Xss16m YourClass`, but **that's a workaround, not a fix.** If your recursion depth scales with input size and input can be large, convert to iteration or use an explicit stack.

**The interview question:** *"Your recursive solution works but crashes on large input. What do you do?"*

Your answer, in order of preference:
1. **Reduce the depth.** Is there an O(log n)-depth formulation? (Divide and conquer instead of linear recursion.)
2. **Convert to iteration.** Linear recursions (`factorial`, list traversal) convert to a simple loop. Tree/graph recursions convert to an explicit `Deque` used as a stack.
3. **Only then** raise `-Xss`, and document why.

Note that Java **does not perform tail-call optimisation**, unlike Scala or functional languages. Writing your recursion in tail position does *not* make it constant-space in Java. It's still one frame per call. This is a genuinely good thing to know: it's a common misconception, and correcting it politely in an interview lands well.

## 4.4 Visual Explanation — Recursion Trees

Linear recursion (`factorial`) is a straight line. But most interesting recursions **branch**, and the shape of the branching *is* the complexity.

### Naive Fibonacci — the exponential disaster

```java
int fib(int n) {
    if (n <= 1) return n;
    return fib(n - 1) + fib(n - 2);
}
```

Draw the tree for `fib(5)`:

```
                            fib(5)
                          /        \
                    fib(4)          fib(3)
                   /      \        /      \
              fib(3)     fib(2) fib(2)    fib(1)
             /     \     /   \   /   \
        fib(2)  fib(1) fib(1) fib(0) fib(1) fib(0)
        /    \
   fib(1)  fib(0)
```

Count the calls: **15 calls to compute fib(5).** Now look for the waste:

```
   fib(3) is computed 2 times
   fib(2) is computed 3 times
   fib(1) is computed 5 times
   fib(0) is computed 3 times
```

The subtree under the left `fib(3)` is **identical** to the right `fib(3)` subtree. We rebuild it from scratch. And that duplication compounds at every level.

**How bad?** The tree has roughly `2^n` nodes:
```
   fib(10)  ->  177 calls
   fib(20)  ->  21,891 calls
   fib(30)  ->  2,692,537 calls
   fib(40)  ->  331,160,281 calls        (~1 second)
   fib(50)  ->  40,730,022,147 calls     (~2 minutes)
   fib(100) ->  more calls than atoms you'll ever count
```

Precisely, `T(n) = O(φ^n)` where φ ≈ 1.618 (the golden ratio). Call it **O(2^n)**.

**The fix — memoization.** Cache each result the first time you compute it:

```java
long fib(int n, long[] memo) {
    if (n <= 1) return n;
    if (memo[n] != 0) return memo[n];              // already known -> return instantly
    return memo[n] = fib(n - 1, memo) + fib(n - 2, memo);
}
```

The tree **collapses**:

```
   Without memo:                    With memo:
                                    (X = cache hit, returns immediately)
        fib(5)                           fib(5)
       /      \                         /      \
   fib(4)    fib(3)                 fib(4)    fib(3) X
   /    \    /    \                 /    \
 fib(3) fib(2) ...                fib(3)  fib(2) X
 ...    ...                       /    \
 15 nodes                       fib(2) fib(1) X
                                /    \
                             fib(1) fib(0)
                             9 nodes, and only 6 do real work
```

Each value `0..n` is computed **exactly once** → **O(n) time, O(n) space.** From 40 billion operations to 50. That is the single most dramatic complexity improvement in all of DSA, and it's the doorway to Dynamic Programming (Module 21).

> **The DP insight, stated once and reused forever: memoization = recursion + a cache. If your recursion tree has repeated subproblems, cache them. That's the whole idea.**

### Recursion tree for divide-and-conquer

Contrast Fibonacci's branching (2 children, input shrinks by 1) with merge sort's (2 children, input **halves**):

```
   FIBONACCI: n -> n-1 and n-2       MERGE SORT: n -> n/2 and n/2
   Shrinks by SUBTRACTION            Shrinks by DIVISION

           n                                  n
          / \                                / \
       n-1   n-2                          n/2   n/2
       / \   / \                          / \   / \
     ...  ...  ...                     n/4 n/4 n/4 n/4

   Depth: n                           Depth: log n
   Nodes: 2^n                         Nodes: 2n
   -> EXPONENTIAL                     -> LINEARITHMIC
```

**This is the single most important structural distinction in recursion.** Memorise it:

> **Subtracting from the input with branching → exponential. Dividing the input with branching → n log n.**
>
> If your recursion branches, make sure it *divides*.

## 4.5 Step-by-Step Dry Run — Recursive Array Sum

Let's trace something with an array, since that's what interviews use.

```java
int sum(int[] arr, int i) {
    if (i == arr.length) return 0;         // base: past the end, nothing to add
    return arr[i] + sum(arr, i + 1);       // this element + sum of the rest
}
```

For `arr = [3, 1, 4]`:

```
DOWN (winding):

sum(arr, 0):  i=0 != 3, so return arr[0] + sum(arr, 1)
              = 3 + <waiting...>
                     |
                     v
sum(arr, 1):  i=1 != 3, so return arr[1] + sum(arr, 2)
              = 1 + <waiting...>
                     |
                     v
sum(arr, 2):  i=2 != 3, so return arr[2] + sum(arr, 3)
              = 4 + <waiting...>
                     |
                     v
sum(arr, 3):  i=3 == 3  ->  BASE CASE  ->  return 0
                     |
UP (unwinding):      |
                     v
sum(arr, 2):  = 4 + 0   = 4    ---> returns 4
                     |
                     v
sum(arr, 1):  = 1 + 4   = 5    ---> returns 5
                     |
                     v
sum(arr, 0):  = 3 + 5   = 8    ---> returns 8

Answer: 8.  (3 + 1 + 4 = 8 ✓)
```

**Notice the shape of the suspended computation.** At maximum depth, the machine is holding:
```
   3 + (1 + (4 + (0)))
```
The additions all happen on the way **up**. Nothing is added on the way down — the calls just stack up with pending `+` operations. That's post-order work.

Compare a version that does work on the way **down**:
```java
int sum(int[] arr, int i, int acc) {
    if (i == arr.length) return acc;
    return sum(arr, i + 1, acc + arr[i]);   // accumulate BEFORE recursing
}
```
```
sum(arr,0,0) -> sum(arr,1,3) -> sum(arr,2,4) -> sum(arr,3,8) -> returns 8
                          ^ acc built on the way DOWN; nothing to do on the way up
```
This is **tail recursion** — the recursive call is the last thing that happens, with no pending work. In a language with TCO this compiles to a loop with O(1) space. **In Java it does not** — it's still O(n) frames. But the *shape* matters enormously, because a tail-recursive function converts to a loop mechanically:

```java
int sum(int[] arr) {
    int acc = 0;
    for (int i = 0; i < arr.length; i++) acc += arr[i];   // the accumulator became a variable
    return acc;
}
```

> **Recognising tail position tells you the recursion can become a simple loop. Recognising non-tail position (pending work on the way up) tells you it needs an explicit stack.**

## 4.6 Java Implementation — a graded set of recursions

```java
package com.dsa.recursion;

import java.util.ArrayList;
import java.util.List;

public final class Recursion {

    private Recursion() { }

    // ---------- 1. Linear recursion ----------

    /** n! with overflow awareness. Depth O(n). */
    public static long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0, got " + n);
        if (n > 20) throw new ArithmeticException("21! overflows long");
        if (n <= 1) return 1L;                    // base case handles both 0 and 1
        return n * factorial(n - 1);
    }

    // ---------- 2. Two-way recursion with memo ----------

    /** Fibonacci in O(n) via top-down memoization. */
    public static long fib(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0");
        long[] memo = new long[n + 1];
        boolean[] computed = new boolean[n + 1];   // avoids the "0 is ambiguous" problem
        return fibHelper(n, memo, computed);
    }

    private static long fibHelper(int n, long[] memo, boolean[] computed) {
        if (n <= 1) return n;
        if (computed[n]) return memo[n];
        computed[n] = true;
        memo[n] = fibHelper(n - 1, memo, computed) + fibHelper(n - 2, memo, computed);
        return memo[n];
    }

    // ---------- 3. Divide and conquer ----------

    /** Fast exponentiation: x^n in O(log n). */
    public static double power(double x, int n) {
        if (n == 0) return 1.0;
        if (n < 0) {
            // Guard against n == Integer.MIN_VALUE, where -n overflows.
            return 1.0 / (power(x, -(n / 2)) * power(x, -(n - n / 2)));
        }
        double half = power(x, n / 2);
        return (n % 2 == 0) ? half * half : half * half * x;
    }

    // ---------- 4. Recursion producing a collection ----------

    /** All subsets of a distinct-element array. O(2^n) results. */
    public static List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> out = new ArrayList<>();
        buildSubsets(nums, 0, new ArrayList<>(), out);
        return out;
    }

    private static void buildSubsets(int[] nums, int idx,
                                     List<Integer> current,
                                     List<List<Integer>> out) {
        if (idx == nums.length) {
            out.add(new ArrayList<>(current));    // SNAPSHOT — see explanation
            return;
        }
        // Choice A: exclude nums[idx]
        buildSubsets(nums, idx + 1, current, out);

        // Choice B: include nums[idx]
        current.add(nums[idx]);
        buildSubsets(nums, idx + 1, current, out);
        current.remove(current.size() - 1);       // BACKTRACK — undo the choice
    }

    // ---------- 5. Tail-shaped recursion (converts to a loop) ----------

    /** Greatest common divisor, Euclid's algorithm. Depth O(log min(a,b)). */
    public static int gcd(int a, int b) {
        return (b == 0) ? Math.abs(a) : gcd(b, a % b);
    }

    // ---------- 6. Classic multi-move recursion ----------

    /** Towers of Hanoi. Prints the optimal 2^n - 1 move sequence. */
    public static void hanoi(int n, char from, char to, char via) {
        if (n == 0) return;
        hanoi(n - 1, from, via, to);                                   // move n-1 out of the way
        System.out.println("Move disk " + n + ": " + from + " -> " + to);
        hanoi(n - 1, via, to, from);                                   // bring them back on top
    }
}
```

## 4.7 Line-by-Line Code Explanation

**`if (n < 0) throw new IllegalArgumentException("n must be >= 0, got " + n);`**
Validate **before** recursing. If you validate inside the recursive case, you re-check the same condition n times. And note: without this, `factorial(-1)` recurses toward negative infinity → `StackOverflowError` with a useless stack trace. A clear exception at the boundary is worth a hundred debugging hours.

**`if (n > 20) throw new ArithmeticException("21! overflows long");`**
`20! = 2,432,902,008,176,640,000` fits in a `long` (max ≈ 9.22 × 10¹⁸). `21!` does not — it silently wraps to a wrong positive number. **Silent integer overflow is one of the nastiest bug classes in Java** because there's no exception; you just get garbage. Mentioning overflow unprompted is a strong senior signal. (`Math.multiplyExact` throws on overflow if you prefer runtime detection.)

**`if (n <= 1) return 1L;`**
`<=` not `==`. This single base case covers `n == 0` (0! = 1 by definition) *and* `n == 1`. **Merging base cases where mathematically sound reduces the surface area for bugs.**

**`boolean[] computed` alongside `long[] memo`**
Why not just check `memo[n] != 0`? Because **0 is a legitimate Fibonacci value** (`fib(0) = 0`). If `fib(0)` legitimately computes to 0, the sentinel check `memo[n] != 0` fails and we recompute forever. For Fibonacci we get lucky (n ≤ 1 is handled by the base case), but the *habit* is what matters. Options:
- a parallel `boolean[] computed` (used here — explicit and always correct),
- `Arrays.fill(memo, -1)` when −1 is impossible as an answer,
- `Long[]` and check `null`.

**Pick a sentinel that cannot be a valid answer.** This is a real bug that has cost real people real interviews.

**`computed[n] = true;` placed BEFORE the recursive calls**
Subtle and deliberate. For a pure tree recursion it doesn't matter, but marking before recursing is the pattern that also detects **cycles** in graph memoization. Building the habit now pays off in Module 14.

**`double half = power(x, n / 2);` — called ONCE**
This is the whole algorithm. Compare:
```java
return power(x, n/2) * power(x, n/2);   // WRONG: 2 calls -> T(n)=2T(n/2)+1 -> O(n)
double half = power(x, n/2);
return half * half;                     // RIGHT: 1 call  -> T(n)=T(n/2)+1  -> O(log n)
```
Both are "correct" in output. One is exponentially better. **Store the result of a recursive call in a variable rather than calling twice** — the single most common way people accidentally destroy a divide-and-conquer's complexity.

Why O(log n)? Each call halves `n`:
```
   power(x, 16) -> power(x,8) -> power(x,4) -> power(x,2) -> power(x,1) -> power(x,0)
   5 calls for n=16.  log2(16) = 4.  -> O(log n)
```

**`(n % 2 == 0) ? half * half : half * half * x`**
The mathematics: `x^n = (x^(n/2))²` when n is even. When n is odd, integer division loses the remainder, so `n = 2·(n/2) + 1` and we must multiply by one extra `x`. Example: `x^7 = (x^3)² · x`.

**`if (n < 0) return 1.0 / (power(x, -(n/2)) * power(x, -(n - n/2)));`**
This looks convoluted, and it's guarding a **real trap**. The obvious code is `return 1.0 / power(x, -n);`. But if `n == Integer.MIN_VALUE` (−2,147,483,648), then `-n` **overflows** — because `Integer.MAX_VALUE` is only 2,147,483,647. `-n` wraps back to `Integer.MIN_VALUE`, still negative, and you recurse forever.

Splitting into two halves before negating keeps every value in range. **Interviewers at Google and Amazon specifically test `Integer.MIN_VALUE` on this problem.** The general lesson: **`-Integer.MIN_VALUE == Integer.MIN_VALUE`.** Negation is not safe on `int`. Say that sentence in an interview.

**`out.add(new ArrayList<>(current));` — the snapshot**
The most important line in `subsets`. We add a **copy**, not `current` itself. Why?

`current` is a single mutable list reused across the entire recursion. If we added the reference, every entry in `out` would point at the *same* list object — and after backtracking emptied it, `out` would contain 2ⁿ references to one empty list.

```
   WRONG: out.add(current)
   out = [ ref, ref, ref, ref ]
            \    |    |    /
             \   |    |   /
              +--+----+--+
                    v
              current = []     <- after all backtracking, everything is empty!

   RIGHT: out.add(new ArrayList<>(current))
   out = [ [], [3], [1], [1,3] ]    <- independent snapshots, frozen in time
```

**This is the #1 bug in all of backtracking.** If your backtracking output is a list of identical empty lists, this is why.

**`current.remove(current.size() - 1);` — the backtrack**
After exploring the "include" branch, we must **undo** our modification so the parent frame sees `current` exactly as it left it. This restores the invariant: *every recursive call returns `current` in the state it received it.*

```
   depth 0: current = []
     -> exclude 3 -> depth 1: current = []            (unchanged, fine)
     -> include 3 -> current = [3]
                     depth 1 explores with [3]
                  <- MUST remove 3 here, or depth 0's parent sees [3] wrongly
   depth 0: current = []   <- invariant restored
```

Forget the `remove` and your results accumulate garbage from sibling branches. **State the invariant out loud when you write backtracking code** — it's how you avoid the bug and how you demonstrate rigour.

**`return (b == 0) ? Math.abs(a) : gcd(b, a % b);`**
Euclid's algorithm. The insight: `gcd(a, b) = gcd(b, a mod b)`, because any common divisor of `a` and `b` also divides `a mod b`. `Math.abs` handles negative inputs (gcd is conventionally non-negative). This is in **tail position** — the recursive call is the entire return expression with nothing pending — so it converts trivially to a loop:
```java
while (b != 0) { int t = b; b = a % b; a = t; }
return Math.abs(a);
```
Depth is O(log min(a,b)) — a beautiful result: consecutive Fibonacci numbers are the worst case.

**`hanoi(n-1, from, via, to);` then print, then `hanoi(n-1, via, to, from);`**
Note how the roles of the pegs **rotate** between the two calls. Read the logic as three English sentences:
1. "To move n disks from A to C, first move the top n−1 disks from A to B, using C as scratch space."
2. "Now the largest disk is alone — move it from A to C."
3. "Now move those n−1 disks from B to C, using A as scratch space."

That's it. Three lines of code for a problem that looks impossibly complex. **This is recursion's real superpower: it lets you express a solution you couldn't possibly write iteratively without pain.** The move count is `T(n) = 2T(n-1) + 1 = 2^n - 1` — provably optimal, and exponential, which is fine because the *output* is exponentially large.

## 4.8 Complexity Analysis

The universal method: **`Total time = (number of nodes in the recursion tree) × (work per node)`** and **`Space = (maximum depth) × (frame size)`**.

| Function | Time | Space | Reasoning |
|---|---|---|---|
| `factorial(n)` | O(n) | O(n) | n calls, O(1) each; n frames alive at max depth. |
| naive `fib(n)` | O(2^n) | O(n) | ~2^n nodes; depth only n because branches run sequentially. |
| memoized `fib(n)` | O(n) | O(n) | Each of n values computed once; memo array + stack. |
| `power(x,n)` | O(log n) | O(log n) | n halves each call → log n depth, 1 call per level. |
| `subsets(n)` | O(n · 2^n) | O(n) stack + O(n·2^n) output | 2^n subsets, each costing O(n) to copy. |
| `gcd(a,b)` | O(log min(a,b)) | O(log min) | Worst case is consecutive Fibonacci numbers. |
| `hanoi(n)` | O(2^n) | O(n) | 2^n − 1 moves; depth n. |

**Two things people consistently get wrong:**

**(a) Space for branching recursion is DEPTH, not node count.** For naive `fib(n)`, the tree has 2^n nodes but space is only **O(n)** — because `fib(n-1)` completes entirely and pops all its frames *before* `fib(n-2)` is called. Only one root-to-leaf path is ever alive.

```
   At any instant, the live stack is ONE PATH down the tree:

           fib(5)     <- alive
          /
       fib(4)         <- alive
      /
   fib(3)             <- alive
   ...                   (everything to the right hasn't started;
                          everything to the left already finished and popped)
```

**(b) Output space is often separate from working space.** `subsets` uses O(n) stack but returns O(n·2^n) of data. Distinguish **auxiliary space** (what your algorithm needs) from **output space** (what the problem demands). If asked "space complexity", clarify which — that question itself impresses.

## 4.9 Common Mistakes

1. **No base case, or an unreachable one.** `if (n == 0)` with `n` decreasing by 2 from an odd start → skips 0 forever.
2. **Not making progress.** `f(n)` calling `f(n)` — instant overflow.
3. **Calling the recursion twice instead of storing it** — §4.7, `power`. Silently converts O(log n) into O(n), or O(n) into O(2^n).
4. **Forgetting to backtrack** — polluted results across sibling branches.
5. **Adding a reference instead of a snapshot** — the empty-lists bug.
6. **A sentinel that's a legal answer** — `memo[n] != 0` when 0 is valid.
7. **Assuming Java optimises tail calls.** It does not. Depth still costs frames.
8. **`-n` on `Integer.MIN_VALUE`** — overflow, infinite recursion.
9. **Mutating shared state without restoring it** — a `visited` array set on the way down and never cleared, when the problem needs it cleared per-path.
10. **Trying to trace 5 levels deep mentally.** Trust the leap of faith. Verify with the base case and one level of the recursive case; that's what induction requires.

## 4.10 Interview Perspective

**Recursion is the gateway skill.** Trees, graphs, backtracking, divide-and-conquer, and all of DP are recursion wearing different hats. Interviewers know that a candidate who is fluent in recursion will pick up the rest fast, and one who isn't will struggle with half the question bank. So they test it deliberately, often through a tree or subset problem.

**What they're watching for:**

1. **Do you state the base case first?** Say "base case: when the index reaches the end, I'm done." Then write it. Then the recursive case.
2. **Can you justify correctness without tracing?** "Assume `subsets(idx+1)` correctly returns all subsets of the remaining elements. Then all subsets of the full array are exactly those, plus those with `nums[idx]` added." That's an induction argument, delivered in one sentence.
3. **Do you spot repeated subproblems?** The moment you draw a recursion tree with a duplicated node, say "there are overlapping subproblems here, so I'll memoize." That transition — brute-force recursion → memoized recursion → tabulation — *is* the DP interview.
4. **Can you convert to iterative when asked?** Have the answer ready: "linear recursion becomes a loop with an accumulator; tree recursion becomes a loop with an explicit `ArrayDeque` as a stack."
5. **Do you analyse the recursion tree, or guess?** Draw it. Count nodes per level. Multiply by work per node. Always.

**The mandatory habit: draw the recursion tree on the whiteboard.** Not because you need it — because it makes your reasoning visible, catches your own errors, and lets the interviewer follow you. Candidates who draw the tree get credit even when their code has a typo. Candidates who write code silently get penalised even when it's correct.

**The two follow-ups you will always get.** Prepare them:
- *"What's the space complexity?"* → "O(depth) for the call stack, which here is O(n)/O(log n) because..."
- *"Can you do it without recursion?"* → "Yes, with an explicit stack; the frames become objects I push manually. Same complexity, no `StackOverflowError` risk."

## 4.11 Practice Problems

### Easy — Reverse a String Recursively
Return the reverse of a string using recursion. State the base case and the depth.
```
"abc" -> "cba"
""    -> ""
```

### Medium — Generate All Valid Parentheses
Given `n` pairs of parentheses, generate all well-formed combinations.
```
n = 3 -> ["((()))","(()())","(())()","()(())","()()()"]
```

### Hard — Word Search in a Grid
Given a `char[][] board` and a `String word`, return true if the word can be built from sequentially adjacent cells (horizontally or vertically). **The same cell may not be used twice.**
```
board = [["A","B","C","E"],
         ["S","F","C","S"],
         ["A","D","E","E"]]
word = "ABCCED" -> true
word = "SEE"    -> true
word = "ABCB"   -> false   (would reuse the B)
```

## 4.12 Solution Walkthrough

### Easy — Reverse a String Recursively

**Three questions.**
1. Smallest input answerable instantly? A string of length 0 or 1 is its own reverse.
2. If I could reverse a smaller string, how do I build my answer? `reverse("abc")` = `reverse("bc")` + `"a"`. Peel off the first character and stick it on the **end** of the reversed rest.
3. Does it shrink? Yes — one character per call.

```java
public String reverse(String s) {
    if (s == null || s.length() <= 1) return s;      // base case
    return reverse(s.substring(1)) + s.charAt(0);    // recursive case
}
```

**Dry run on `"abc"`:**
```
reverse("abc") = reverse("bc") + 'a'
                     |
                 reverse("bc") = reverse("c") + 'b'
                                     |
                                 reverse("c") -> length 1 -> BASE, returns "c"
                                     |
                 reverse("bc") = "c" + 'b' = "cb"
                     |
reverse("abc") = "cb" + 'a' = "cba"   ✓
```

**Now the critical follow-up — and this is why I chose this problem.** What's the complexity?

Beginners say O(n). **It's O(n²).** Two reasons compounding:
- `s.substring(1)` **copies** n−1 characters (§3.3). Called at every level.
- `+` allocates a new string of growing length at every level.

Total: `n + (n-1) + ... + 1 = O(n²)` time and O(n²) allocation churn.

**The fix — recurse over indices on a `char[]`, never allocating:**
```java
public String reverse(String s) {
    if (s == null) return null;
    char[] c = s.toCharArray();
    reverseHelper(c, 0, c.length - 1);
    return new String(c);
}
private void reverseHelper(char[] c, int lo, int hi) {
    if (lo >= hi) return;                  // base: pointers met or crossed
    char t = c[lo]; c[lo] = c[hi]; c[hi] = t;
    reverseHelper(c, lo + 1, hi - 1);      // tail position
}
```
**O(n) time, O(n) space** (the char array; the stack is O(n/2) = O(n)). And since the recursive call is in tail position, this converts directly to the `while (lo < hi)` loop from §3.4 — giving **O(1) auxiliary space** beyond the array.

**The lesson, which generalises far beyond this problem:** the recursion structure was fine both times. The *data handling* was what made version one quadratic. **Recurse over indices, not over copies.** Say this in an interview and you have shown you think about allocation, not just algorithms.

### Medium — Generate All Valid Parentheses

**The naive idea:** generate all 2^(2n) strings of brackets and filter the valid ones. For n=3 that's 64 candidates for 5 answers. Wasteful — and it gets exponentially worse.

**The insight: prune invalid branches at the moment they become invalid.** Don't generate then filter; **refuse to generate garbage in the first place.** This is the essence of backtracking.

What makes a bracket string valid? Two conditions, and they're both *local*:
```
   1. You may add '(' only if you haven't used all n of them.
   2. You may add ')' only if there is an unmatched '(' waiting for it.
```

Condition 2 is the key. Track how many `(` and `)` we've placed:
```
   open  = number of '(' placed
   close = number of ')' placed

   Can add '('?  ->  open < n
   Can add ')'?  ->  close < open      <-- this is the pruning rule
```

`close < open` means "there's at least one unmatched open bracket." If `close == open`, everything is balanced and adding `)` would make it invalid immediately.

```java
public List<String> generateParenthesis(int n) {
    List<String> out = new ArrayList<>();
    if (n <= 0) return out;
    backtrack(new StringBuilder(), 0, 0, n, out);
    return out;
}

private void backtrack(StringBuilder sb, int open, int close, int n, List<String> out) {
    if (sb.length() == 2 * n) {           // base case: complete string
        out.add(sb.toString());           // toString() is already a snapshot
        return;
    }
    if (open < n) {                       // choice 1: add '('
        sb.append('(');
        backtrack(sb, open + 1, close, n, out);
        sb.deleteCharAt(sb.length() - 1); // BACKTRACK
    }
    if (close < open) {                   // choice 2: add ')'
        sb.append(')');
        backtrack(sb, open, close + 1, n, out);
        sb.deleteCharAt(sb.length() - 1); // BACKTRACK
    }
}
```

**Dry run for n = 2.** The full tree, showing pruned branches:

```
                              ""  (open=0, close=0)
                            /              \
              add '(' OK   /                \  add ')' ? close(0) < open(0)? NO -> PRUNED
                          /                     (this entire subtree never explored)
                     "("  (1,0)
                    /            \
      open<2? YES  /              \  close(0) < open(1)? YES
                  /                \
            "(("  (2,0)          "()"  (1,1)
                 |                    |         \
   open<2? 2<2 NO -> can't add '('    |          \ close(1)<open(1)? NO -> PRUNED
   close(0)<open(2)? YES              |
                 |          open<2? YES
            "(()" (2,1)               |
                 |                 "()(" (2,1)
   close(1)<open(2)? YES              |
                 |          close(1)<open(2)? YES
           "(())" (2,2)                |
           length == 4 -> ADD       "()()" (2,2)
                                    length == 4 -> ADD

Result: ["(())", "()()"]   ✓  (Catalan number C(2) = 2)
```

**Look at what the pruning bought us.** The full binary tree of depth 4 has 16 leaves. We visited a handful of nodes and produced exactly 2 answers, with **zero invalid strings ever constructed.** That's the difference between generate-and-filter and backtracking.

**Three implementation notes:**

**`out.add(sb.toString())`** — `toString()` creates a new immutable String, so this *is* a snapshot. No `new ArrayList<>(...)` needed here, unlike the `subsets` case. Understanding *why the snapshot is automatic here* (immutability) but *manual there* (mutable list) shows real command of the pattern.

**`sb.deleteCharAt(sb.length() - 1)`** — the backtrack. `StringBuilder` is mutable and shared across all frames, so we must restore it. Note we could instead pass `sb.toString() + "("` and skip backtracking — but that allocates at every node, turning this into the O(n²) mistake from the previous problem. **Mutate-and-restore is the efficient pattern.**

**Why no explicit validity check?** Because the two `if` guards make invalid states **unreachable**. There is nothing to check. This is the ideal form of backtracking: the constraints live in the branch conditions, not in a validation step. Point this out in an interview.

**Complexity.** The number of valid strings is the nth **Catalan number**, `C(n) = (1/(n+1))·C(2n,n) ≈ 4^n / (n^1.5·√π)`. Each costs O(n) to build and copy. → **O(4^n / √n) time**. Space: O(n) for the stack and builder, plus the output. Don't panic about the ugly bound — the honest interview answer is: *"The output size is the nth Catalan number, roughly 4^n/n^1.5, and each string costs O(n) to emit, so that's the lower bound too. This algorithm is output-optimal — it does O(n) work per result and never explores a dead branch."* **"Output-optimal"** is the phrase you want.

### Hard — Word Search in a Grid

This is DFS with backtracking on a 2D grid — the pattern behind dozens of interview questions (islands, flood fill, path counting, maze solving). Learn it properly here.

**The structure.** For each cell, try starting the word there. From a cell, if the character matches, recurse into the four neighbours looking for the *next* character.

**The hard part is the "can't reuse a cell" constraint.** We need a `visited` marker that is set on the way down and **cleared on the way up** — because a cell used in one path must be free for a different path.

```java
public boolean exist(char[][] board, String word) {
    if (board == null || board.length == 0 || word == null || word.isEmpty()) return false;
    int rows = board.length, cols = board[0].length;
    if (word.length() > rows * cols) return false;              // cheap impossibility check

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (dfs(board, word, r, c, 0)) return true;
        }
    }
    return false;
}

private boolean dfs(char[][] board, String word, int r, int c, int idx) {
    if (idx == word.length()) return true;                      // matched everything

    if (r < 0 || r >= board.length || c < 0 || c >= board[0].length) return false;  // off-grid
    if (board[r][c] != word.charAt(idx)) return false;           // char mismatch

    char original = board[r][c];
    board[r][c] = '#';                                           // MARK as visited

    boolean found = dfs(board, word, r + 1, c, idx + 1)
                 || dfs(board, word, r - 1, c, idx + 1)
                 || dfs(board, word, r, c + 1, idx + 1)
                 || dfs(board, word, r, c - 1, idx + 1);

    board[r][c] = original;                                      // UNMARK (backtrack)
    return found;
}
```

**Dry run: `word = "ABCCED"` on the sample board.** Let me trace the successful path.

```
   board:        c=0  c=1  c=2  c=3
          r=0:    A    B    C    E
          r=1:    S    F    C    S
          r=2:    A    D    E    E

Outer loop tries (0,0) first.

dfs(0,0, idx=0): board[0][0]='A', word[0]='A'  MATCH
                 mark (0,0) as '#'
                 grid:  #  B  C  E
                        S  F  C  S
                        A  D  E  E
   try DOWN (1,0), idx=1: board[1][0]='S', word[1]='B'. MISMATCH -> false
   try UP   (-1,0):       out of bounds -> false
   try RIGHT(0,1), idx=1: board[0][1]='B', word[1]='B'  MATCH
                          mark (0,1)
                          grid:  #  #  C  E
                                 S  F  C  S
                                 A  D  E  E
        try DOWN (1,1), idx=2: 'F' vs 'C'. MISMATCH
        try UP   (-1,1):       out of bounds
        try RIGHT(0,2), idx=2: 'C' vs 'C'  MATCH
                               mark (0,2)
                               grid:  #  #  #  E
                                      S  F  C  S
                                      A  D  E  E
             try DOWN (1,2), idx=3: 'C' vs 'C'  MATCH
                                    mark (1,2)
                                    grid:  #  #  #  E
                                           S  F  #  S
                                           A  D  E  E
                  try DOWN (2,2), idx=4: 'E' vs 'E'  MATCH
                                         mark (2,2)
                       try DOWN (3,2): out of bounds
                       try UP   (1,2): board[1][2] is '#' != 'D'. MISMATCH
                                       ^^^ THE MARK IS DOING ITS JOB — it blocks reuse
                       try RIGHT(2,3), idx=5: 'E' vs 'D'. MISMATCH
                       try LEFT (2,1), idx=5: 'D' vs 'D'  MATCH
                                              mark (2,1)
                            dfs(..., idx=6): idx == word.length()  ->  TRUE
                            unmark (2,1), return true
                       -> true propagates up
                  unmark (2,2), return true
             unmark (1,2), return true
        unmark (0,2), return true
   unmark (0,1), return true
unmark (0,0), return true

Result: true. Path found: A(0,0) -> B(0,1) -> C(0,2) -> C(1,2) -> E(2,2) -> D(2,1)
```

**Four things to notice, each an interview talking point:**

**1. `board[r][c] = '#'` — marking in the input instead of a separate `visited` array.** This is the **O(1) extra space** trick: we borrow the input as our bookkeeping and restore it afterward. Since `'#'` can never equal a letter in `word`, the mismatch check doubles as the visited check. Two purposes, one comparison. If the interviewer says the input must not be mutated, use `boolean[][] visited` — O(m·n) space but non-destructive. **Offer both and let them choose.**

**2. `board[r][c] = original;` — the unmark is mandatory.** Watch what breaks without it: after failing to find `"ABCB"` starting at (0,0), the cells stay marked as `'#'`, and every subsequent start position sees a corrupted board. The **invariant to state out loud** is: *"every call to `dfs` leaves the board exactly as it found it."*

**3. Short-circuit `||` is doing real work.** Java's `||` doesn't evaluate the right side if the left is true. So the moment one direction succeeds, the other three recursive calls are **never made**. That's automatic pruning — we stop searching as soon as we have an answer. Writing this with four separate `if (dfs(...)) return true;` statements is equivalent; the `||` chain is just more compact.

**4. The base case is checked BEFORE the bounds check.** `if (idx == word.length()) return true;` comes first. This matters: if the last character of the word sits at the grid edge, the recursive call goes out of bounds — but we return `true` before ever looking at `r` and `c`. Order the guards so success is detected before failure conditions are evaluated. Reversing these two lines is a real bug that only appears on edge cells.

**Complexity.**
- **Time:** we try each of `m·n` starting cells. From each, the search branches into at most 4 directions, but never backward (that cell is marked), so effectively **3 choices per step**, to depth `L = word.length()`. → **O(m · n · 3^L)** worst case.
- **Space:** **O(L)** for the recursion stack. The `'#'` marking is in-place, so no extra grid. (With a `visited` array it's O(m·n).)

**Why the bound is loose in practice:** the character-mismatch check prunes almost immediately. Real inputs run vastly faster than 3^L. Saying "the worst case is O(m·n·3^L), but the character check prunes so aggressively that typical performance is far better" is exactly the kind of nuanced complexity statement that distinguishes a strong candidate.

**The grid-DFS template to memorise** — you will reuse this verbatim:
```
dfs(r, c, state):
    if (goal reached)            return SUCCESS
    if (out of bounds)           return FAIL
    if (already visited)         return FAIL
    if (this cell doesn't fit)   return FAIL

    MARK (r, c)
    result = dfs(r+1,c) || dfs(r-1,c) || dfs(r,c+1) || dfs(r,c-1)
    UNMARK (r, c)                       // only if paths must be independent
    return result
```
Note the last comment: for *path* problems (like this one) you unmark. For *connected-component* problems (counting islands), you **don't** unmark — a visited cell should stay visited forever. **Knowing when to unmark is the single most important judgement call in grid DFS.**

---
---
# MODULE 5 — Searching (and the Binary Search Pattern)

## 5.1 Intuition

Searching answers one question: **"where is it?"** And there are exactly two strategies in the universe.

**Linear search — look at everything.** Works always. Costs O(n).

**Binary search — eliminate half, repeatedly.** Costs O(log n). Requires *order*.

That word "requires" is the whole lesson. Binary search doesn't need a sorted array. **It needs a monotonic predicate** — a yes/no question whose answer flips exactly once as you move left to right. Sortedness is just the most familiar way to get that property.

Back to the phone book from Module 1. You open the middle and ask "is Ramesh after this?" The answer is NO for a while, then YES forever:

```
   Names:      Aarav  Bhavna  Deepak  Kavya  Ramesh  Sneha  Vikram
   "Is name >= Ramesh?"
               NO     NO      NO      NO     YES     YES    YES
                                             ^
                                             the flip point = the answer
```

**That flip point is what binary search finds.** Not "the target" — the *boundary*. Reframing binary search as "find the boundary of a monotonic predicate" instead of "find a value in a sorted array" is the single upgrade that lets you solve the hard variants. We'll build to that.

Why is halving so powerful? Because information doubles per question:

```
   Array size    Questions needed
   ------------  ----------------
   1             0
   2             1
   4             2
   1,000         10
   1,000,000     20
   1,000,000,000 30
   
   Every DOUBLING of the array costs exactly ONE more question.
```

Thirty questions to find one item among a billion. That's binary search.

## 5.2 Mental Model

**Model 1 — "I maintain a search space and I shrink it."**

Binary search is not about `mid`. It's about the **invariant**: *"if the answer exists, it is inside `[lo, hi]`."* Every step must preserve that. If you can state your invariant, you can write the loop correctly. If you can't, you'll fight off-by-one errors forever.

```
   Start:   [lo ........................ hi]     answer is somewhere in here
   Step:    compute mid, ask a question
   Discard: [lo ... mid]  or  [mid ... hi]        HALF is proven answer-free
   Repeat until the space holds one candidate (or is empty)
```

**Model 2 — "Never write `(lo + hi) / 2`."**

```java
int mid = (lo + hi) / 2;          // BUG: overflows when lo + hi > Integer.MAX_VALUE
int mid = lo + (hi - lo) / 2;     // CORRECT: hi - lo can never overflow
```
`hi - lo` is at most the array length, so it's always safe; adding it to `lo` keeps us in range. **This exact bug existed in `java.util.Arrays.binarySearch` for nine years** and in Joshua Bloch's own published binary search. Fixed in Java 6. Mentioning this story in an interview is genuinely charming and demonstrates real depth. Type the safe form every single time until it's muscle memory.

**Model 3 — "Answer these three questions before writing the loop."**
```
   1. Is my search space [lo, hi] inclusive, or [lo, hi) exclusive?
   2. Is my loop condition  lo <= hi  or  lo < hi ?
   3. When I discard, do I move to  mid ± 1  or to  mid ?
```
Those three must be *consistent*, and different variants need different combinations. Below I give you two templates that are internally consistent; **memorise them exactly and never improvise.**

## 5.3 Internal Working

### Why O(log n), derived

Each iteration keeps at most half the space. After `k` iterations the space has size `n / 2^k`. We stop when it holds 1 element:

```
   n / 2^k = 1
   2^k = n
   k = log₂ n
```

For n = 1,000,000: `k = 20`. Confirmed by the table in §5.1.

### What binary search costs that linear search doesn't

```
   Linear search:  no preconditions. O(n).  Works on anything.
   Binary search:  needs sorted data. O(log n) per query.
                   But sorting costs O(n log n) once.
```

**The break-even calculation** — this is the practical engineering question, and interviewers love it:

```
   q queries on n elements:
     Linear:  q × n
     Sort + binary:  n log n + q log n

   Sorting wins when:  n log n + q log n  <  q × n
   
   n = 1,000,000, log n = 20:
     1 query:    2×10^7 + 20        vs  10^6         -> LINEAR wins
     100 queries: 2×10^7 + 2000     vs  10^8         -> BINARY wins
     
   Roughly: if q > log n, pay the sort. Otherwise don't.
```

**One query? Just scan.** Many queries? Sort once, then binary search forever. Say this trade-off out loud — it shows you think about amortising preprocessing.

### Cache behaviour (the honest footnote)

Binary search jumps around memory, causing a cache miss almost every step. Linear search walks contiguous memory, which the CPU prefetches beautifully. **For small arrays (roughly n < 50–100), linear search is often *faster in wall-clock time* despite being O(n).** This is why real-world implementations (including the JDK's `TimSort`) switch to insertion sort / linear scanning below a threshold. Big O is about growth, not about small inputs.

## 5.4 Visual Explanation

### Successful search: find 23 in a sorted array

```
Index:   0    1    2    3    4    5    6    7    8    9
Value:   2    5    8   12   16   23   38   56   72   91

--- Iteration 1 ---
lo=0, hi=9    mid = 0 + (9-0)/2 = 4
              arr[4] = 16.  16 < 23  ->  target is to the RIGHT
              
   [ 2    5    8   12   16 ] 23   38   56   72   91
   \_____ DISCARDED _____/  ^^^^^^^^^^^^^^^^^^^^^^
                            new search space: lo = 5

--- Iteration 2 ---
lo=5, hi=9    mid = 5 + (9-5)/2 = 5 + 2 = 7
              arr[7] = 56.  56 > 23  ->  target is to the LEFT
              
                            23   38 [ 56   72   91 ]
                            ^^^^^^^^  \_ DISCARDED _/
                            new search space: hi = 6

--- Iteration 3 ---
lo=5, hi=6    mid = 5 + (6-5)/2 = 5 + 0 = 5
              arr[5] = 23.  FOUND. Return 5.

Total: 3 comparisons for 10 elements. Linear search would have taken 6.
```

### Failed search: find 40 — watch the pointers cross

```
Index:   0    1    2    3    4    5    6    7    8    9
Value:   2    5    8   12   16   23   38   56   72   91

lo=0, hi=9,  mid=4:  arr[4]=16 < 40  ->  lo = 5
lo=5, hi=9,  mid=7:  arr[7]=56 > 40  ->  hi = 6
lo=5, hi=6,  mid=5:  arr[5]=23 < 40  ->  lo = 6
lo=6, hi=6,  mid=6:  arr[6]=38 < 40  ->  lo = 7
lo=7, hi=6:  lo > hi  ->  LOOP ENDS. Not found.

   Final state:      ... 38 | 56 ...
                        ^     ^
                       hi=6   lo=7
                       
   The pointers CROSSED. And notice where they ended up:
     hi points to the largest element < 40
     lo points to the smallest element > 40
     
   lo is exactly the INSERTION POINT for 40.
```

**That last observation is enormously useful.** When binary search fails, `lo` is the index where the target *would* go. This is why `Arrays.binarySearch` returns `-(insertionPoint) - 1` on failure — the negative encodes "not found" while preserving the position. It also solves "lower bound", "ceiling", and "count of elements less than x" for free.

## 5.5 Java Implementation

### Template A — exact match (inclusive bounds)

```java
package com.dsa.searching;

public final class Searching {

    private Searching() { }

    /** Linear search. O(n). Works on unsorted data, and on anything. */
    public static int linearSearch(int[] arr, int target) {
        if (arr == null) return -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) return i;
        }
        return -1;
    }

    /** TEMPLATE A: exact match on a sorted array. O(log n) time, O(1) space. */
    public static int binarySearch(int[] arr, int target) {
        if (arr == null || arr.length == 0) return -1;

        int lo = 0, hi = arr.length - 1;          // INCLUSIVE bounds
        while (lo <= hi) {                        // continue while space is non-empty
            int mid = lo + (hi - lo) / 2;         // overflow-safe
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                lo = mid + 1;                     // mid is proven too small -> exclude it
            } else {
                hi = mid - 1;                     // mid is proven too big -> exclude it
            }
        }
        return -1;                                // lo > hi: space exhausted
    }

    /** Recursive form, for comparison. O(log n) time, O(log n) STACK space. */
    public static int binarySearchRecursive(int[] arr, int target) {
        return bsr(arr, target, 0, arr.length - 1);
    }
    private static int bsr(int[] arr, int target, int lo, int hi) {
        if (lo > hi) return -1;
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        return (arr[mid] < target)
                ? bsr(arr, target, mid + 1, hi)
                : bsr(arr, target, lo, mid - 1);
    }

    // ---------- TEMPLATE B: boundary search (the powerful one) ----------

    /**
     * First index where arr[i] >= target (C++'s lower_bound).
     * Returns arr.length if no such index exists.
     */
    public static int lowerBound(int[] arr, int target) {
        int lo = 0, hi = arr.length;              // NOTE: hi = length, EXCLUSIVE
        while (lo < hi) {                         // NOTE: strict <
            int mid = lo + (hi - lo) / 2;
            if (arr[mid] >= target) {
                hi = mid;                         // mid is a CANDIDATE -> keep it
            } else {
                lo = mid + 1;                     // mid fails -> exclude it
            }
        }
        return lo;                                // lo == hi == the boundary
    }

    /** First index where arr[i] > target (C++'s upper_bound). */
    public static int upperBound(int[] arr, int target) {
        int lo = 0, hi = arr.length;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (arr[mid] > target) hi = mid;
            else                   lo = mid + 1;
        }
        return lo;
    }

    /** Count of occurrences of target. O(log n). */
    public static int countOccurrences(int[] arr, int target) {
        return upperBound(arr, target) - lowerBound(arr, target);
    }

    /** Largest element <= target, or Integer.MIN_VALUE if none. */
    public static int floor(int[] arr, int target) {
        int idx = upperBound(arr, target) - 1;
        return (idx >= 0) ? arr[idx] : Integer.MIN_VALUE;
    }

    /** Smallest element >= target, or Integer.MAX_VALUE if none. */
    public static int ceiling(int[] arr, int target) {
        int idx = lowerBound(arr, target);
        return (idx < arr.length) ? arr[idx] : Integer.MAX_VALUE;
    }
}
```

## 5.6 Line-by-Line Code Explanation

**`int lo = 0, hi = arr.length - 1;` (Template A)**
Both bounds are **inclusive** — the search space is `[lo, hi]`, and `hi` is a real index we might return. That's why it's `length - 1`.

**`while (lo <= hi)` (Template A)**
`<=` because when `lo == hi` the space still contains **one** element that we haven't examined yet. Using `<` here would skip single-element spaces and fail to find elements at the boundaries. **This is the single most common binary search bug.** Test your implementation on a 1-element array — if it fails, this is why.

**`lo = mid + 1;` and `hi = mid - 1;` (Template A)**
The `± 1` is mandatory and it's what guarantees termination. We just *proved* `arr[mid]` is not the target, so excluding it is correct — and it strictly shrinks the space. Writing `lo = mid` instead creates an infinite loop when `lo == mid` (which happens whenever `hi == lo + 1`). **Every "my binary search hangs" bug is this line.**

**`int lo = 0, hi = arr.length;` (Template B — note the difference!)**
Now `hi` is **exclusive** — one past the end. The search space is `[lo, hi)`. Why? Because the answer to "first index where the predicate is true" might be *"nowhere"*, and `arr.length` is the natural encoding of that. Template B's return value is a **position**, possibly past the end; Template A's is an **index that must exist**.

**`while (lo < hi)` (Template B)**
Strict `<`. When `lo == hi` the half-open space `[lo, hi)` is **empty** — there's nothing left to examine, and `lo` *is* the answer. The loop condition and the bound convention must match: `[lo, hi]` pairs with `<=`; `[lo, hi)` pairs with `<`.

**`hi = mid;` — no minus one! (Template B)**
This is the crucial asymmetry, and it's where everyone stumbles. In Template B we're not looking for an exact value; we're looking for the **first** position satisfying a condition. When `arr[mid] >= target`, `mid` **might be the answer** — it satisfies the predicate. We must not discard it. So `hi = mid` keeps it in range (as the new exclusive upper bound, `mid` is still reachable as a value of `lo`).

Meanwhile `lo = mid + 1` in the else branch *is* safe, because `arr[mid] < target` proves `mid` is not a candidate.

```
   Template A: mid is EITHER the answer OR excludable  -> always ±1
   Template B: mid may be a CANDIDATE -> keep it (hi = mid)
                                      -> or exclude it (lo = mid + 1)
```

**Why does Template B still terminate with `hi = mid`?** Because `mid < hi` always holds when `lo < hi`:
```
   lo < hi  =>  mid = lo + (hi-lo)/2  <  hi     (integer division rounds down)
   So hi = mid STRICTLY decreases hi. Progress guaranteed.
```
Note that `mid` can equal `lo` (when `hi == lo + 1`), which is exactly why `lo = mid` would *not* be safe but `hi = mid` is. Understanding this asymmetry is the difference between someone who memorised binary search and someone who understands it.

**`return lo;` (Template B)**
At exit `lo == hi`. Everything before `lo` fails the predicate; everything from `lo` onward satisfies it. **`lo` is the boundary.** That's the invariant, and it's true even when the answer is `0` (everything satisfies) or `arr.length` (nothing does).

**`upperBound(t) - lowerBound(t)` for counting**
Beautiful and worth internalising:
```
   arr = [1, 2, 2, 2, 3],  target = 2
   
   lowerBound(2) = 1   (first index with value >= 2)
   upperBound(2) = 4   (first index with value >  2)
   count = 4 - 1 = 3   ✓
   
   [1,  2,  2,  2,  3]
        ^           ^
        lo=1        up=4
        \___3 twos_/
```
Two O(log n) searches instead of an O(n) scan. This is how you answer "count occurrences in a sorted array with duplicates" — a top-20 interview question.

**`floor` = `upperBound(t) - 1`**
`upperBound` gives the first element strictly greater than `t`. Step back one and you have the last element `<= t`. Guard `idx >= 0` for when every element exceeds `t`.

**The recursive version's space complexity**
`O(log n)` stack frames versus `O(1)` for the iterative form. Binary search is one of the few cases where **iterative is strictly better** — the recursion buys no clarity and costs stack. Prefer iterative, and say why if asked.

## 5.7 Complexity Analysis

| Algorithm | Time (worst) | Time (best) | Space | Precondition |
|---|---|---|---|---|
| Linear search | O(n) | O(1) | O(1) | none |
| Binary search (iterative) | O(log n) | O(1) | **O(1)** | sorted / monotonic |
| Binary search (recursive) | O(log n) | O(1) | O(log n) | sorted / monotonic |
| `lowerBound` / `upperBound` | O(log n) | O(log n) | O(1) | sorted |
| Count occurrences | O(log n) | — | O(1) | sorted |
| Sort + q binary searches | O(n log n + q log n) | — | O(log n)–O(n) | none |

**Why `lowerBound` has no O(1) best case:** it always runs the full `log n` iterations, because it never returns early on a match — it must confirm it found the *first* one. Slightly more work than Template A on lucky inputs, but far more powerful.

## 5.8 Common Mistakes

1. **`(lo + hi) / 2`** — overflow. Always `lo + (hi - lo) / 2`.
2. **`while (lo < hi)` with inclusive bounds** — skips single-element spaces. Misses elements.
3. **`lo = mid` in Template A** — infinite loop.
4. **`hi = mid - 1` in Template B** — skips the answer when `mid` is the boundary.
5. **Mixing the templates.** Inclusive `hi = length - 1` with `while (lo < hi)` and `hi = mid`? That combination is *almost* right and fails on specific inputs. **Don't improvise. Pick a template and reproduce it exactly.**
6. **Binary searching unsorted data** — returns garbage, silently. No exception. `Arrays.binarySearch` explicitly documents that results are undefined on unsorted input.
7. **Forgetting duplicates.** Template A returns *some* matching index, not the first or last. If duplicates matter, use Template B.
8. **Not checking for null / empty arrays.**
9. **Off-by-one in the answer-space version** — when binary searching over a *range of answers* rather than array indices (§5.9), getting the initial `lo`/`hi` wrong is fatal. Set them to provably-valid extremes.

## 5.9 Interview Perspective — the pattern that matters most

Plain "find x in a sorted array" is a warm-up. The real interview skill is recognising the **generalised** form:

> **Binary Search on the Answer.** If you can write a boolean function `isFeasible(x)` that is *monotonic* — false, false, false, then true, true, true — you can binary search for the flip point, even when there is no array to search.

```
   candidate answers:  1    2    3    4    5    6    7    8
   isFeasible(x):      F    F    F    T    T    T    T    T
                                      ^
                                 binary search finds this
```

**The trigger phrases.** When you hear any of these, think binary search on the answer:
- "minimum capacity such that..."
- "minimum days to..."
- "maximum value of the minimum..."  (or "minimise the maximum")
- "smallest k such that..."
- "can we do it within X?" as a subproblem

**How to structure your answer, every time:**
1. **Identify the answer range.** "The answer is between `lo` and `hi` because..." (lowest conceivable and highest conceivable values).
2. **Write `isFeasible(x)`** — usually a simple O(n) greedy scan.
3. **Prove monotonicity out loud.** "If capacity `x` works, then `x+1` certainly works, since more capacity can never hurt." **This proof is the whole answer.** Without monotonicity, binary search is invalid.
4. **Binary search** with Template B for the boundary.
5. **State complexity:** `O(n · log(range))`.

That five-step script converts a large family of hard problems into mechanical work. It's probably the highest return-on-investment pattern in interview preparation.

**The other must-know variants** (each a real interview question):
```
   Find first / last occurrence with duplicates      -> Template B
   Search in a rotated sorted array                  -> find which half is sorted
   Find the peak element                             -> compare mid with mid+1
   Find sqrt(x) with integer arithmetic              -> binary search on the answer
   Median of two sorted arrays                       -> binary search on the partition
   Koko eating bananas / ship packages in D days     -> binary search on the answer
   Find minimum in a rotated sorted array            -> compare mid with hi
```

## 5.10 Practice Problems

### Easy — Search Insert Position
Given a sorted array of distinct integers and a target, return the index if found; otherwise return the index where it would be inserted. Must be O(log n).
```
[1,3,5,6], target=5 -> 2
[1,3,5,6], target=2 -> 1
[1,3,5,6], target=7 -> 4
```

### Medium — Find First and Last Position of Element in Sorted Array
Given a sorted array with possible duplicates and a target, return `[firstIndex, lastIndex]`, or `[-1,-1]` if absent. O(log n).
```
[5,7,7,8,8,10], target=8 -> [3,4]
[5,7,7,8,8,10], target=6 -> [-1,-1]
```

### Hard — Koko Eating Bananas
`piles[i]` bananas in pile `i`. Koko eats for `h` hours. Each hour she picks one pile and eats up to `k` bananas from it; if the pile has fewer than `k`, she eats it all and stops for that hour. Find the **minimum** `k` allowing her to finish all piles within `h` hours.
```
piles = [3,6,7,11], h = 8  ->  4
piles = [30,11,23,4,20], h = 5 -> 30
```

## 5.11 Solution Walkthrough

### Easy — Search Insert Position

**The realisation:** this is *exactly* `lowerBound`. "The first index where `arr[i] >= target`" is both the location of the target (if present) and the correct insertion point (if not). One function, both cases, no special handling.

```java
public int searchInsert(int[] nums, int target) {
    int lo = 0, hi = nums.length;              // exclusive upper bound
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (nums[mid] >= target) hi = mid;     // candidate — keep it
        else                     lo = mid + 1; // too small — discard
    }
    return lo;
}
```

**Dry run: `[1,3,5,6]`, target = 2.**
```
lo=0, hi=4:  mid = 0 + 4/2 = 2.  nums[2]=5 >= 2  -> hi = 2
             space [0,2):  [1, 3]
lo=0, hi=2:  mid = 0 + 2/2 = 1.  nums[1]=3 >= 2  -> hi = 1
             space [0,1):  [1]
lo=0, hi=1:  mid = 0 + 1/2 = 0.  nums[0]=1 <  2  -> lo = 1
             space [1,1):  EMPTY
lo=1, hi=1:  loop exits.  return 1.   ✓  (2 would be inserted at index 1)
```

**Dry run: target = 7 (beyond everything).**
```
lo=0, hi=4:  mid=2, nums[2]=5 < 7  -> lo = 3
lo=3, hi=4:  mid=3, nums[3]=6 < 7  -> lo = 4
lo=4, hi=4:  exits.  return 4 == nums.length.   ✓
```
Notice how `hi = length` (not `length - 1`) is what makes returning `4` possible. If you'd used the inclusive template you'd need a special case for "greater than everything." **Template B eliminates the edge cases by construction** — that's the argument for learning it.

**Complexity:** O(log n) time, O(1) space.

### Medium — First and Last Position

**The mistake to avoid:** finding the target with Template A, then linearly scanning left and right for the boundaries. On input `[8,8,8,8,...,8]` (n copies) that scan is O(n) — you've thrown away your logarithm. Interviewers plant this input.

**The correct approach:** two boundary searches.
```
   first index of target  = lowerBound(target)
   last  index of target  = upperBound(target) - 1
```

```java
public int[] searchRange(int[] nums, int target) {
    if (nums == null || nums.length == 0) return new int[]{-1, -1};

    int first = lowerBound(nums, target);
    // If target is absent, first is either out of range or points elsewhere.
    if (first == nums.length || nums[first] != target) {
        return new int[]{-1, -1};
    }
    int last = upperBound(nums, target) - 1;
    return new int[]{first, last};
}

private int lowerBound(int[] a, int t) {
    int lo = 0, hi = a.length;
    while (lo < hi) { int m = lo + (hi-lo)/2; if (a[m] >= t) hi = m; else lo = m+1; }
    return lo;
}
private int upperBound(int[] a, int t) {
    int lo = 0, hi = a.length;
    while (lo < hi) { int m = lo + (hi-lo)/2; if (a[m] >  t) hi = m; else lo = m+1; }
    return lo;
}
```

**Dry run: `[5,7,7,8,8,10]`, target = 8.**

```
Index:   0   1   2   3   4   5
Value:   5   7   7   8   8  10

--- lowerBound(8): first index with value >= 8 ---
lo=0, hi=6:  mid=3, a[3]=8 >= 8  -> hi=3        space [0,3) = [5,7,7]
lo=0, hi=3:  mid=1, a[1]=7 <  8  -> lo=2        space [2,3) = [7]
lo=2, hi=3:  mid=2, a[2]=7 <  8  -> lo=3        space [3,3) = empty
exits, first = 3.   nums[3] == 8  ✓ target exists

--- upperBound(8): first index with value > 8 ---
lo=0, hi=6:  mid=3, a[3]=8 not > 8  -> lo=4     space [4,6) = [8,10]
lo=4, hi=6:  mid=5, a[5]=10 > 8     -> hi=5     space [4,5) = [8]
lo=4, hi=5:  mid=4, a[4]=8 not > 8  -> lo=5     space [5,5) = empty
exits, upper = 5.   last = 5 - 1 = 4

Answer: [3, 4]   ✓
```

**The two guards in `if (first == nums.length || nums[first] != target)`:**
- `first == nums.length` → target is larger than every element. Must check this **first**, or `nums[first]` throws `ArrayIndexOutOfBoundsException`. **Short-circuit `||` order is load-bearing here.**
- `nums[first] != target` → target is absent, and `first` points at the next larger element. E.g. searching for 6 in `[5,7,7,8,8,10]` gives `first = 1`, and `nums[1] = 7 ≠ 6`.

Both guards are needed. Omit either and you have a bug. **Say out loud: "lowerBound tells me where the target *would* be, so I must verify it's actually there."**

**Complexity:** two O(log n) searches → **O(log n) time, O(1) space.** Crucially, this holds even when the entire array is the target — the whole point.

### Hard — Koko Eating Bananas

**This is the flagship "binary search on the answer" problem.** Work the five-step script.

**Step 0 — recognise the pattern.** "Find the *minimum* `k` such that she *can* finish in `h` hours." Minimum-something-such-that-feasible. That's the trigger.

**Step 1 — the answer range.**
- Lowest conceivable `k` is **1** (she must eat at least one banana per hour, or she never finishes).
- Highest conceivable `k` is **`max(piles)`**. With `k = max(piles)`, she clears one entire pile per hour, taking exactly `piles.length` hours. Any larger `k` gives the *same* time, so it's wasted. So `hi = max(piles)`.

Also note: if `h < piles.length`, it's impossible — she can't finish even one pile per hour. The problem guarantees `h >= piles.length`, but say it out loud.

**Step 2 — `isFeasible(k)`: can she finish with speed `k`?**

Hours needed for one pile of size `p` at speed `k` is `ceil(p / k)`. Why ceiling? Because a partial pile still costs a full hour — she stops eating for that hour once the pile is gone.

```
   pile = 7, k = 3:  hours 1 and 2 eat 3 each (6 total), hour 3 eats the last 1.
                     -> 3 hours = ceil(7/3) = 3   ✓
```

Total hours = `Σ ceil(piles[i] / k)`. Feasible iff that total `<= h`.

**Step 3 — prove monotonicity. This is the heart of the answer.**

> "If speed `k` lets her finish in time, then speed `k+1` certainly does — she eats at least as fast from every pile, so `ceil(p/(k+1)) <= ceil(p/k)` for every pile, so the total hours can only decrease. Therefore `isFeasible` is monotonically non-decreasing in `k`: false for small `k`, then true for all larger `k`. That single flip point is what binary search finds."

Visualise it:
```
   k:               1    2    3    4    5    6    7   ... 11
   hours needed:   27   15   10    8    7    6    6   ...  4
   feasible (h=8)?  F    F    F    T    T    T    T   ...  T
                                   ^
                              answer = 4
```

**Step 4 — the code.**

```java
public int minEatingSpeed(int[] piles, int h) {
    int lo = 1;
    int hi = 0;
    for (int p : piles) hi = Math.max(hi, p);     // hi = max pile

    while (lo < hi) {                              // Template B: find the boundary
        int mid = lo + (hi - lo) / 2;
        if (canFinish(piles, mid, h)) {
            hi = mid;                              // mid works -> it's a candidate, keep it
        } else {
            lo = mid + 1;                          // mid too slow -> discard
        }
    }
    return lo;                                     // smallest feasible speed
}

private boolean canFinish(int[] piles, int k, int h) {
    long hours = 0;                                // long: guards against overflow
    for (int p : piles) {
        hours += (p + k - 1) / k;                  // integer ceiling division
        if (hours > h) return false;               // early exit: already too slow
    }
    return hours <= h;
}
```

**Dry run: `piles = [3,6,7,11]`, `h = 8`.**

```
hi = max(3,6,7,11) = 11.  Search space: k in [1, 11].

--- Iteration 1 ---
lo=1, hi=11.  mid = 1 + (11-1)/2 = 1 + 5 = 6
canFinish(k=6):
    ceil(3/6)  = 1
    ceil(6/6)  = 1
    ceil(7/6)  = 2
    ceil(11/6) = 2
    total = 6 hours.  6 <= 8  ->  FEASIBLE
-> hi = 6.   Space [1, 6]

--- Iteration 2 ---
lo=1, hi=6.   mid = 1 + (6-1)/2 = 1 + 2 = 3
canFinish(k=3):
    ceil(3/3)  = 1
    ceil(6/3)  = 2
    ceil(7/3)  = 3
    ceil(11/3) = 4
    total = 10 hours.  10 > 8  ->  NOT feasible
-> lo = 4.   Space [4, 6]

--- Iteration 3 ---
lo=4, hi=6.   mid = 4 + (6-4)/2 = 4 + 1 = 5
canFinish(k=5):
    ceil(3/5)  = 1
    ceil(6/5)  = 2
    ceil(7/5)  = 2
    ceil(11/5) = 3
    total = 8 hours.  8 <= 8  ->  FEASIBLE
-> hi = 5.   Space [4, 5]

--- Iteration 4 ---
lo=4, hi=5.   mid = 4 + (5-4)/2 = 4 + 0 = 4
canFinish(k=4):
    ceil(3/4)  = 1
    ceil(6/4)  = 2
    ceil(7/4)  = 2
    ceil(11/4) = 3
    total = 8 hours.  8 <= 8  ->  FEASIBLE
-> hi = 4.   Space [4, 4]

lo == hi == 4.  Loop exits.  Return 4.   ✓

Notice: we tested 4 speeds out of 11, and never tested most of them.
Only log2(11) ≈ 4 evaluations of canFinish were needed.
```

**Three implementation details that separate a working solution from a great one:**

**1. `(p + k - 1) / k` — integer ceiling division.**
Java's `/` truncates toward zero, so `7/3 = 2` when we want 3. The idiom `(a + b - 1) / b` computes `ceil(a/b)` for positive integers:
```
   p=7, k=3:  (7 + 3 - 1) / 3 = 9 / 3 = 3      ✓ ceil(7/3) = 3
   p=6, k=3:  (6 + 3 - 1) / 3 = 8 / 3 = 2      ✓ ceil(6/3) = 2 (exact division unaffected)
   p=3, k=6:  (3 + 6 - 1) / 6 = 8 / 6 = 1      ✓ ceil(3/6) = 1
```
Why it works: adding `k-1` pushes any non-zero remainder over the next multiple of `k`, while an exact multiple is left in the same bucket. **Memorise this idiom** — it appears in dozens of problems. The alternative `Math.ceil((double) p / k)` works but introduces floating-point imprecision on large values; integer arithmetic is exact and preferred.

**2. `long hours` and the early exit.**
With `piles.length` up to 10⁴ and pile sizes up to 10⁹, at `k = 1` the total hours could reach 10¹³ — which overflows `int` (max ≈ 2.1×10⁹). Declaring `hours` as `long` prevents a silent wrap to a negative number that would falsely report feasibility. And `if (hours > h) return false;` bails out the instant we exceed the budget, which often saves most of the scan.

**Overflow reasoning volunteered unprompted is one of the strongest signals a candidate can give.** Do it.

**3. Why Template B, and why `hi = mid` without the −1.**
We want the *smallest* feasible `k`. When `mid` is feasible, `mid` **might be the answer** — so we keep it (`hi = mid`) and keep looking left for something smaller. When `mid` is infeasible, `mid` is definitively not the answer (`lo = mid + 1`). This is exactly the boundary-search shape from §5.6, applied to a space of *answers* rather than array indices.

**Complexity.**
- `canFinish` is O(n) where n = `piles.length`.
- Binary search runs O(log(max(piles))) iterations — note the log is over the **value range**, not the array length.
- Total: **O(n · log(max(piles)))**.
- For n = 10⁴ and max pile = 10⁹: `10⁴ × 30 = 3×10⁵` operations. Instant.
- **Space: O(1).**

**Compare with brute force:** try every `k` from 1 upward, checking each in O(n) → `O(n · max(piles))` = 10⁴ × 10⁹ = **10¹³ operations**. Binary search improves this by a factor of ~30 million, purely by exploiting monotonicity.

**The transferable script.** Every "binary search on the answer" problem reduces to:
```
   1. What is the answer's range?         -> lo, hi
   2. Write isFeasible(candidate)         -> usually a simple O(n) greedy pass
   3. PROVE monotonicity out loud         -> "if x works, x+1 works, because..."
   4. Template B for the boundary
   5. Complexity = O(n · log(range))
```
Problems this solves verbatim: *Ship Packages in D Days*, *Split Array Largest Sum*, *Minimum Number of Days to Make m Bouquets*, *Capacity To Ship*, *Magnetic Force Between Two Balls*, *Minimize Max Distance to Gas Station*, *Kth Smallest in a Sorted Matrix*, *Find the Smallest Divisor Given a Threshold*. Learn the script once; solve eight problems.

---
---
# MODULE 6 — Sorting

## 6.1 Intuition — why sorting is the most important algorithm you'll learn

Sorting is not really about producing ordered data. It's about **creating structure you can exploit.**

Look at what sortedness buys you:
```
   Unsorted array                    Sorted array
   --------------                    ------------
   search: O(n)                      search: O(log n)      <- binary search
   find duplicates: O(n) w/ hashing  find duplicates: O(n)  <- adjacent comparison
   find median: O(n) (quickselect)   find median: O(1)      <- middle index
   find kth smallest: O(n)           find kth smallest: O(1)
   two-sum: O(n) w/ hashing          two-sum: O(n) w/ two pointers, O(1) space
   group equal items: O(n) w/ map    group equal items: O(n) in-place
```

Sorting costs O(n log n) **once**, and then a dozen problems become easy. That's why *"sort it first"* is the single most productive first thought in interview problem-solving. If you're stuck, ask: **"would sorting help?"** It often does.

**And there's a deeper reason to study sorting.** Every major algorithmic paradigm shows up here in miniature:
```
   Bubble / Selection / Insertion  ->  incremental construction, invariants
   Merge sort                      ->  divide and conquer
   Quick sort                      ->  partitioning, randomisation
   Heap sort                       ->  a data structure doing the work
   Counting / Radix                ->  trading space for time, non-comparison tricks
```
Learning eight sorts isn't about memorising eight sorts. It's about learning five ways to think.

## 6.2 Mental Model — the classification that organises everything

Before any code, learn these four axes. Interviewers ask about all of them.

**Axis 1 — Comparison vs Non-comparison**
```
   Comparison sorts: only ever ask "is a < b?"
       Bubble, Selection, Insertion, Merge, Quick, Heap
       PROVABLE LOWER BOUND: Ω(n log n). Cannot be beaten. (Proof in §6.12.)

   Non-comparison sorts: exploit the structure of the values themselves
       Counting, Radix, Bucket
       Can achieve O(n) — but only under restrictions on the input.
```

**Axis 2 — Stable vs Unstable**

A sort is **stable** if equal elements keep their original relative order.

```
   Input (sort by grade only):
       (Amit, B)  (Bina, A)  (Chetan, B)  (Divya, A)

   STABLE result:    (Bina,A) (Divya,A) (Amit,B) (Chetan,B)
                              ^^^^^^^ Bina still before Divya, Amit still before Chetan

   UNSTABLE result:  (Divya,A) (Bina,A) (Chetan,B) (Amit,B)
                     ^^^^^^^^ order among equals was scrambled
```

**Why stability matters in the real world:** it lets you sort by multiple keys sequentially. Sort by name, then stably sort by department — and within each department, names remain sorted. That's how spreadsheet multi-column sorting works. It's also why `Collections.sort` (TimSort) is guaranteed stable while `Arrays.sort(int[])` (dual-pivot quicksort) is not — **and that distinction is a favourite Java interview question.** Primitives have no identity beyond their value, so stability is meaningless for them; objects do, so stability is guaranteed.

**Axis 3 — In-place vs Out-of-place**
```
   In-place:      O(1) or O(log n) extra space.  Bubble, Selection, Insertion, Heap, Quick*
   Out-of-place:  O(n) extra space.              Merge, Counting, Radix
   
   * Quicksort is "in-place" for the partitioning but uses O(log n) stack for recursion.
```

**Axis 4 — Adaptive vs Non-adaptive**
```
   Adaptive:     runs faster on partially-sorted input.   Insertion (O(n) on sorted!), Bubble w/ flag, TimSort
   Non-adaptive: same cost regardless.                    Selection, Merge, Heap
```
Real data is often nearly sorted. This is exactly why the JDK uses TimSort (adaptive) for objects.

**The summary table — memorise this. It is asked directly.**

| Algorithm | Best | Average | Worst | Space | Stable | Adaptive | In-place |
|---|---|---|---|---|---|---|---|
| Bubble | O(n) | O(n²) | O(n²) | O(1) | ✅ | ✅ (with flag) | ✅ |
| Selection | O(n²) | O(n²) | O(n²) | O(1) | ❌ | ❌ | ✅ |
| Insertion | **O(n)** | O(n²) | O(n²) | O(1) | ✅ | ✅ | ✅ |
| Merge | O(n log n) | O(n log n) | **O(n log n)** | O(n) | ✅ | ❌ | ❌ |
| Quick | O(n log n) | O(n log n) | **O(n²)** | O(log n) | ❌ | ❌ | ✅ |
| Heap | O(n log n) | O(n log n) | **O(n log n)** | **O(1)** | ❌ | ❌ | ✅ |
| Counting | O(n+k) | O(n+k) | O(n+k) | O(n+k) | ✅ | ❌ | ❌ |
| Radix | O(d(n+k)) | O(d(n+k)) | O(d(n+k)) | O(n+k) | ✅ | ❌ | ❌ |

**The three cells that matter most in interviews:**
- **Insertion sort's O(n) best case** — the only comparison sort here that is linear on sorted input.
- **Quicksort's O(n²) worst case** — and why we still use it (better constants, cache locality, in-place).
- **Heap sort's O(1) space with guaranteed O(n log n)** — the only algorithm with both. Yet rarely used in practice, because its cache behaviour is poor.

---

## 6.3 Bubble Sort

### Intuition

Repeatedly walk through the array comparing **adjacent pairs**, swapping any that are out of order. Large values "bubble" to the right like air rising through water.

**The key invariant:** after pass `k`, the largest `k` elements are correctly placed at the end and never move again.

### Visual Explanation — every pass on `[5, 4, 3, 2]`

```
INITIAL:  5  4  3  2

=== PASS 1 (compare adjacent pairs, j = 0..2) ===
j=0: compare 5,4  ->  5 > 4, SWAP
     4  5  3  2
     ^^^^
j=1: compare 5,3  ->  5 > 3, SWAP
     4  3  5  2
        ^^^^
j=2: compare 5,2  ->  5 > 2, SWAP
     4  3  2  5
           ^^^^
PASS 1 DONE:  4  3  2 | 5
                       ^^^ 5 is HOME. Largest element found. Never touched again.

=== PASS 2 (j = 0..1, we skip the sorted tail) ===
j=0: compare 4,3  ->  4 > 3, SWAP
     3  4  2 | 5
     ^^^^
j=1: compare 4,2  ->  4 > 2, SWAP
     3  2  4 | 5
        ^^^^
PASS 2 DONE:  3  2 | 4  5
                     ^^^^^^ two largest are HOME

=== PASS 3 (j = 0 only) ===
j=0: compare 3,2  ->  3 > 2, SWAP
     2  3 | 4  5
     ^^^^
PASS 3 DONE:  2 | 3  4  5

=== PASS 4: only one element left, trivially sorted ===

FINAL:  2  3  4  5    ✓

Total comparisons: 3 + 2 + 1 = 6 = n(n-1)/2
Total swaps:       6 (worst case — the input was fully reversed)
```

**Notice the shrinking boundary.** Pass 1 examines indices 0–3, pass 2 examines 0–2, pass 3 examines 0–1. That's why the inner loop bound is `n - 1 - i`:

```
   The array during sorting:

   +--------------------------------+----------------+
   |     UNSORTED (still working)   | SORTED, FINAL  |
   +--------------------------------+----------------+
    0                     n-1-i     n-i          n-1
                                    ^
                       the boundary marches LEFT each pass
```

### Java Implementation

```java
/** Bubble sort with early-exit optimisation. */
public static void bubbleSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    for (int i = 0; i < n - 1; i++) {          // n-1 passes suffice
        boolean swapped = false;               // adaptivity flag

        for (int j = 0; j < n - 1 - i; j++) {  // shrinking boundary
            if (arr[j] > arr[j + 1]) {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
                swapped = true;
            }
        }

        if (!swapped) return;                  // already sorted -> stop early
    }
}
```

### Line-by-Line

**`for (int i = 0; i < n - 1; i++)`** — `n - 1` passes, not `n`. After placing `n-1` elements, the last one is necessarily in place (there's nowhere else for it to be). One free pass saved.

**`for (int j = 0; j < n - 1 - i; j++)`** — the `- 1` prevents `arr[j+1]` from going out of bounds; the `- i` skips the already-sorted tail. **Both subtractions are load-bearing.** Omit `- i` and it still sorts correctly but does 2× the work.

**`if (arr[j] > arr[j + 1])`** — strict `>`. Using `>=` would swap **equal** elements, destroying stability. **This single character is the difference between a stable and unstable sort.** Interviewers ask "how would you make bubble sort unstable?" — the answer is "change `>` to `>=`."

**`boolean swapped` and `if (!swapped) return;`** — the adaptivity. If a full pass makes zero swaps, the array is sorted by definition (no adjacent pair is out of order → the whole thing is ordered). This gives bubble sort an **O(n) best case** on already-sorted input: one pass, no swaps, return. Without this flag, bubble sort is O(n²) even on sorted input. **Always include the flag** — it's free and it's what the interviewer is checking for.

### Complexity
- **Worst / Average: O(n²)** — `n(n-1)/2 ≈ n²/2` comparisons.
- **Best: O(n)** — one pass with the flag.
- **Space: O(1)**, **Stable: yes**, **In-place: yes.**

### Interview Perspective
Bubble sort is **never** the right answer to "sort this." Its only interview roles:
1. As the brute force you mention and immediately discard: *"bubble sort would be O(n²); let me do better."*
2. To test whether you know the early-exit flag and the stability point.
3. Its one genuine virtue: **it detects sortedness in O(n)** and requires no extra memory. Essentially never useful in practice.

---

## 6.4 Selection Sort

### Intuition

Find the **minimum** of the unsorted region and swap it into the front. Repeat.

Where bubble sort does many small swaps, selection sort does **many comparisons but exactly `n-1` swaps** — one per pass, no matter what.

### Visual Explanation — every pass on `[64, 25, 12, 22, 11]`

```
INITIAL:  64  25  12  22  11
          ^^ all unsorted

=== PASS i=0: scan [0..4] for the minimum ===
   j=1: 25 < 64  -> minIdx = 1
   j=2: 12 < 25  -> minIdx = 2
   j=3: 22 > 12  -> no change
   j=4: 11 < 12  -> minIdx = 4
   minimum is 11 at index 4.  SWAP arr[0] <-> arr[4]:

   11 | 25  12  22  64
   ^^   ^^^^^^^^^^^^^^  sorted | unsorted

=== PASS i=1: scan [1..4] for the minimum ===
   j=2: 12 < 25  -> minIdx = 2
   j=3: 22 > 12  -> no change
   j=4: 64 > 12  -> no change
   minimum is 12 at index 2.  SWAP arr[1] <-> arr[2]:

   11  12 | 22  25  64
   ^^^^^^   ^^^^^^^^^^

=== PASS i=2: scan [2..4] ===
   j=3: 25 > 22.  j=4: 64 > 22.  minIdx stays 2.
   minimum is already at index 2. SWAP arr[2] <-> arr[2] (no-op):

   11  12  22 | 25  64

=== PASS i=3: scan [3..4] ===
   j=4: 64 > 25. minIdx stays 3. No-op swap.

   11  12  22  25 | 64

=== Done: last element is necessarily in place ===

FINAL:  11  12  22  25  64   ✓

Comparisons: 4 + 3 + 2 + 1 = 10 = n(n-1)/2   (ALWAYS, regardless of input)
Swaps:       4 = n - 1                        (ALWAYS)
```

### Java Implementation

```java
/** Selection sort. Minimises SWAPS at the cost of always doing n²/2 comparisons. */
public static void selectionSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;                        // assume the first unsorted element is smallest
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;                    // track the INDEX, not the value
            }
        }
        if (minIdx != i) {                     // skip pointless self-swaps
            int tmp = arr[i];
            arr[i] = arr[minIdx];
            arr[minIdx] = tmp;
        }
    }
}
```

### Line-by-Line

**`int minIdx = i;`** — track the **index**, not the value. If you tracked only the minimum value you couldn't swap it, because you wouldn't know where it lives. Beginners write `int minVal = arr[i]` and then get stuck.

**`for (int j = i + 1; j < n; j++)`** — start at `i + 1`, because `arr[i]` is already our candidate. Scan to the very end (`j < n`), because the minimum could be anywhere in the unsorted region. **Contrast with bubble sort, whose inner loop *shrinks* from the right; selection sort's inner loop shrinks from the *left*.**

**`if (minIdx != i)`** — a micro-optimisation, but it also documents intent. Swapping an element with itself is harmless but wasteful, and on an already-sorted array this check reduces swaps from `n-1` to `0`.

**Why is selection sort NOT stable?** The long-distance swap is the culprit:
```
   [ (4,a)  (4,b)  (1,c) ]     two 4s: 'a' before 'b'
   
   Pass 0: minimum is (1,c) at index 2. Swap index 0 and 2:
   [ (1,c)  (4,b)  (4,a) ]     'b' is now before 'a'  ->  ORDER BROKEN
```
One swap jumped over `(4,b)` and reversed the two equal elements. **This is why selection sort is unstable, and stating this example is exactly how to answer "why is selection sort unstable?"**

### Complexity
- **All cases: O(n²)** — the inner scan always runs to the end. **Not adaptive at all**; sorted input costs the same as reversed input.
- **Swaps: exactly O(n)** — its one genuine advantage.
- **Space: O(1)**, **Stable: no**, **In-place: yes.**

### Interview Perspective
The one situation where selection sort is genuinely the right choice: **when writes are far more expensive than reads.** Think EEPROM/flash memory with limited write cycles, or sorting records so large that moving them dominates. Selection sort does the theoretical minimum number of moves (n−1). Mentioning this specific niche shows you understand *why* algorithms exist rather than just what they do.

Also: selection sort is the conceptual ancestor of **heap sort**. Heap sort is "selection sort, but find the minimum in O(log n) instead of O(n) by using a heap." Understanding that link makes heap sort trivial to remember.

---

## 6.5 Insertion Sort

### Intuition

**How you actually sort a hand of playing cards.**

Hold a sorted hand on the left. Pick up the next card. Slide it leftward past every card larger than it, until it lands in the right spot. Repeat.

```
   Sorted hand: [3, 7, 9]      new card: 5
   
   Compare 5 with 9: 9 > 5, slide 9 right   [3, 7, _, 9]
   Compare 5 with 7: 7 > 5, slide 7 right   [3, _, 7, 9]
   Compare 5 with 3: 3 < 5, STOP            [3, 5, 7, 9]  <- insert here
```

This is the most *natural* sorting algorithm — you already know it — and it's genuinely useful in production.

### Visual Explanation — every pass on `[12, 11, 13, 5, 6]`

```
INITIAL:  12 | 11  13   5   6
          ^^^ a 1-element region is trivially sorted

=== i=1, key = 11 ===
   Compare with 12: 12 > 11  ->  shift 12 right
        12 |  _  13  5  6      (position 1 is now a hole)
        _  12 |  13  5  6
   j reaches -1  ->  insert key at index 0
   
   11  12 | 13   5   6

=== i=2, key = 13 ===
   Compare with 12: 12 < 13  ->  no shift needed, key is already in place
   
   11  12  13 |  5   6

=== i=3, key = 5 ===
   Compare with 13: 13 > 5  -> shift          11  12   _  13 |  6
   Compare with 12: 12 > 5  -> shift          11   _  12  13 |  6
   Compare with 11: 11 > 5  -> shift           _  11  12  13 |  6
   j reaches -1  ->  insert 5 at index 0
   
    5  11  12  13 |  6
   ^^^ 5 travelled 3 positions left. THREE shifts for ONE element.

=== i=4, key = 6 ===
   Compare with 13: 13 > 6  -> shift           5  11  12   _  13
   Compare with 12: 12 > 6  -> shift           5  11   _  12  13
   Compare with 11: 11 > 6  -> shift           5   _  11  12  13
   Compare with  5:  5 < 6  -> STOP            insert 6 at index 1
   
    5   6  11  12  13    ✓

FINAL:  5  6  11  12  13
```

**Now the crucial contrast — insertion sort on ALREADY SORTED input `[1,2,3,4,5]`:**

```
   i=1, key=2: compare with 1.  1 < 2  ->  STOP IMMEDIATELY. Zero shifts.
   i=2, key=3: compare with 2.  2 < 3  ->  STOP. Zero shifts.
   i=3, key=4: compare with 3.  3 < 4  ->  STOP. Zero shifts.
   i=4, key=5: compare with 4.  4 < 5  ->  STOP. Zero shifts.
   
   Total: 4 comparisons, 0 shifts.  ->  O(n)
```

**That is the O(n) best case, and it's why insertion sort matters.** Compare with selection sort, which would still do 10 comparisons on the same input. Insertion sort *notices* that the data is sorted; selection sort cannot.

### Java Implementation

```java
/** Insertion sort. O(n) on nearly-sorted data. Stable. The best O(n²) sort. */
public static void insertionSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    for (int i = 1; i < arr.length; i++) {     // start at 1: arr[0] alone is sorted
        int key = arr[i];                      // SAVE the element being inserted
        int j = i - 1;

        // Shift every element greater than key one slot to the right
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];               // shift right (NOT a swap — one write)
            j--;
        }
        arr[j + 1] = key;                      // drop key into the hole
    }
}

/** Insertion sort on a subrange — used by hybrid sorts like TimSort. */
public static void insertionSort(int[] arr, int lo, int hi) {
    for (int i = lo + 1; i <= hi; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= lo && arr[j] > key) { arr[j + 1] = arr[j]; j--; }
        arr[j + 1] = key;
    }
}
```

### Line-by-Line

**`int key = arr[i];`** — **you must save the value first.** The shifting loop is about to overwrite `arr[i]`. Forget this line and you'll duplicate an element and lose another. This is the #1 bug in insertion sort.

**`while (j >= 0 && arr[j] > key)`** — two conditions, and **the order matters.** `j >= 0` must come first: Java's `&&` short-circuits, so when `j` reaches `-1` we never evaluate `arr[-1]`. Reverse the order and you get `ArrayIndexOutOfBoundsException` on every element that belongs at index 0. **Short-circuit evaluation is doing real work here** — point this out in an interview.

**`arr[j + 1] = arr[j];` — a SHIFT, not a swap.**
```
   Swap:  3 writes (tmp = a; a = b; b = tmp)
   Shift: 1 write  (a = b)
```
Insertion sort does one write per displaced element; bubble sort does three per swap. Same asymptotic complexity, **~3× better constant factor.** This is precisely why insertion sort is the fastest of the three O(n²) sorts in practice, and why real libraries use it (not bubble sort) for small arrays.

**`arr[j + 1] = key;` — why `j + 1`?** The `while` loop exits when `arr[j] <= key` (or `j < 0`). At that moment `arr[j]` should stay put, and the hole is at `j + 1`. Off-by-one here is the second most common bug; trace the `[12, 11]` case by hand if it feels unclear.

**`arr[j] > key`, strictly greater** — again the stability guarantee. With `>=`, an equal element would be shifted past, reversing equal pairs.

### Complexity

Let's derive it honestly, because the derivation is the interview answer.

**Worst case (reverse-sorted input):** element `i` must travel all the way to index 0, requiring `i` shifts.
```
   Total shifts = 1 + 2 + 3 + ... + (n-1) = n(n-1)/2 = O(n²)
```
**Best case (sorted input):** the `while` condition fails immediately every time.
```
   Total = (n-1) comparisons, 0 shifts = O(n)
```
**Average case:** each element travels about half the distance → `n²/4` → still **O(n²)**.

**The property that makes it valuable: for an array where each element is at most `k` positions from its final place, insertion sort runs in O(n·k).** For nearly-sorted data (`k` small and constant), that's **effectively O(n)** — faster than merge sort's O(n log n). This is a real, exploitable fact.

- **Space: O(1)**, **Stable: yes**, **Adaptive: yes**, **In-place: yes.**

### Interview Perspective

**Insertion sort is the O(n²) sort you should actually know cold**, because it appears inside real production sorts:

- **`java.util.Arrays.sort(int[])`** uses dual-pivot quicksort, but **switches to insertion sort for subarrays under 47 elements.**
- **`java.util.Arrays.sort(Object[])`** uses TimSort, which **builds "runs" using binary insertion sort** on segments under 32 elements, then merges them.
- **C++'s `std::sort`** (introsort) switches to insertion sort below ~16 elements.

**Why do all of these switch?** Because for small `n`, O(n²) with tiny constants beats O(n log n) with recursion overhead, cache misses, and function-call cost. `n²/4 < n log n × C` when `n` is small. **Explaining this in an interview — that real sorts are hybrids, and why — is a genuinely strong answer to "which sort would you use?"**

The other must-know use: **insertion sort is the natural choice for an online algorithm** — one where data arrives one element at a time and you must maintain a sorted structure. Merge sort and quicksort need the whole array upfront; insertion sort doesn't.

---
## 6.6 Merge Sort

### Intuition

**Two sorted lists can be merged into one sorted list in a single linear pass.**

That's the entire insight. If you believe it, merge sort writes itself: split the array in half, sort each half (by magic — the recursive leap of faith from Module 4), then merge.

Why is merging linear? Because the smallest remaining element overall must be at the front of one of the two lists. So you only ever compare the two front elements:

```
   Left:  [1, 4, 9]        Right: [2, 3, 8]
           ^                       ^
   Compare 1 vs 2 -> take 1. The smallest of everything MUST be one of these two.
   
   Left:  [4, 9]           Right: [2, 3, 8]      output: [1]
   Compare 4 vs 2 -> take 2.
   
   Left:  [4, 9]           Right: [3, 8]         output: [1, 2]
   Compare 4 vs 3 -> take 3.
   ... and so on. Each comparison outputs exactly one element. -> O(n).
```

Merge sort is the cleanest example of **divide and conquer**, and — critically — it is the sort with a **guaranteed** O(n log n). No adversarial input can slow it down. That guarantee is why it's used for external sorting (files too large for RAM), for linked lists, and inside TimSort.

### Visual Explanation — the full recursion tree on `[38, 27, 43, 3, 9, 82, 10]`

**Phase 1 — DIVIDE (going down). No comparisons happen here; we just split.**

```
                    [38, 27, 43, 3, 9, 82, 10]
                              |
                 +------------+------------+
                 |                         |
          [38, 27, 43, 3]            [9, 82, 10]
                 |                         |
          +------+------+            +-----+-----+
          |             |            |           |
      [38, 27]      [43, 3]        [9, 82]      [10]
          |             |            |            
      +---+---+     +---+---+    +---+---+       
      |       |     |       |    |       |       
    [38]    [27]  [43]     [3]  [9]    [82]     

   Depth = log2(7) rounded up = 3 levels of splitting.
   Bottom: 7 single-element arrays. A single element is sorted by definition.
```

**Phase 2 — CONQUER (coming back up). All the work happens here.**

```
LEVEL 3 -> LEVEL 2:  merge pairs of singletons

   merge [38], [27]:  compare 38 vs 27 -> 27, then 38   -->  [27, 38]
   merge [43], [3] :  compare 43 vs 3  -> 3,  then 43   -->  [3, 43]
   merge [9], [82] :  compare 9 vs 82  -> 9,  then 82   -->  [9, 82]
   [10] stays [10]

   State:  [27, 38]   [3, 43]   [9, 82]   [10]


LEVEL 2 -> LEVEL 1:  merge pairs of 2-element arrays

   merge [27, 38] and [3, 43]:
       L=[27,38] R=[3,43]  out=[]
       27 vs 3   -> take 3      out=[3]
       27 vs 43  -> take 27     out=[3,27]
       38 vs 43  -> take 38     out=[3,27,38]
       L exhausted -> drain R   out=[3,27,38,43]

   merge [9, 82] and [10]:
       9 vs 10   -> take 9      out=[9]
       82 vs 10  -> take 10     out=[9,10]
       R exhausted -> drain L   out=[9,10,82]

   State:  [3, 27, 38, 43]   [9, 10, 82]


LEVEL 1 -> LEVEL 0:  the final merge

   L = [3, 27, 38, 43]     R = [9, 10, 82]     out = []

   i     j
   3 vs  9   -> 3  smaller  -> out=[3]                        i->1
   27 vs 9   -> 9  smaller  -> out=[3,9]                      j->1
   27 vs 10  -> 10 smaller  -> out=[3,9,10]                   j->2
   27 vs 82  -> 27 smaller  -> out=[3,9,10,27]                i->2
   38 vs 82  -> 38 smaller  -> out=[3,9,10,27,38]             i->3
   43 vs 82  -> 43 smaller  -> out=[3,9,10,27,38,43]          i->4 (L exhausted)
   drain R   -> 82          -> out=[3,9,10,27,38,43,82]

FINAL:  [3, 9, 10, 27, 38, 43, 82]   ✓
```

**Now look at the work per level — this is the complexity proof:**

```
   Level 0:  merge 7 elements total          -> 7 operations
   Level 1:  merge 4 + 3 = 7 elements        -> 7 operations
   Level 2:  merge 2+2+2+1 = 7 elements      -> 7 operations
   Level 3:  (base cases, no work)

   EVERY level touches every element exactly once  ->  O(n) per level
   Number of levels = log₂ n
   Total = O(n log n)      <- and this is unconditional
```

That's the whole proof, and it's the same recursion-tree argument from Module 1, Hard Problem 1.

### Java Implementation

```java
/** Top-down merge sort. Guaranteed O(n log n), stable, O(n) extra space. */
public static void mergeSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int[] buffer = new int[arr.length];        // ONE buffer, allocated ONCE
    mergeSort(arr, buffer, 0, arr.length - 1);
}

private static void mergeSort(int[] arr, int[] buffer, int lo, int hi) {
    if (lo >= hi) return;                      // base case: 0 or 1 element

    // Hybrid optimisation: insertion sort is faster on small ranges
    if (hi - lo + 1 <= 16) {
        insertionSort(arr, lo, hi);
        return;
    }

    int mid = lo + (hi - lo) / 2;              // overflow-safe
    mergeSort(arr, buffer, lo, mid);            // sort left half
    mergeSort(arr, buffer, mid + 1, hi);        // sort right half

    if (arr[mid] <= arr[mid + 1]) return;      // already ordered -> skip the merge
    merge(arr, buffer, lo, mid, hi);
}

private static void merge(int[] arr, int[] buffer, int lo, int mid, int hi) {
    // Copy the range we're about to overwrite into the buffer
    System.arraycopy(arr, lo, buffer, lo, hi - lo + 1);

    int i = lo;          // cursor into the left half of the BUFFER
    int j = mid + 1;     // cursor into the right half of the BUFFER
    int k = lo;          // write cursor into the ORIGINAL array

    while (i <= mid && j <= hi) {
        if (buffer[i] <= buffer[j]) {          // <= PRESERVES STABILITY
            arr[k++] = buffer[i++];
        } else {
            arr[k++] = buffer[j++];
        }
    }
    while (i <= mid) arr[k++] = buffer[i++];   // drain leftovers from the left
    // No need to drain the right: those elements are already in place in arr.
}
```

### Line-by-Line

**`int[] buffer = new int[arr.length];` — allocated ONCE, outside the recursion.**
This is the most important engineering decision in the file. The naive implementation allocates two new arrays inside every `merge` call:
```java
int[] left = new int[n1];  int[] right = new int[n2];   // BAD: allocates at every node
```
There are O(n) nodes in the recursion tree, so that's O(n) allocations — enormous GC pressure. One shared buffer, reused at every level, gives the same O(n) space with **one** allocation. **Mentioning this optimisation unprompted is a strong senior signal.**

**`if (lo >= hi) return;`** — base case. `lo == hi` means one element (sorted). `lo > hi` means empty. `>=` covers both.

**`if (hi - lo + 1 <= 16) { insertionSort(arr, lo, hi); return; }`**
The hybrid cut-off. Below ~16 elements, insertion sort's tiny constants beat recursion overhead. This typically gives a **10–25% real-world speedup** and is exactly what production sorts do (§6.5). Note it doesn't change the asymptotic complexity — the bottom `log 16` levels of the tree are simply replaced by one insertion sort each.

**`int mid = lo + (hi - lo) / 2;`** — the overflow-safe form from Module 5. In an array of 2 billion elements, `lo + hi` would overflow.

**`if (arr[mid] <= arr[mid + 1]) return;`**
A beautiful, cheap adaptivity check. If the largest element of the sorted left half is `<=` the smallest of the sorted right half, then concatenating them is *already* sorted — the merge would just copy everything back unchanged. One comparison saves an O(n) pass. **On already-sorted input this makes merge sort O(n log n) with almost no data movement**, and on real-world partially-sorted data it's a significant win. This is one of TimSort's core ideas in miniature.

**`System.arraycopy(arr, lo, buffer, lo, hi - lo + 1);`**
Note we copy into the buffer at **the same indices** (`lo` → `lo`), not starting at 0. That means `i` and `j` can index the buffer using the same coordinates as the original array — no index translation, no off-by-one arithmetic. **This is why the merge loop is so clean.** A JVM intrinsic, so it's as fast as `memcpy`.

**`if (buffer[i] <= buffer[j])` — the `<=` is the stability guarantee.**
When the two values are **equal**, we take from the **left** half. The left half holds elements that came earlier in the original array, so equal elements retain their original relative order. Change this to `<` and merge sort becomes **unstable**.

```
   Left half (earlier in original):  [ (5,a) ]
   Right half (later in original):   [ (5,b) ]

   With <= : take left first  ->  [(5,a), (5,b)]   original order preserved  ✅
   With <  : 5 < 5 is false   ->  take right first ->  [(5,b), (5,a)]        ❌
```

**This one character is the entire stability property of merge sort.** It is one of the most commonly asked "explain this line" questions in interviews. Know it.

**`while (i <= mid) arr[k++] = buffer[i++];` — and why there's no matching right drain.**
Subtle and elegant. If the left half is exhausted first, the remaining right-half elements are already sitting in `arr` at exactly the positions they need to be — we copied them there... actually, we never *moved* them; `arr[k..hi]` still holds the original right-half values in order, and `k` has advanced to exactly where they start. So draining the right is a no-op copy. Omitting it is correct and saves work.

Prove it to yourself: if `i > mid` (left exhausted), then the number of elements written so far is `(mid - lo + 1) + (j - mid - 1) = j - lo`, so `k = lo + (j - lo) = j`. Writing `arr[k] = buffer[j]` for the rest is writing each value back to its own position. Genuinely a no-op. **Explaining this in an interview is a real flex.**

### Complexity

- **Time: O(n log n) in all cases** — best, average, worst. `log n` levels × O(n) work per level. **No input can degrade it.** This unconditional guarantee is merge sort's defining virtue.
- **Space: O(n)** for the buffer, plus **O(log n)** for the recursion stack → **O(n)** overall. This is merge sort's defining weakness.
- **Stable: yes.** **In-place: no.**

**Recurrence:** `T(n) = 2T(n/2) + O(n)` → `Θ(n log n)` by the Master Theorem, or by the level-summing argument above (which is better to present).

### Interview Perspective

**When to choose merge sort:**
1. **Stability is required.** (Sorting objects by a secondary key.)
2. **You need a worst-case guarantee.** (Real-time systems, adversarial input, SLA guarantees.)
3. **Sorting a linked list.** Merge sort is *the* answer here — it needs no random access, and it can be done with **O(1) extra space** on a linked list by relinking pointers instead of copying. Quicksort on a linked list is awkward; heap sort is impossible without random access. **"How do you sort a linked list in O(n log n)?" → merge sort. Have this ready.**
4. **External sorting.** Data too large for RAM: sort chunks that fit in memory, write them to disk, then k-way merge the sorted files. Merge sort is inherently sequential-access, which is exactly what disks and tapes want.
5. **Counting inversions** and other divide-and-conquer counting problems (see the Hard problem in §6.13).

**The classic follow-up:** *"Merge sort is O(n log n) guaranteed and quicksort can be O(n²). Why does the JDK use quicksort for primitives?"*

Your answer: *"Three reasons. Quicksort is in-place, so no O(n) buffer. Its constant factor is smaller — partitioning is a tight sequential scan with excellent cache locality, while merging requires copying to and from a buffer. And with randomised or median-of-three pivot selection, the O(n²) case becomes astronomically unlikely. For objects, though, the JDK uses TimSort — because stability is required for `Comparator`-based sorting and object comparisons are expensive enough that TimSort's run-detection pays for itself."*

That answer covers memory, constants, cache, probability, and the primitive/object split. It is close to a complete answer to "tell me about sorting."

---

## 6.7 Quick Sort

### Intuition

**Pick a pivot. Put everything smaller on its left, everything larger on its right. The pivot is now in its FINAL position. Recurse on both sides.**

The contrast with merge sort is illuminating:
```
   MERGE SORT:  divide trivially (just split in half), 
                combine with effort (the merge does the work)

   QUICK SORT:  divide with effort (partitioning does the work),
                combine trivially (nothing to do — the pieces are already in place)
```

Quicksort front-loads the work. And that's why it needs no buffer: after partitioning, the left part, the pivot, and the right part are already in their correct **regions** of the same array. There is nothing to merge.

### Visual Explanation — Lomuto partition on `[10, 80, 30, 90, 40, 50, 70]`

We'll use the last element as pivot: **70**.

```
Array:   10  80  30  90  40  50  70
                                 ^^ pivot

The invariant we maintain:
   +------------------+------------------+-------+
   |  all <= pivot    |  all > pivot     | unseen|  pivot
   +------------------+------------------+-------+
   lo               i    i+1           j-1        hi
   
   i = boundary of the "<= pivot" region (starts at lo-1)
   j = scanning cursor

--- j=0, arr[0]=10.  10 <= 70?  YES ---
    i moves from -1 to 0. Swap arr[0] with arr[0] (self, no-op).
    10 | 80  30  90  40  50 | 70
    ^^ small region = {10}

--- j=1, arr[1]=80.  80 <= 70?  NO  ---
    Do nothing. 80 stays in the "large" region.
    10 | 80 | 30  90  40  50 | 70
       small  large={80}

--- j=2, arr[2]=30.  30 <= 70?  YES ---
    i moves 0 -> 1. Swap arr[1] and arr[2]:  80 <-> 30
    10  30 | 80 | 90  40  50 | 70
    ^^^^^^  small={10,30}, large={80}

--- j=3, arr[3]=90.  90 <= 70?  NO ---
    Do nothing.
    10  30 | 80  90 | 40  50 | 70
            large={80,90}

--- j=4, arr[4]=40.  40 <= 70?  YES ---
    i moves 1 -> 2. Swap arr[2] and arr[4]:  80 <-> 40
    10  30  40 | 90  80 | 50 | 70
    ^^^^^^^^^^  small={10,30,40}
                Note: 80 and 90 are still both in the "large" region,
                just internally reordered. That's fine — and it's WHY
                quicksort is unstable.

--- j=5, arr[5]=50.  50 <= 70?  YES ---
    i moves 2 -> 3. Swap arr[3] and arr[5]:  90 <-> 50
    10  30  40  50 | 80  90 | 70
    ^^^^^^^^^^^^^^  small={10,30,40,50}

--- j reaches hi. FINAL STEP: place the pivot ---
    Swap arr[i+1] with arr[hi]:  arr[4]=80 <-> arr[6]=70
    
    10  30  40  50  70  90  80
                    ^^ PIVOT IS HOME. Index 4. FOREVER.
    
    <---- all <= 70 ----> ^  <-- all > 70 -->

Return 4 (the pivot's final index).

Now recurse on [10,30,40,50] (indices 0..3) and [90,80] (indices 5..6).
Nothing needs to be merged afterward.
```

**Read that final line again:** `70` is at index 4 and will *never move again*. That's the guarantee partitioning gives you, and it's what eliminates the combine step.

### Java Implementation

```java
import java.util.Random;

private static final Random RNG = new Random();

/** Quicksort with randomised pivot, tail-call elimination, and hybrid cutoff. */
public static void quickSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    quickSort(arr, 0, arr.length - 1);
}

private static void quickSort(int[] arr, int lo, int hi) {
    while (lo < hi) {                                  // loop instead of tail recursion
        if (hi - lo + 1 <= 16) {                       // hybrid cutoff
            insertionSort(arr, lo, hi);
            return;
        }

        int pivotIdx = lo + RNG.nextInt(hi - lo + 1);   // RANDOM pivot
        swap(arr, pivotIdx, hi);                        // move it to the end
        int p = partition(arr, lo, hi);

        // Recurse into the SMALLER side; loop on the larger.
        // This bounds stack depth at O(log n) even in the worst case.
        if (p - lo < hi - p) {
            quickSort(arr, lo, p - 1);
            lo = p + 1;                                 // tail-call eliminated
        } else {
            quickSort(arr, p + 1, hi);
            hi = p - 1;
        }
    }
}

/** Lomuto partition. Returns the pivot's final index. */
private static int partition(int[] arr, int lo, int hi) {
    int pivot = arr[hi];
    int i = lo - 1;                                     // boundary of the "<= pivot" region

    for (int j = lo; j < hi; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i + 1, hi);                               // pivot into its final slot
    return i + 1;
}

private static void swap(int[] a, int x, int y) {
    int t = a[x]; a[x] = a[y]; a[y] = t;
}
```

### Line-by-Line

**`int pivotIdx = lo + RNG.nextInt(hi - lo + 1);` — randomisation is not optional.**

With a fixed pivot (say, always the last element), the worst case is triggered by **sorted input** — the most common real-world case:
```
   Sorted [1,2,3,4,5], pivot = last = 5.
   Partition: everything is <= 5, so the pivot lands at the end.
   Left subarray = [1,2,3,4]  (size n-1),  Right = empty.
   
   Recursion: n -> n-1 -> n-2 -> ... -> 1
   Depth = n.  Work per level = n.  ->  O(n²) time AND O(n) stack (StackOverflowError!)
```

**A fixed-pivot quicksort is quadratic on sorted data.** That is a catastrophic, easily-triggered failure — and in a networked service it's a denial-of-service vector (an attacker sends pre-sorted input). Randomisation makes the probability of a bad split independent of the input, so no adversary can force it. **Expected** time becomes O(n log n) with the worst case occurring with probability ~1/n!.

Alternatives: **median-of-three** (take the median of first, middle, last) is cheaper than randomisation and handles sorted input well, but is still defeatable by a crafted input. The JDK's dual-pivot quicksort uses a sophisticated median-of-five-ish scheme plus a check that falls back to merge sort on detected structure.

**`swap(arr, pivotIdx, hi);`** — after choosing a random pivot, move it to the end so `partition` can use its standard "pivot is at `hi`" convention. Cleaner than parameterising the partition.

**`int i = lo - 1;`** — the boundary starts *before* the array, meaning "the `<= pivot` region is currently empty." This is why the first qualifying element triggers `i++` to `lo` and then a self-swap. Slightly odd-looking, but it makes the invariant uniform with no special cases.

**`if (arr[j] <= pivot)`** — `<=`, not `<`. Why? Consider an array of all-identical elements `[5,5,5,5,5]` with pivot 5:
```
   With <= : every element qualifies, i advances each time,
             pivot lands in the MIDDLE. Balanced split. O(n log n).  ✅
   With <  : NO element qualifies, i stays at lo-1,
             pivot lands at position lo. Left empty, right = n-1.
             -> O(n²) on all-duplicate input.                        ❌
```
**One character, and duplicate-heavy input goes from O(n log n) to O(n²).** Arrays with many duplicates are extremely common in practice (sorting by status, category, boolean flags). This is why serious implementations use **three-way partitioning** (Dutch National Flag) which groups `< pivot`, `== pivot`, `> pivot` and achieves O(n) on all-duplicate input.

**`swap(arr, i + 1, hi);`** — the final placement. After the loop, `arr[lo..i]` are all `<= pivot` and `arr[i+1..hi-1]` are all `> pivot`. Position `i+1` holds the first "large" element, which is exactly where the pivot belongs. Swapping sends that large element to the end (still in the "large" region — correct) and brings the pivot to `i+1`.

**`while (lo < hi)` with `lo = p + 1` — tail-call elimination by hand.**
The natural code is:
```java
quickSort(arr, lo, p - 1);
quickSort(arr, p + 1, hi);     // this call is in TAIL POSITION
```
Java doesn't optimise tail calls (Module 4), so the second call costs a frame. Rewriting it as a loop assignment (`lo = p + 1; continue;`) eliminates one of the two recursive branches. Combined with **always recursing into the smaller half**, this bounds the stack at:

```
   Each recursive call handles a range of size <= half the current range.
   So depth <= log2(n).   ->  O(log n) space, GUARANTEED,
                              even if partitions are maximally unbalanced.
```

**This is the fix for quicksort's `StackOverflowError` risk.** Without it, worst-case partitioning gives O(n) stack depth and a crash on large arrays. With it, quicksort's *space* is O(log n) unconditionally, even when its *time* degrades. Explaining this optimisation is one of the strongest things you can say about quicksort in an interview — very few candidates know it.

### Complexity

**Best/average — balanced partitions:**
```
   T(n) = 2T(n/2) + O(n)  ->  O(n log n)
   
   Even a 90/10 split is fine:
   T(n) = T(0.9n) + T(0.1n) + O(n)
   Depth = log_{10/9}(n) ≈ 6.6 log₂ n   -> still O(n log n), just a bigger constant.
```
**Quicksort is remarkably robust to unbalanced splits.** You need *consistently* terrible splits to hit O(n²).

**Worst — maximally unbalanced:**
```
   T(n) = T(n-1) + O(n)  ->  n + (n-1) + ... + 1 = O(n²)
```
Probability with a random pivot: vanishingly small (you'd need to pick the min or max at every level).

**Space: O(log n)** with the smaller-side-first optimisation. O(n) without it.

**Stable: no** — long-distance swaps in `partition` reorder equal elements (see the `j=4` step in the dry run, where 80 and 90 swapped places).

### Interview Perspective

**The single most important thing to be able to say:** *"Quicksort is O(n log n) on average but O(n²) in the worst case. I mitigate that with a randomised pivot, which makes the bad case independent of the input, and I recurse into the smaller partition first to bound stack depth at O(log n)."*

**"Why is quicksort used more than merge sort despite the worse guarantee?"**
1. **In-place** — O(log n) space vs O(n).
2. **Better constants** — partitioning is one sequential pass with excellent cache locality; merging requires reading and writing a separate buffer.
3. **Randomisation** makes the worst case practically impossible.
4. And where the guarantee genuinely matters, hybrids like **introsort** (used by C++'s `std::sort`) detect excessive recursion depth and switch to heap sort — getting quicksort's speed with merge sort's guarantee.

**Quickselect — the essential relative.** If you only need the kth smallest element, you don't need to sort both halves:
```java
// After partitioning, if p == k you're done. Otherwise recurse into ONE side only.
   T(n) = T(n/2) + O(n)  ->  O(n) EXPECTED, not O(n log n)
```
This solves "find the kth largest element" and "find the median" in **expected O(n)**. It's a top-10 interview question and it falls straight out of the partition function you just wrote. **Know that quickselect exists and that it's O(n) expected, O(n²) worst.**

---

## 6.8 Heap Sort

### Intuition

**Selection sort's problem is that finding the maximum costs O(n). A heap finds the maximum in O(1) and removes it in O(log n).**

That's the whole idea. Heap sort is selection sort with a better tool:
```
   Selection sort: n passes × O(n) to find the max  ->  O(n²)
   Heap sort:      n passes × O(log n) to extract the max  ->  O(n log n)
```

A **max-heap** is a complete binary tree where every parent is `>=` its children. The maximum is always at the root. Stored in an array with no pointers:

```
   For index i (0-based):
       parent(i)      = (i - 1) / 2
       leftChild(i)   = 2i + 1
       rightChild(i)  = 2i + 2

   Tree:              Array:
        50            [50, 30, 40, 10, 20, 35]
       /  \             0   1   2   3   4   5
     30    40
    /  \   /
  10   20 35

   Check: parent of index 4 (value 20) = (4-1)/2 = 1 -> value 30.  ✓ 30 >= 20
          children of index 1 = indices 3, 4 -> values 10, 20.     ✓ 30 >= both
```

We'll cover heaps properly in Module 12. Here we just use them to sort.

### Visual Explanation — heap sort on `[4, 10, 3, 5, 1]`

**Phase 1 — BUILD the max-heap (bottom-up heapify).**

```
Initial array: [4, 10, 3, 5, 1]

Tree view:        4
                /   \
              10     3
             /  \
            5    1

Start from the last NON-LEAF node: index (n/2 - 1) = (5/2 - 1) = 1.
(Leaves are already valid 1-element heaps — no need to touch indices 2,3,4.)

--- heapify(index 1, value 10) ---
   children: index 3 (5), index 4 (1).  Largest of {10, 5, 1} is 10 = itself.
   No swap needed.
        4
      /   \
    10     3
   /  \
  5    1

--- heapify(index 0, value 4) ---
   children: index 1 (10), index 2 (3).  Largest of {4, 10, 3} is 10 at index 1.
   SWAP index 0 and 1:
       10
      /   \
     4     3
    /  \
   5    1
   Array: [10, 4, 3, 5, 1]
   
   Now RECURSE down: 4 moved to index 1. Is the subtree at index 1 still valid?
   heapify(index 1, value 4): children are 5 (idx 3) and 1 (idx 4).
   Largest of {4, 5, 1} is 5 at index 3. SWAP index 1 and 3:
       10
      /   \
     5     3
    /  \
   4    1
   Array: [10, 5, 3, 4, 1]
   
   Recurse to index 3: it's a leaf. Done.

MAX-HEAP BUILT:  [10, 5, 3, 4, 1]
       10
      /   \
     5     3
    /  \
   4    1
   Verify: 10>=5,3 ✓   5>=4,1 ✓   Valid max-heap.
```

**Phase 2 — SORT by repeatedly extracting the max.**

```
--- Extraction 1 ---
   Swap root (index 0) with the LAST heap element (index 4):
   [1, 5, 3, 4 | 10]
                 ^^^ 10 is HOME (largest, goes at the end). Heap size shrinks to 4.
   
   Heap is now broken at the root (1 is too small). heapify(0) on size 4:
       1                     5
      / \        ->         / \
     5   3                 4   3
    /                     /
   4                     1
   heapify(0): children 5,3 -> largest 5 at idx 1. Swap 0,1: [5,1,3,4|10]
   heapify(1): child 4 at idx 3 -> largest 4. Swap 1,3:      [5,4,3,1|10]
   
   Array: [5, 4, 3, 1 | 10]

--- Extraction 2 ---
   Swap index 0 with index 3:  [1, 4, 3 | 5, 10]
   heapify(0) on size 3: children 4 (idx1), 3 (idx2). Largest 4. Swap:
                                [4, 1, 3 | 5, 10]
   heapify(1): idx 1 has no children within size 3? left = 3, which is >= size. Done.
   
   Array: [4, 1, 3 | 5, 10]

--- Extraction 3 ---
   Swap index 0 with index 2:  [3, 1 | 4, 5, 10]
   heapify(0) on size 2: child 1 (idx 1). 3 >= 1, no swap.
   
   Array: [3, 1 | 4, 5, 10]

--- Extraction 4 ---
   Swap index 0 with index 1:  [1 | 3, 4, 5, 10]
   heapify(0) on size 1: nothing to do.

--- Heap size is 1: done ---

FINAL:  [1, 3, 4, 5, 10]   ✓
```

**Notice the array's dual life:**
```
   +---------------------------+------------------------+
   |     ACTIVE MAX-HEAP       |   SORTED (final)       |
   +---------------------------+------------------------+
   0                   size-1  size                   n-1
   
   The boundary marches LEFT. One array, two data structures. Zero extra space.
```

### Java Implementation

```java
/** Heap sort. Guaranteed O(n log n) with O(1) space. Not stable. */
public static void heapSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    // PHASE 1: build a max-heap, bottom-up. O(n) — see the analysis below.
    for (int i = n / 2 - 1; i >= 0; i--) {
        siftDown(arr, i, n);
    }

    // PHASE 2: repeatedly move the max to the end and restore the heap.
    for (int end = n - 1; end > 0; end--) {
        swap(arr, 0, end);           // max goes to its final position
        siftDown(arr, 0, end);       // restore heap property on the shrunken heap
    }
}

/**
 * Restores the max-heap property at index i, for a heap occupying arr[0, size).
 * Moves arr[i] down until both children are <= it.
 */
private static void siftDown(int[] arr, int i, int size) {
    while (true) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int largest = i;

        if (left  < size && arr[left]  > arr[largest]) largest = left;
        if (right < size && arr[right] > arr[largest]) largest = right;

        if (largest == i) return;    // heap property satisfied -> stop
        swap(arr, i, largest);
        i = largest;                 // follow the element down (iterative, no stack)
    }
}
```

### Line-by-Line

**`for (int i = n / 2 - 1; i >= 0; i--)`**
`n/2 - 1` is the index of the **last non-leaf node**. Everything from `n/2` to `n-1` is a leaf, and a single node is trivially a valid heap. Starting there skips half the array for free.

We iterate **downward** (`i--`), which is essential: `siftDown(i)` assumes both subtrees of `i` are already valid heaps. Processing from the bottom up guarantees that. Going top-down would be wrong.

**Why is Phase 1 O(n) and not O(n log n)?** This is a genuinely surprising result and a favourite interview question.

Naive reasoning: n/2 calls to `siftDown`, each O(log n) → O(n log n). **But that's a loose bound**, because most nodes are near the *bottom*, where `siftDown` has almost nowhere to go:

```
   Level (from bottom)   #nodes      max sift distance    work
   -------------------   ---------   ------------------   --------
   0 (leaves)            n/2         0                    0
   1                     n/4         1                    n/4
   2                     n/8         2                    2n/8
   3                     n/16        3                    3n/16
   ...
   log n (root)          1           log n                log n

   Total = Σ (h × n/2^(h+1)) for h = 0..log n
         = n × Σ (h / 2^(h+1))
         = n × (1/2 · Σ h/2^h)
   
   And Σ h/2^h converges to 2.   ->  Total = n × 1 = O(n)
```

**Half the nodes do zero work. Only one node does log n work.** The sum converges, giving **O(n)** for building a heap. Say this in an interview — it's precise, non-obvious, and demonstrates real analytical skill.

**`for (int end = n - 1; end > 0; end--)`**
`end` is both "the last index of the current heap" and "where the extracted max should go." Stop at `end > 0`: when only one element remains, it's necessarily the minimum and already in place.

**`swap(arr, 0, end);`**
The root holds the maximum of the remaining heap. Swapping it to `end` places it in its final sorted position and simultaneously brings a (likely small) leaf value to the root — which is why we must immediately restore the heap.

**`siftDown(arr, 0, end);` — note `end`, not `end + 1`.**
`size = end` means the heap now occupies `arr[0..end-1]`, **excluding** the element we just placed at `end`. If you pass `end + 1`, the sifting will see the already-finalised maximum, pull it back into the heap, and the sort silently produces garbage. **This off-by-one is the classic heap sort bug.** Trace it once with `n = 3` to burn it in.

**`if (left < size && arr[left] > arr[largest])`**
The bounds check `left < size` comes **first** — short-circuit `&&` prevents reading past the heap boundary into the sorted region. Same pattern as insertion sort's `j >= 0 &&`.

**`i = largest;` inside a `while (true)` — iteration, not recursion.**
`siftDown` is naturally tail-recursive, so converting it to a loop is mechanical (Module 4, §4.5) and eliminates O(log n) stack frames. **This is what gives heap sort its O(1) space.** If you write `siftDown` recursively, heap sort becomes O(log n) space — still good, but you've given away its unique selling point.

### Complexity

- **Time: O(n log n) in ALL cases.** Phase 1 is O(n); Phase 2 is n extractions × O(log n) sift = O(n log n). Total O(n log n). **No input degrades it** — same guarantee as merge sort.
- **Space: O(1).** The only algorithm here with *both* a guaranteed O(n log n) and O(1) space.
- **Stable: no.** The root-to-end swap moves elements arbitrarily far.
- **Adaptive: no.** Sorted input costs the same.

### Interview Perspective

**The question you must be able to answer:** *"Heap sort has a better worst case than quicksort and better space than merge sort. Why isn't it the default?"*

*"Cache locality. Quicksort's partition is a linear scan — the CPU prefetcher loads the next cache line and it's exactly what you need. Heap sort's `siftDown` jumps from index `i` to `2i+1`, which for large arrays is a different cache line, then a different page. Every level of every sift is potentially a cache miss. So despite identical Big O, heap sort typically runs 2–3× slower than quicksort in wall-clock time on large arrays. Big O measures comparisons, not memory latency."*

That answer demonstrates that you understand the gap between theoretical and practical performance, which is exactly what distinguishes senior engineers.

**Where heap sort genuinely shines:**
1. **Memory-constrained environments** — embedded systems where an O(n) buffer is unaffordable.
2. **As the fallback in introsort** — C++'s `std::sort` starts with quicksort and switches to heap sort if recursion depth exceeds `2 log n`, converting quicksort's O(n²) risk into a guaranteed O(n log n). **Best of both worlds; this is the design to describe if asked "how would you build a production sort?"**
3. **The heap itself** is far more useful than heap sort — `PriorityQueue`, top-k problems, Dijkstra, median maintenance. Module 12.

**The top-k insight:** for "find the k largest of n elements", don't sort. Build a **min-heap of size k** and stream through the data: **O(n log k)** time, **O(k)** space. For n = 10⁹ and k = 10, that's essentially O(n) with 10 elements of memory. Sorting would be O(n log n) and require all n in memory. This is one of the most practically useful algorithms in this entire course.

---

## 6.9 Counting Sort

### Intuition

**If you know the values are small integers, don't compare them at all — just count them.**

To sort exam scores from 0 to 100, you don't compare scores. You tally how many students got each score, then read the tally in order.

```
   Input:  [3, 1, 3, 0, 2, 1, 3]
   
   Tally:  value:  0  1  2  3
           count:  1  2  1  3
   
   Read out: 0 once, 1 twice, 2 once, 3 three times
   Output: [0, 1, 1, 2, 3, 3, 3]   ✓
   
   Zero comparisons were performed.
```

This **breaks the Ω(n log n) barrier** — legally, because the barrier applies only to comparison-based sorts (§6.12). We're not comparing; we're using values as array indices, which is a fundamentally more powerful operation.

### Visual Explanation on `[4, 2, 2, 8, 3, 3, 1]`, k = 9 (values 0..8)

```
--- STEP 1: count occurrences ---
   
   count[v] = how many times v appears
   
   index:  0  1  2  3  4  5  6  7  8
   count:  0  1  2  2  1  0  0  0  1
              ^  ^  ^  ^           ^
              |  |  |  |           +-- one 8
              |  |  |  +-- one 4
              |  |  +-- two 3s
              |  +-- two 2s
              +-- one 1

--- STEP 2: prefix-sum the counts ---

   Transform count[] into "how many elements are <= v"
   
   count[i] += count[i-1]  for i = 1..k-1
   
   before:  0  1  2  2  1  0  0  0  1
   after:   0  1  3  5  6  6  6  6  7
            ^  ^  ^  ^  ^           ^
            |  |  |  |  |           +-- 7 elements are <= 8 (all of them)
            |  |  |  |  +-- 6 elements are <= 4
            |  |  |  +-- 5 elements are <= 3
            |  |  +-- 3 elements are <= 2
            |  +-- 1 element is <= 1
            +-- 0 elements are <= 0

   INTERPRETATION: count[v] is now the index JUST PAST where the last v goes.
   So count[v] - 1 is where the last occurrence of v belongs.

--- STEP 3: place elements, iterating the INPUT BACKWARD ---

   Why backward? For STABILITY. See the explanation below.
   
   input:  [4, 2, 2, 8, 3, 3, 1]
                                ^ start here (i = 6)
   
   i=6, v=1:  count[1]=1  ->  place at index 1-1 = 0.  count[1] -> 0
              output: [_, 1, _, _, _, _, _]
              
   Wait — index 0? Let me redo with correct output indexing:
              output[0] = 1
              output: [1, _, _, _, _, _, _]
   
   i=5, v=3:  count[3]=5  ->  output[4] = 3.  count[3] -> 4
              output: [1, _, _, _, 3, _, _]
   
   i=4, v=3:  count[3]=4  ->  output[3] = 3.  count[3] -> 3
              output: [1, _, _, 3, 3, _, _]
   
   i=3, v=8:  count[8]=7  ->  output[6] = 8.  count[8] -> 6
              output: [1, _, _, 3, 3, _, 8]
   
   i=2, v=2:  count[2]=3  ->  output[2] = 2.  count[2] -> 2
              output: [1, _, 2, 3, 3, _, 8]
   
   i=1, v=2:  count[2]=2  ->  output[1] = 2.  count[2] -> 1
              output: [1, 2, 2, 3, 3, _, 8]
   
   i=0, v=4:  count[4]=6  ->  output[5] = 4.  count[4] -> 5
              output: [1, 2, 2, 3, 3, 4, 8]

FINAL:  [1, 2, 2, 3, 3, 4, 8]   ✓
```

**Why iterate the input backward?** This is the stability mechanism, and it's the part that gets asked about.

Each `count[v]` tells us the **last** available slot for value `v`. So we must fill slots from the back. If we walk the input backward, the *last* occurrence of `v` in the input gets the *last* slot, the second-to-last gets the second-to-last slot, and so on — **original relative order is preserved.**

```
   Input has two 2s: 2ᵃ at index 1, 2ᵇ at index 2.
   Slots available for value 2: indices 1 and 2.
   
   BACKWARD iteration: we meet 2ᵇ first -> gets index 2. Then 2ᵃ -> gets index 1.
   Output: [.., 2ᵃ, 2ᵇ, ..]   ORDER PRESERVED  ✅
   
   FORWARD iteration: we meet 2ᵃ first -> gets index 2. Then 2ᵇ -> gets index 1.
   Output: [.., 2ᵇ, 2ᵃ, ..]   ORDER REVERSED   ❌
```

**This matters enormously** because radix sort *requires* a stable subsort. Break counting sort's stability and radix sort breaks completely (§6.10).

### Java Implementation

```java
/**
 * Counting sort for non-negative ints. Stable. O(n + k) where k = max value + 1.
 * Only appropriate when k is O(n) — otherwise the count array dominates.
 */
public static void countingSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    int min = arr[0], max = arr[0];
    for (int v : arr) {                            // find the range in one pass
        if (v < min) min = v;
        if (v > max) max = v;
    }

    int range = max - min + 1;                     // offset by min: handles NEGATIVES
    if (range > 10L * arr.length + 1000) {
        // Range is huge relative to n; counting sort would waste memory.
        Arrays.sort(arr);
        return;
    }

    int[] count = new int[range];
    for (int v : arr) {
        count[v - min]++;                          // STEP 1: tally
    }
    for (int i = 1; i < range; i++) {
        count[i] += count[i - 1];                  // STEP 2: prefix sums
    }

    int[] output = new int[arr.length];
    for (int i = arr.length - 1; i >= 0; i--) {    // STEP 3: BACKWARD for stability
        int v = arr[i];
        output[--count[v - min]] = v;
    }

    System.arraycopy(output, 0, arr, 0, arr.length);
}
```

### Line-by-Line

**`int range = max - min + 1;` and `count[v - min]++`**
Offsetting by `min` is what lets counting sort handle **negative numbers**. Without it, `count[-5]` throws. With it, `-5` maps to index `-5 - min`. Most textbook implementations omit this and only work on non-negative input — including this generalisation is a nice touch.

Note the potential overflow: if `max = Integer.MAX_VALUE` and `min = Integer.MIN_VALUE`, then `max - min` overflows. A truly production-grade version would compute the range as a `long`.

**`if (range > 10L * arr.length + 1000)`**
The guard that makes this **safe to actually use**. Counting sort's fatal flaw: sorting `[1, 1000000000]` (n = 2) would allocate a billion-element array — 4 GB — to sort two numbers. **The complexity is O(n + k), and when k >> n the k dominates completely.** This check falls back to a comparison sort when the range is unreasonable. Volunteering this guard shows engineering judgment, not just algorithm knowledge.

**`for (int i = 1; i < range; i++) count[i] += count[i-1];`**
The prefix-sum transformation (this is Module 27 arriving again). It converts "how many equal `v`" into "how many `<= v`", which is exactly the *position* information we need. Note it starts at `i = 1` — `count[0]` needs no predecessor.

**`output[--count[v - min]] = v;`**
Dense but precise. Read it right to left:
1. `count[v - min]` = the number of elements `<= v` = one past the last slot for `v`.
2. `--` pre-decrements, giving the actual last available index **and** reserving it (so the next occurrence of `v` gets the slot before).
3. Write `v` there.

Pre-decrement (`--count[...]`) not post-decrement is essential. With `count[...]--` you'd write one slot too high and go out of bounds on the largest value.

**`for (int i = arr.length - 1; i >= 0; i--)`** — backward, for stability. Discussed above. **This is the line interviewers ask about.**

**`System.arraycopy(output, 0, arr, 0, arr.length);`** — counting sort is **not in-place**; it needs the `output` array. Copying back gives the caller an in-place-looking API. Total extra space: O(n + k).

### Complexity
- **Time: O(n + k)** — three O(n) passes plus one O(k) pass. **Linear when k = O(n).**
- **Space: O(n + k).**
- **Stable: yes** (with backward iteration).

### Interview Perspective

**The question that unlocks it:** *"Sort n integers where all values are between 0 and 100."* Or *"...where values are ages"*, *"...are ASCII characters"*, *"...are exam scores"*, *"...are years"*. Any bounded-range hint means **counting sort — O(n), beating the O(n log n) bound.**

**Always state the trade-off unprompted:** *"Counting sort gives O(n + k). It's a clear win when k is comparable to n — bounded ranges like ages or scores. But if the values are arbitrary 32-bit integers, k is 4 billion and the count array is unusable; I'd fall back to a comparison sort or use radix sort, which decomposes large values into small digit-sized pieces."*

**The most common real use** is as a subroutine: counting sort by a single digit is the engine inside radix sort, and counting sort by character is the engine inside bucket-based string sorting.

---

## 6.10 Radix Sort

### Intuition

**Counting sort is great when values are small. Radix sort makes values small by looking at one digit at a time.**

A 32-bit integer has a range of 4 billion (unusable for counting sort). But each *decimal digit* has a range of 10. Each *byte* has a range of 256. So: **sort by the last digit, then the next, then the next.** After processing all digits, the array is fully sorted.

**And the magic requirement:** each digit-pass must be **stable**. That's the entire correctness argument. When we sort by the tens digit, elements with equal tens digits must retain the order established by the previous (ones-digit) pass. Stability is what carries earlier work forward.

```
   Think of it as: "sort by the least significant thing first,
                    and let stability preserve it while you sort by more significant things."
```

This is exactly how humans sorted punched cards mechanically in the 1890s — Hollerith's machines did LSD radix sort. It predates computers.

### Visual Explanation on `[170, 45, 75, 90, 802, 24, 2, 66]`

Max is 802, so 3 digits → 3 passes.

```
INITIAL:  170  45  75  90  802  24  2  66

=== PASS 1: sort by the ONES digit (place value 1) ===

   Extract digits:  170->0  45->5  75->5  90->0  802->2  24->4  2->2  66->6
   
   Buckets:
       0:  170, 90
       1:  (empty)
       2:  802, 2
       3:  (empty)
       4:  24
       5:  45, 75
       6:  66
       7,8,9: (empty)
   
   Read buckets in order:
   AFTER PASS 1:  170  90  802  2  24  45  75  66
                  ^^^  ^^  ordered by last digit: 0,0,2,2,4,5,5,6
   
   Note 170 before 90 (both end in 0) — that was their original relative order.
   Note 802 before 2 (both end in 2) — also original order. STABILITY AT WORK.

=== PASS 2: sort by the TENS digit (place value 10) ===

   Extract tens digits:  170->7  90->9  802->0  2->0  24->2  45->4  75->7  66->6
   
   Buckets:
       0:  802, 2
       1:  (empty)
       2:  24
       3:  (empty)
       4:  45
       5:  (empty)
       6:  66
       7:  170, 75
       8:  (empty)
       9:  90
   
   AFTER PASS 2:  802  2  24  45  66  170  75  90
                  ^^^^^^  tens digits: 0,0,2,4,6,7,7,9
   
   CRUCIAL: 170 and 75 both have tens digit 7. Pass 1 left 170 before 75
   (ones digits 0 and 5), and stability preserved that. So within tens-digit 7,
   they are correctly ordered by ones digit already.

=== PASS 3: sort by the HUNDREDS digit (place value 100) ===

   Extract hundreds:  802->8  2->0  24->0  45->0  66->0  170->1  75->0  90->0
   
   Buckets:
       0:  2, 24, 45, 66, 75, 90     <- all preserved in their pass-2 order!
       1:  170
       2..7: (empty)
       8:  802
   
   AFTER PASS 3:  2  24  45  66  75  90  170  802

FINAL:  [2, 24, 45, 66, 75, 90, 170, 802]   ✓  FULLY SORTED
```

**Now watch what happens WITHOUT stability.** Suppose pass 2's subsort scrambled equal keys:

```
   After pass 1:  170  90  802  2  24  45  75  66
   
   Pass 2 (UNSTABLE) puts bucket-7 as [75, 170] instead of [170, 75]:
   After pass 2:  802  2  24  45  66  75  170  90
   
   Pass 3: all of {2,24,45,66,75,90} have hundreds digit 0, and 
           an unstable sort might emit them in any order:
   Result: 45  2  75  24  90  66  170  802     ← COMPLETELY WRONG
```

**Radix sort's correctness rests entirely on the stability of its subsort.** This is *the* reason counting sort iterates backward (§6.9), and it's why "why must the subsort be stable?" is a standard interview question. Answer: *"because each pass must preserve the ordering established by all previous, less-significant passes. Without stability, earlier work is destroyed."*

### Java Implementation

```java
/**
 * LSD radix sort for non-negative ints, base 256 (one byte per pass).
 * O(d(n + k)) where d = 4 passes, k = 256.  Effectively O(n).
 */
public static void radixSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    final int BITS = 8;                    // 8 bits per pass
    final int BUCKETS = 1 << BITS;         // 256
    final int MASK = BUCKETS - 1;          // 0xFF
    final int PASSES = 4;                  // 32 bits / 8 = 4 passes

    int n = arr.length;
    int[] buffer = new int[n];             // ONE buffer, reused
    int[] count = new int[BUCKETS];

    int[] src = arr, dst = buffer;

    for (int pass = 0; pass < PASSES; pass++) {
        int shift = pass * BITS;
        Arrays.fill(count, 0);             // reset the tally each pass

        // STEP 1: count occurrences of each byte value
        for (int i = 0; i < n; i++) {
            int bucket = (src[i] >>> shift) & MASK;
            count[bucket]++;
        }

        // Skip this pass entirely if all values share the same byte here
        if (count[(src[0] >>> shift) & MASK] == n) continue;

        // STEP 2: prefix sums -> starting index of each bucket
        int total = 0;
        for (int b = 0; b < BUCKETS; b++) {
            int c = count[b];
            count[b] = total;
            total += c;
        }

        // STEP 3: stable distribution, FORWARD (works with start-index counts)
        for (int i = 0; i < n; i++) {
            int bucket = (src[i] >>> shift) & MASK;
            dst[count[bucket]++] = src[i];
        }

        // STEP 4: swap the roles of src and dst — no copying needed
        int[] tmp = src; src = dst; dst = tmp;
    }

    // After 4 passes (even number), src == arr. If it weren't, copy back.
    if (src != arr) {
        System.arraycopy(src, 0, arr, 0, n);
    }
}
```

### Line-by-Line

**`final int BITS = 8; final int BUCKETS = 1 << BITS;`**
Base 256, not base 10. Why? Because `(x >>> shift) & 0xFF` extracts a byte with **two single-cycle bit operations**, whereas base 10 needs `(x / placeValue) % 10` — an integer division, which is 20–40× slower on most CPUs. And 4 passes (32/8) instead of 10 passes (for 10-digit ints). **Base 256 radix sort is roughly 5–10× faster than base-10 radix sort.** This choice is why radix sort is genuinely competitive with quicksort on large integer arrays.

Trade-off: a 256-entry count array instead of 10. Utterly negligible.

**`int bucket = (src[i] >>> shift) & MASK;`**
`>>>` is the **unsigned** right shift. Using `>>` (signed) would sign-extend negative numbers, corrupting the digit extraction. Then `& 0xFF` isolates the low 8 bits of the shifted value.

```
   value = 0x12345678, pass = 1, shift = 8
   value >>> 8  = 0x00123456
   & 0xFF       = 0x56          <- the second byte. Correct.
```

**Important caveat this implementation carries:** it treats the top byte as unsigned, so **negative numbers sort after positives** (because their sign bit makes the top byte ≥ 0x80). The standard fix is to flip the sign bit during the final pass: `bucket = ((src[i] >>> 24) ^ 0x80) & 0xFF`. Mention this limitation if asked — knowing where your implementation's boundaries are is more impressive than pretending it handles everything.

**`if (count[(src[0] >>> shift) & MASK] == n) continue;`**
If one bucket holds all `n` elements, this digit is identical across the whole array and the pass would be a pure copy. Skip it. For arrays of small values (the common case), the top two or three passes are skipped entirely — **turning 4 passes into 1 or 2.** A big practical win, and a nice thing to point out.

**STEP 2 computes STARTING indices, not "one past the end."**
```java
int c = count[b]; count[b] = total; total += c;
```
This is an **exclusive** prefix sum: after it, `count[b]` = the index where bucket `b` begins. That changes the distribution loop:
```
   Counting sort (§6.9): count[] = one-past-end  ->  iterate input BACKWARD, use --count[]
   Radix here:           count[] = start index   ->  iterate input FORWARD,  use count[]++
```
**Both are stable.** They're two encodings of the same idea. The forward version is more cache-friendly (sequential reads of `src`), which is why high-performance radix sorts use it. Understanding that *both* forms achieve stability — and why — means you actually understand the mechanism rather than having memorised one recipe.

**`int[] tmp = src; src = dst; dst = tmp;` — pointer swapping, not copying.**
After each pass the sorted-by-this-digit data lives in `dst`. Instead of copying it back to `arr` (an O(n) copy per pass), we just **swap which array we call "source."** Next pass reads from what was `dst`. This is **double buffering** and it eliminates 4 full array copies. With an even number of passes, `src` ends up back at `arr` — hence the final `if (src != arr)` guard for safety.

### Complexity

- **Time: O(d · (n + k))** where `d` = number of passes, `k` = bucket count.
  - Here `d = 4`, `k = 256`, both **constants** → **O(n)**.
  - More precisely: `4 × (n + 256)` ≈ `4n`. **Four linear passes.** Compare quicksort's `n log n` ≈ `n × 30` for n = 10⁹.
- **Space: O(n + k)** = one n-element buffer plus 256 counters.
- **Stable: yes** (essential, and by construction).
- **Not in-place.**

**Is radix sort actually faster than quicksort in practice?** For large arrays of primitive integers, **yes, often by 2–3×.** For small arrays, no (the constant overhead of 4 passes and buffer allocation dominates). For objects with expensive comparators, radix isn't applicable at all. This is why the JDK doesn't use it — a general-purpose library sort must handle `Comparator`, but a specialised numeric sort absolutely should consider radix.

### Interview Perspective

**When to bring it up:** *"sort 10 million 32-bit integers"*, *"sort IP addresses"*, *"sort fixed-length strings"*, *"sort dates"*, *"can you beat O(n log n)?"*

**How to present it:** *"Since these are fixed-width integers, I can use radix sort — LSD, base 256, four passes with a stable counting sort per pass. That's O(4n) — linear — and it beats the comparison lower bound because I'm not comparing, I'm bucketing by digit. The requirements are that keys are fixed-width and decomposable into small digits, and that each pass is stable, since stability is what preserves the ordering from less-significant digits."*

That paragraph contains: the algorithm, the base choice, the complexity, why the lower bound doesn't apply, and the correctness condition. It's about as complete as an interview answer gets.

**MSD vs LSD:** we did LSD (least significant digit first), which processes all elements every pass and needs no recursion. **MSD** (most significant first) partitions into buckets and recurses — it's how you radix-sort **variable-length strings**, and it can terminate early once buckets have one element. Knowing both exist, and that MSD is the string variant, is worth a sentence.

---

## 6.11 The Java Collections angle (asked constantly)

```
   Arrays.sort(int[] a)            ->  Dual-Pivot Quicksort
                                       In-place, O(n log n) expected, O(n²) worst (mitigated),
                                       NOT stable (irrelevant for primitives).
                                       Falls back to insertion sort below 47 elements.
                                       Falls back to merge sort if it detects
                                       structure that would hurt quicksort.

   Arrays.sort(Object[] a)         ->  TimSort
   Collections.sort(List)          ->  (delegates to Arrays.sort)
   List.sort(Comparator)
                                       STABLE, guaranteed O(n log n), O(n) space.
                                       Adaptive: finds existing "runs" and merges them.
                                       O(n) on already-sorted input.

   Arrays.parallelSort(...)        ->  Parallel merge sort via ForkJoinPool.
                                       Worth it above ~8192 elements.

   Arrays.sort(a, fromIndex, toIndex)  ->  sorts a subrange.
```

**Why the split?** *"Primitives have no identity beyond their value, so stability is meaningless — the JDK can use the faster in-place quicksort. Objects are distinguishable, so `Comparator`-based sorting must be stable to support multi-key sorting, and object comparisons are expensive enough that TimSort's run-detection pays for itself."* That's the complete answer.

**TimSort in one paragraph** (worth knowing — it's the most-used sort on Earth, in both Java and Python):
1. Scan for **natural runs** — already-ascending or already-descending sequences. Reverse the descending ones.
2. Extend short runs to a minimum length (32–64) using **binary insertion sort**.
3. Push runs onto a stack and **merge** them, maintaining invariants that keep the merge tree balanced.
4. Use **galloping mode** during merges: if one run is consistently winning, binary-search ahead instead of comparing one at a time.

Result: **O(n) on sorted or reverse-sorted input, O(n log n) worst case, stable.** It's merge sort that exploits real-world data's tendency to be partially ordered.

**One gotcha worth knowing:** `Arrays.sort(Object[])` throws `IllegalArgumentException: Comparison method violates its general contract!` if your `Comparator` is inconsistent (e.g. not transitive, or `compare(a,b)` and `compare(b,a)` disagree). TimSort *detects* broken comparators. A common cause is `return a.value - b.value` **overflowing** for large values — use `Integer.compare(a.value, b.value)` instead. **This is a real production bug and a great thing to mention.**

## 6.12 The Ω(n log n) lower bound — why comparison sorts can't do better

This proof gets asked at strong companies, and it's short.

Think of a sorting algorithm as a **decision tree**. Each internal node is a comparison ("is a[i] < a[j]?") with two branches. Each leaf is one possible output ordering.

```
                    a<b?
                   /     \
                yes       no
                /           \
            b<c?             a<c?
           /    \           /    \
      [a,b,c]  a<c?    [b,a,c]  b<c?
              /    \            /    \
        [a,c,b] [c,a,b]   [b,c,a] [c,b,a]
```

For `n` distinct elements there are **n!** possible orderings, so the tree needs **at least n! leaves**.

A binary tree of height `h` has at most `2^h` leaves. Therefore:
```
   2^h  >=  n!
   h    >=  log₂(n!)
```
By Stirling's approximation, `log₂(n!) ≈ n log₂ n − n log₂ e ≈ n log₂ n`.

```
   h  >=  Ω(n log n)
```

The height of the tree is the **worst-case number of comparisons**. So:

> **No comparison-based sort can do better than Ω(n log n) comparisons in the worst case.** Merge sort and heap sort achieve this bound, so they are **optimal** among comparison sorts.

**And why counting/radix escape it:** they never perform a comparison. Using a value as an **array index** is not a binary decision — it's a `k`-way branch in constant time, which sits outside this model entirely. That's the loophole, and it costs you the requirement that values be small integers.

## 6.13 Practice Problems

### Easy — Sort Colors (Dutch National Flag)
Given `int[] nums` containing only 0, 1, and 2, sort it **in place** in **one pass** with **O(1) space**. Do not use a library sort or counting sort's two passes.
```
[2,0,2,1,1,0] -> [0,0,1,1,2,2]
```

### Medium — Kth Largest Element in an Array
Find the kth largest element in an unsorted array. Aim for **average O(n)**.
```
[3,2,1,5,6,4], k = 2 -> 5
[3,2,3,1,2,4,5,5,6], k = 4 -> 4
```

### Hard — Count Inversions
Count the pairs `(i, j)` with `i < j` and `arr[i] > arr[j]`. This measures "how unsorted" an array is. Must be **O(n log n)**.
```
[2, 4, 1, 3, 5] -> 3     pairs: (2,1), (4,1), (4,3)
[5, 4, 3, 2, 1] -> 10    (fully reversed: n(n-1)/2)
```

## 6.14 Solution Walkthrough

### Easy — Sort Colors (Dutch National Flag)

**Why not counting sort?** It works (count 0s, 1s, 2s; overwrite) but takes **two passes**. The problem asks for one. And the one-pass solution teaches the **three-way partitioning** technique that fixes quicksort's duplicate problem (§6.7).

**The idea: three pointers carving the array into four regions.**

```
   +----------+----------+------------------+----------+
   |   = 0    |   = 1    |     UNKNOWN      |   = 2    |
   +----------+----------+------------------+----------+
   0        low-1  low        mid        high      n-1
                                       high+1

   INVARIANT (state this out loud — it IS the solution):
     nums[0 .. low-1]    are all 0
     nums[low .. mid-1]  are all 1
     nums[mid .. high]   are UNEXAMINED
     nums[high+1 .. n-1] are all 2

   Loop while mid <= high, shrinking the unknown region to nothing.
```

```java
public void sortColors(int[] nums) {
    if (nums == null || nums.length < 2) return;
    int low = 0, mid = 0, high = nums.length - 1;

    while (mid <= high) {
        if (nums[mid] == 0) {
            swap(nums, low, mid);
            low++;
            mid++;                 // safe to advance: we swapped in a known 1 (or self)
        } else if (nums[mid] == 1) {
            mid++;                 // already in the right region
        } else {                   // nums[mid] == 2
            swap(nums, mid, high);
            high--;
            // DO NOT advance mid — the value swapped in is UNEXAMINED
        }
    }
}
```

**Dry run on `[2, 0, 2, 1, 1, 0]`.**

```
Start: [2, 0, 2, 1, 1, 0]   low=0, mid=0, high=5

--- mid=0, nums[0]=2 ---
   Swap mid(0) and high(5):  [0, 0, 2, 1, 1, 2]
   high -> 4.  mid stays 0 (the 0 we just received is unexamined).
   [0, 0, 2, 1, 1 | 2]

--- mid=0, nums[0]=0 ---
   Swap low(0) and mid(0) — self swap, no-op.
   low -> 1, mid -> 1.
   [0 | 0, 2, 1, 1 | 2]

--- mid=1, nums[1]=0 ---
   Swap low(1) and mid(1) — self swap.
   low -> 2, mid -> 2.
   [0, 0 | 2, 1, 1 | 2]

--- mid=2, nums[2]=2 ---
   Swap mid(2) and high(4):  [0, 0, 1, 1, 2, 2]
   high -> 3.  mid stays 2.
   [0, 0 | 1, 1 | 2, 2]

--- mid=2, nums[2]=1 ---
   Just advance. mid -> 3.
   [0, 0 | 1 | 1 | 2, 2]

--- mid=3, nums[3]=1 ---
   Advance. mid -> 4.
   
--- mid=4 > high=3  ->  LOOP EXITS ---

FINAL: [0, 0, 1, 1, 2, 2]   ✓  ONE pass.
```

**The detail that is the entire problem: why does `mid` advance on 0 but NOT on 2?**

This is the question interviewers ask, and it's a beautiful piece of reasoning.

- **When `nums[mid] == 0`:** we swap with `nums[low]`. But what was at `low`? By the invariant, `low` is the start of the "= 1" region, so `nums[low]` is either a **1** or `low == mid` (self-swap). Either way, the value arriving at `mid` is **already examined and known**. Safe to advance.

- **When `nums[mid] == 2`:** we swap with `nums[high]`. By the invariant, `nums[high]` is in the **UNKNOWN** region. The value arriving at `mid` could be 0, 1, or 2 — **we have no idea.** We must examine it on the next iteration, so `mid` must **not** advance.

```
   Case 0:  swap with low  ->  receive a known 1  ->  advance mid  ✅
   Case 2:  swap with high ->  receive an UNKNOWN ->  do NOT advance  ✅
```

Advance `mid` in the 2-case and you skip an element, which can leave a 0 stranded in the middle. **Trace `[2, 2, 0]` by hand with the bug** and you'll watch the 0 get skipped over and stranded.

**Also: `while (mid <= high)`, not `<`.** When `mid == high` there is still **one** unexamined element. Using `<` leaves it unsorted. Same boundary logic as binary search Template A.

**Complexity:** **O(n) time** — each iteration either advances `mid` or decrements `high`, so the unknown region shrinks by one every step; at most n iterations. **O(1) space.** One pass, three pointers.

**Why this matters beyond the problem:** this *is* the three-way partition that makes quicksort O(n) on all-duplicate input. Replace "0/1/2" with "< pivot / == pivot / > pivot" and you have production-grade quicksort partitioning. **Say that connection out loud** — it shows you see the pattern rather than the puzzle.

### Medium — Kth Largest Element

**Four approaches. Present them in ascending order of quality — this progression *is* the interview.**

**1. Sort and index.** `Arrays.sort(nums); return nums[n - k];` → **O(n log n)** time, O(1) space. Two lines. **Say this first** — it's correct, and it establishes a baseline.

**2. Min-heap of size k.** Stream through the array, keeping only the k largest seen so far:
```java
PriorityQueue<Integer> heap = new PriorityQueue<>();   // min-heap by default
for (int v : nums) {
    heap.offer(v);
    if (heap.size() > k) heap.poll();                  // evict the smallest
}
return heap.peek();                                    // the kth largest
```
→ **O(n log k)** time, **O(k)** space. Better than sorting when `k << n`. **And it's the only viable approach if the data is a stream that doesn't fit in memory** — a follow-up you should volunteer.

**3. Quickselect.** → **O(n) expected**, O(1) space. The optimal answer.

**4. Median of medians.** → O(n) **worst case**, but with constants so large it's slower in practice. Mention it exists; don't implement it.

**Quickselect, the answer:**

```java
private static final Random RNG = new Random();

public int findKthLargest(int[] nums, int k) {
    // kth LARGEST == the element at index (n - k) in ascending order
    int targetIdx = nums.length - k;
    int lo = 0, hi = nums.length - 1;

    while (lo < hi) {
        int pivotIdx = lo + RNG.nextInt(hi - lo + 1);
        swap(nums, pivotIdx, hi);
        int p = partition(nums, lo, hi);         // same Lomuto partition as §6.7

        if (p == targetIdx) {
            return nums[p];                      // found it
        } else if (p < targetIdx) {
            lo = p + 1;                          // target is to the RIGHT
        } else {
            hi = p - 1;                          // target is to the LEFT
        }
    }
    return nums[lo];
}
```

**Dry run: `nums = [3,2,1,5,6,4]`, k = 2.**

```
n = 6, so targetIdx = 6 - 2 = 4.
(In ascending order [1,2,3,4,5,6], index 4 holds 5. And 5 IS the 2nd largest. ✓)

--- Iteration 1 ---
lo=0, hi=5. Suppose the random pivot lands on 4 (value 6). Swap to hi:
   [3, 2, 1, 5, 4, 6]      pivot = 6

   partition: every element <= 6, so i advances all the way to 4,
   then pivot swaps to index 5.
   [3, 2, 1, 5, 4, 6]   p = 5

   p=5 > targetIdx=4  ->  the answer is LEFT of index 5.  hi = 4.
   Search space: [0, 4] = [3, 2, 1, 5, 4]
   
   NOTE: we did NOT recurse into the right side at all. Half the work discarded.

--- Iteration 2 ---
lo=0, hi=4. Suppose the pivot is 4 (value 4, already at hi). pivot = 4.
   
   partition [3,2,1,5,4] with pivot 4:
     j=0: 3<=4 YES, i->0, swap(0,0)      [3,2,1,5,4]
     j=1: 2<=4 YES, i->1, swap(1,1)      [3,2,1,5,4]
     j=2: 1<=4 YES, i->2, swap(2,2)      [3,2,1,5,4]
     j=3: 5<=4 NO                        [3,2,1,5,4]
     final: swap(i+1=3, hi=4)            [3,2,1,4,5]
   p = 3

   p=3 < targetIdx=4  ->  answer is RIGHT.  lo = 4.
   Search space: [4, 4] — a single element.

--- lo == hi == 4  ->  loop exits.  return nums[4] = 5.  ✓
```

**Why quickselect is O(n) and not O(n log n)** — this derivation is the interview answer:

```
   QUICKSORT:    recurses into BOTH sides
                 T(n) = 2T(n/2) + O(n)  ->  O(n log n)
                 
   QUICKSELECT:  recurses into ONE side (the other cannot contain the answer)
                 T(n) = T(n/2) + O(n)
                      = n + n/2 + n/4 + n/8 + ...
                      = n × (1 + 1/2 + 1/4 + ...)
                      = n × 2
                      = O(n)
```

**A geometric series that converges to 2.** Discarding half the search space each time makes the *total* work linear, not linearithmic. That's the same convergence trick as amortized ArrayList growth (§1.4) — the pattern recurs constantly.

**`while (lo < hi)` instead of recursion** — quickselect only ever recurses into one side, so that call is in tail position and converts directly to a loop (Module 4, §4.5). Result: **O(1) space** instead of O(log n). Do this; it's strictly better and shows you recognised the tail call.

**`targetIdx = nums.length - k`** — the index conversion, and a classic off-by-one trap. Verify with a tiny case: `n=6, k=1` (largest) → `targetIdx = 5` = the last index in ascending order. ✓ `k=6` (smallest) → `targetIdx = 0`. ✓

**Complexity:** **O(n) expected, O(n²) worst** (mitigated by the random pivot, exactly as in quicksort). **O(1) space.**

**What to say when asked "which would you use in production?"** *"Quickselect for a one-shot query on an in-memory array — O(n) expected and in-place. But a size-k min-heap if the data arrives as a stream, or if I need the answer repeatedly as data changes, since the heap maintains the invariant incrementally in O(log k) per element."* Recognising that the *best* algorithm depends on the access pattern is exactly the judgment interviews are testing.

### Hard — Count Inversions

**Brute force:** two nested loops, count every out-of-order pair → O(n²). For n = 10⁵ that's 10¹⁰. Too slow.

**The insight: merge sort already finds every inversion — we just have to count them.**

Think about the merge step. We have two sorted halves, `L` and `R`. Every element of `L` came *before* every element of `R` in the original array. So if we ever take an element from `R` **before** exhausting `L`, that element is smaller than everything remaining in `L` — and each of those is an inversion.

```
   L = [3, 5, 9]        R = [1, 4, 8]
        i                    j
   
   Compare 3 vs 1.  R wins  ->  take 1.
   
   How many inversions did we just discover?
   1 is smaller than 3, 5, AND 9 — all remaining elements of L.
   And all of them come EARLIER in the original array.
   
   So we found (mid - i + 1) = 3 inversions in ONE step:
       (3,1), (5,1), (9,1)
   
   +--------------------------+
   |  L: [3, 5, 9]            |
   |       ^^^^^^^ all 3 are > 1 and all come before it  -> 3 inversions
   |  R: [1, ...]             |
   +--------------------------+
```

**One comparison reveals up to `n/2` inversions at once.** That's how we get from O(n²) to O(n log n).

```java
public long countInversions(int[] arr) {
    if (arr == null || arr.length < 2) return 0;
    int[] buffer = new int[arr.length];
    return sortAndCount(arr, buffer, 0, arr.length - 1);
}

private long sortAndCount(int[] arr, int[] buf, int lo, int hi) {
    if (lo >= hi) return 0;

    int mid = lo + (hi - lo) / 2;
    long count = sortAndCount(arr, buf, lo, mid)          // inversions fully inside left
               + sortAndCount(arr, buf, mid + 1, hi);     // inversions fully inside right
    count += mergeAndCount(arr, buf, lo, mid, hi);        // inversions ACROSS the halves
    return count;
}

private long mergeAndCount(int[] arr, int[] buf, int lo, int mid, int hi) {
    System.arraycopy(arr, lo, buf, lo, hi - lo + 1);

    long inversions = 0;
    int i = lo, j = mid + 1, k = lo;

    while (i <= mid && j <= hi) {
        if (buf[i] <= buf[j]) {
            arr[k++] = buf[i++];             // no inversion: left element is smaller
        } else {
            arr[k++] = buf[j++];
            inversions += (mid - i + 1);     // <-- THE ENTIRE ALGORITHM IS THIS LINE
        }
    }
    while (i <= mid) arr[k++] = buf[i++];
    while (j <= hi)  arr[k++] = buf[j++];
    return inversions;
}
```

**The decomposition to state out loud:** every inversion `(i, j)` falls into exactly one of three buckets —
1. both indices in the left half → counted by the left recursive call,
2. both in the right half → counted by the right recursive call,
3. `i` in the left, `j` in the right → counted during the merge.

Three mutually exclusive, collectively exhaustive cases. **That's the correctness proof, and it's the same divide-and-conquer decomposition you'd use for "count pairs with property P".**

**Dry run on `[2, 4, 1, 3, 5]`.** Expected answer: 3, from pairs (2,1), (4,1), (4,3).

```
Split: [2, 4]  and  [1, 3, 5]

=== LEFT: [2, 4] ===
   Split into [2] and [4].
   Merge: 2 <= 4, take 2 (no inversion). Then drain 4.
   Result: [2, 4].  Inversions: 0

=== RIGHT: [1, 3, 5] ===
   Split into [1] and [3, 5].
   [3,5]: split [3],[5]. Merge: 3<=5, no inversion. Result [3,5]. Inversions: 0
   Merge [1] with [3,5]: 1 <= 3, take 1 (no inversion). Drain 3, 5.
   Result: [1, 3, 5].  Inversions: 0

=== TOP-LEVEL MERGE: L = [2, 4], R = [1, 3, 5] ===
   buf = [2, 4, 1, 3, 5]
   i=0 (points at 2), mid=1, j=2 (points at 1), k=0

   Step 1: buf[0]=2 vs buf[2]=1.  2 > 1  ->  take from RIGHT.
           arr[0] = 1.  j -> 3
           inversions += (mid - i + 1) = (1 - 0 + 1) = 2
           
           WHY 2?  Elements remaining in L are buf[0..1] = {2, 4}.
                   Both are > 1, and both come before 1 in the original array.
                   Inversions found: (2,1) and (4,1).   ✓ exactly right.
           
           running total: 2

   Step 2: buf[0]=2 vs buf[3]=3.  2 <= 3  ->  take from LEFT.
           arr[1] = 2.  i -> 1.  No inversion (2 comes before 3 and is smaller).
           
   Step 3: buf[1]=4 vs buf[3]=3.  4 > 3  ->  take from RIGHT.
           arr[2] = 3.  j -> 4
           inversions += (mid - i + 1) = (1 - 1 + 1) = 1
           
           WHY 1?  Only buf[1] = {4} remains in L. 4 > 3 and comes earlier.
                   Inversion found: (4,3).   ✓
           
           running total: 3

   Step 4: buf[1]=4 vs buf[4]=5.  4 <= 5  ->  take from LEFT.
           arr[3] = 4.  i -> 2.  i > mid, left exhausted.

   Drain right: arr[4] = 5.

   Merged array: [1, 2, 3, 4, 5]
   Inversions from this merge: 3

TOTAL: 0 (left) + 0 (right) + 3 (merge) = 3   ✓
```

**Three critical details:**

**1. `inversions += (mid - i + 1)` — why that formula?**
`i` points at the first *unconsumed* element of the left half; `mid` is its last index. So the count of remaining left elements is `mid - i + 1`. Every one of them is `>= buf[i] > buf[j]` (the left half is sorted!) and every one sits at an earlier original index. **All of them form an inversion with `buf[j]`.** Off-by-one check: if `i == mid`, one element remains → `mid - mid + 1 = 1`. ✓

**2. `if (buf[i] <= buf[j])` — the `<=` is mandatory here, and not just for stability.**
An inversion requires `arr[i] > arr[j]` **strictly**. Equal elements are *not* inversions. With `<`, equal values would take the right branch and be miscounted as inversions. **This single character changes the answer.** The stability property and the correctness property happen to coincide — a nice observation to make.

**3. `long`, not `int`, for the count.**
Maximum inversions is `n(n-1)/2`. For n = 10⁵ that's ~5×10⁹, which **overflows `int`** (max 2.1×10⁹). Silent wraparound to a negative number. Declaring `inversions` and the return type as `long` is not paranoia — it's required for the stated constraints. **Volunteering this is exactly the overflow-awareness that distinguishes strong candidates** (see also Module 4, §4.7).

**Complexity:** **O(n log n) time** — it's merge sort with one extra addition per step, so the complexity is unchanged. **O(n) space** for the buffer plus O(log n) stack.

**The transferable pattern.** "Count pairs `(i, j)` with `i < j` and some relationship between `arr[i]` and `arr[j]`" is almost always solvable by **merge sort with counting**, or by a **Fenwick tree / BIT** (Module 11). Problems this exact technique solves:
- Count Inversions
- Reverse Pairs (`arr[i] > 2·arr[j]`)
- Count of Smaller Numbers After Self
- Count of Range Sum
- Global and Local Inversions

**The generalisable idea, stated once:** *when a problem asks about pairs across a sequence, split the sequence and count pairs that (a) lie entirely left, (b) lie entirely right, (c) straddle the split. The straddling case is where the algorithm lives, and sortedness of the two halves is what makes counting it linear.* That sentence is the core of divide-and-conquer counting, and it will serve you across a dozen problems.

---
---
# MODULE 7 — Linked Lists

## 7.1 Intuition

An array is a row of adjacent mailboxes. **A linked list is a treasure hunt.**

Each clue tells you where the next clue is. The clues can be scattered anywhere in the house — under the sofa, in the fridge, in the garden. There is no formula that gets you to clue #7. You must follow clues 1 through 6 first.

```
   ARRAY:  everything adjacent, position computable
   
   +----+----+----+----+
   | 10 | 20 | 30 | 40 |     arr[2]?  base + 2*4.  ONE STEP.
   +----+----+----+----+
   1000 1004 1008 1012


   LINKED LIST: everything scattered, position must be WALKED
   
   head
    |
    v
   +----+------+        +----+------+        +----+------+
   | 10 | 0x88 |------->| 20 | 0x14 |------->| 30 | null |
   +----+------+        +----+------+        +----+------+
   at 0x40               at 0x88              at 0x14
   
   node #2?  start at head, follow 2 pointers.  TWO STEPS.
   node #1000? follow 1000 pointers.
```

**So the linked list is worse. Why does it exist?**

Because of what the treasure hunt makes *easy*. To insert a new clue between clue 1 and clue 2, you don't move anything. You just rewrite two slips of paper:

```
   BEFORE:  [10] --------------------> [20] --> [30]

   INSERT 15 between them:

   Step 1: new node points to 20
            [15] ---> [20]
   Step 2: 10 points to 15
            [10] ---> [15] ---> [20] ---> [30]
            
   TOTAL WORK: two pointer assignments. O(1). Nothing moved.
```

Compare with the array (Module 2, §2.4), which had to shift every subsequent element. **That is the entire trade:**

```
   ARRAY:        O(1) access,  O(n) insert/delete in the middle
   LINKED LIST:  O(n) access,  O(1) insert/delete GIVEN A POINTER to the position
```

Read that last clause carefully — **"given a pointer to the position."** It's the caveat that catches everyone. Deleting the 500th node is O(n), because *finding* it is O(n). Only the pointer rewiring is O(1). Interviewers probe this constantly.

## 7.2 Mental Model

**Model 1 — "A linked list IS its head pointer."**

There is no list object. There is no length field. A linked list is a single reference to a first node, and each node knows only its successor. Lose the head and the entire list is unreachable garbage.

```java
Node head = ...;   // THIS variable is the list. That's all there is.
```

**Model 2 — "Draw the boxes and arrows. Always. Every time."**

I am completely serious about this. Linked list problems are pointer-rewiring puzzles, and pointer-rewiring puzzles are impossible to hold in your head and trivial on paper. In an interview, draw four nodes and physically redraw the arrows for each line of code you write. Candidates who draw solve these problems; candidates who don't produce off-by-one pointer bugs and lose the thread.

**Model 3 — "Order of assignment is everything."**

```java
// WRONG — you just leaked the rest of the list
prev.next = newNode;        // prev's old successor is now unreachable
newNode.next = prev.next;   // ...and this now points newNode at ITSELF

// RIGHT — attach forward first, then attach backward
newNode.next = prev.next;   // newNode now knows the rest of the list
prev.next = newNode;        // NOW it's safe to overwrite prev.next
```

**The universal rule: before you overwrite a pointer, make sure something else still points at what it pointed to.** This is the same "copy away from the direction you're moving" principle as array shifting (§2.4), and it is the single most common linked-list bug.

**Model 4 — "Almost every linked list problem is solved by one of five techniques."**
```
   1. Dummy head node       -> eliminates all "what if it's the first node?" cases
   2. Two pointers, offset  -> nth from end, middle of list
   3. Two pointers, speed   -> cycle detection (Floyd's tortoise & hare)
   4. Three-pointer walk    -> in-place reversal (prev, curr, next)
   5. Recursion             -> natural, since a list IS a node plus a smaller list
```
Learn these five and you can solve virtually any linked list interview question. We'll build all five.

## 7.3 Internal Working — memory, and why linked lists are slower than the math suggests

### What a node actually costs in Java

```java
class Node {
    int val;
    Node next;
}
```

That looks like 4 bytes of data plus an 8-byte pointer. Here's the reality on a 64-bit HotSpot JVM with compressed oops:

```
   +--------------------------------------+
   |  Mark word            8 bytes        |  GC state, hash, lock bits
   |  Class pointer        4 bytes        |  (compressed)
   |  int val              4 bytes        |  <-- THE ACTUAL DATA
   |  Node next            4 bytes        |  (compressed reference)
   +--------------------------------------+
   |  TOTAL: 20 bytes -> padded to 24     |  (8-byte alignment)
   +--------------------------------------+

   4 bytes of payload in a 24-byte object.  ~17% efficiency.
   
   Compare:  int[] of n elements = 16 bytes header + 4n bytes payload.
             For n = 1000:  4016 bytes.
             LinkedList of 1000 ints: 24,000 bytes + boxing if Integer.
             SIX TIMES the memory. And that's before boxing.
```

### The real killer: cache locality

This is the part that textbooks skip and that separates people who have measured things from people who have only read about them.

```
   ARRAY in memory (one contiguous block):
   
   [10][20][30][40][50][60][70][80][90][A0][B0][C0][D0][E0][F0][100]
   |<---------------- one 64-byte cache line ------------------>|
   
   Reading arr[0] pulls SIXTEEN ints into cache for free.
   The CPU prefetcher then speculatively loads the NEXT line.
   Iterating an array is essentially free after the first miss.


   LINKED LIST in memory (nodes allocated at different times, scattered by GC):
   
   [node3]......[node1]...........[node5]...[node2]......[node4]
      ^            ^                 ^         ^            ^
   Reading node1 pulls in node1's cache line — which contains
   nothing else useful. Following .next JUMPS to a different line.
   
   EVERY step is potentially a cache miss (~100-300 CPU cycles).
   The prefetcher CANNOT help: it cannot predict where .next points
   until it has already loaded the current node.
```

**The practical consequence:** iterating a `LinkedList<Integer>` of a million elements can be **10 to 50 times slower** than iterating an `int[]` of the same size, despite both being O(n). Same complexity class, wildly different wall-clock time.

**This is why `LinkedList` is almost never the right choice in production Java.** Even for "many insertions in the middle," `ArrayList` usually wins, because `System.arraycopy` is a vectorised block move that the hardware loves, while `LinkedList` pays a cache miss per node *just to find the insertion point*.

**What to say in an interview:** *"Asymptotically, LinkedList gives O(1) insertion at a known position versus ArrayList's O(n). But in practice ArrayList almost always wins, because finding the position is O(n) anyway, and the O(n) shift is a cache-friendly block copy while the O(n) traversal is a chain of cache misses. I'd use ArrayDeque over LinkedList for queue/deque behaviour, and I'd only reach for a linked structure when I already hold node references — like an LRU cache, where the HashMap gives me O(1) access to the node."*

That answer is honest, specific, and reflects real engineering. It's a genuinely strong thing to say.

### Where linked lists genuinely win

1. **LRU cache** — `HashMap<K, Node>` + doubly linked list. The map gives O(1) node lookup, so the O(1) unlink/relink is *actually* O(1). This is the canonical correct use, and it's a top interview question.
2. **Anything where you already hold the node.** Java's own `LinkedHashMap`, iterator-based removal, intrusive lists in kernels.
3. **You must never invalidate references.** An `ArrayList` resize moves all the data; a linked list's nodes never move addresses. Critical for structures holding external pointers.
4. **Splicing whole sublists in O(1).** Concatenating two linked lists is one pointer assignment; concatenating two arrays is O(n).
5. **Unknown, unbounded growth with no resize spikes.** An `ArrayList` growing to 1 GB momentarily needs 2.5 GB (§2.6). A linked list never does.

## 7.4 Visual Explanation — the four core operations

### Traversal

```
   head
    |
    v
   +----+---+     +----+---+     +----+------+
   | 10 | *-|---->| 20 | *-|---->| 30 | null |
   +----+---+     +----+---+     +----+------+
    ^
   curr           curr           curr           curr = null -> STOP

   Node curr = head;
   while (curr != null) { visit(curr.val); curr = curr.next; }
   
   Explaining every arrow:
     head -> node(10)      the list's single entry point
     node(10).next -> node(20)   the '*' box holds the ADDRESS of node(20)
     node(30).next = null        null is the TERMINATOR. It means "no successor."
                                 Every singly linked list ends in null.
```

### Insert at head — O(1)

```
   BEFORE:
   head ---> [10] ---> [20] ---> null

   Step 1: create the node, point it at the current head
           [5] ---> [10] ---> [20] ---> null
            ^
           newNode                    (head still points at 10)

   Step 2: move head
   head ---> [5] ---> [10] ---> [20] ---> null

   CODE:
     Node n = new Node(5);
     n.next = head;      // FORWARD link first
     head = n;           // THEN move head
   
   Reverse those two lines and n.next points at itself -> infinite list.
```

### Insert after a given node — O(1)

```
   BEFORE:
   ... ---> [10] ---> [20] ---> ...
             ^
            prev

   Step 1: newNode.next = prev.next     (grab the rest of the list FIRST)
   
             [10] ---> [20] ---> ...
                        ^
             [15] ------+
              ^
             newNode

   Step 2: prev.next = newNode
   
   ... ---> [10] ---> [15] ---> [20] ---> ...
   
   Two assignments. O(1). Nothing else in the list was touched.
```

### Delete a node — O(1) given prev

```
   BEFORE:
   ... ---> [10] ---> [20] ---> [30] ---> ...
             ^         ^
            prev     target

   Step 1: prev.next = target.next
   
             [10] --------------> [30] ---> ...
                       [20] ---> [30]
                        ^ still points forward, but NOTHING points AT it
                          -> unreachable -> eligible for GC

   Step 2 (good hygiene): target.next = null
             Breaks the outgoing link too. Prevents the deleted node from
             keeping [30] and everything after it alive if some external
             reference to [20] still exists. This is a real memory-leak
             prevention step; java.util.LinkedList does exactly this.

   AFTER:
   ... ---> [10] ---> [30] ---> ...
```

**Notice what's missing: no shifting.** Deleting from the middle of an array moves every subsequent element. Deleting from a linked list moves nothing.

## 7.5 Step-by-Step Dry Run — reversing a singly linked list

This is *the* fundamental linked-list operation. Every interview touches it. Let's trace it with total precision.

```java
Node reverse(Node head) {
    Node prev = null;
    Node curr = head;
    while (curr != null) {
        Node next = curr.next;   // 1. SAVE the rest before we destroy the link
        curr.next = prev;        // 2. REVERSE this node's pointer
        prev = curr;             // 3. ADVANCE prev
        curr = next;             // 4. ADVANCE curr
    }
    return prev;                 // prev is the new head
}
```

**Trace on `1 -> 2 -> 3 -> null`:**

```
INITIAL STATE
   prev = null
   curr -> [1] -> [2] -> [3] -> null
   
   null      [1] ---> [2] ---> [3] ---> null
    ^         ^
   prev     curr


=== ITERATION 1 ===
 Line 1:  next = curr.next  ->  next points at [2]
          
          null      [1] ---> [2] ---> [3] ---> null
           ^         ^        ^
          prev     curr     next

 Line 2:  curr.next = prev  ->  [1].next = null
          
          null <--- [1]      [2] ---> [3] ---> null
           ^         ^        ^
          prev     curr     next
          
          [1] is now DETACHED from [2]. This is why we saved 'next' first!
          Without line 1, we would have lost [2] and everything after it.

 Line 3:  prev = curr  ->  prev points at [1]
 Line 4:  curr = next  ->  curr points at [2]
 
          null <--- [1]      [2] ---> [3] ---> null
                     ^        ^
                    prev     curr
          
          Reversed portion: [1] -> null
          Remaining portion: [2] -> [3] -> null


=== ITERATION 2 ===
 Line 1:  next = curr.next  ->  next points at [3]
 
          null <--- [1]      [2] ---> [3] ---> null
                     ^        ^        ^
                    prev     curr     next

 Line 2:  curr.next = prev  ->  [2].next = [1]
 
          null <--- [1] <--- [2]      [3] ---> null
                     ^        ^        ^
                    prev     curr     next

 Line 3-4: prev -> [2],  curr -> [3]
 
          null <--- [1] <--- [2]      [3] ---> null
                              ^        ^
                             prev     curr
          
          Reversed: [2] -> [1] -> null
          Remaining: [3] -> null


=== ITERATION 3 ===
 Line 1:  next = curr.next  ->  next = null
 Line 2:  curr.next = prev  ->  [3].next = [2]
 
          null <--- [1] <--- [2] <--- [3]
                              ^        ^
                             prev     curr    next = null

 Line 3-4: prev -> [3],  curr -> null
 
          null <--- [1] <--- [2] <--- [3]
                                       ^
                                      prev      curr = null


=== LOOP CONDITION: curr == null  ->  EXIT ===

 return prev  ->  returns [3]

FINAL LIST:  [3] ---> [2] ---> [1] ---> null    ✓
```

**Three things to burn in:**

1. **`next` must be saved before `curr.next` is overwritten.** Line 2 destroys the only link to the rest of the list. Line 1 is the insurance. Swap lines 1 and 2 and you lose the entire tail on the first iteration.

2. **Return `prev`, not `curr`.** When the loop exits, `curr` is `null` and `prev` points at the last node processed — which is the *original* tail, i.e. the *new* head. Returning `curr` returns null and the classic "my reverse returns an empty list" bug.

3. **The invariant** (say this in interviews): *"At the top of each iteration, `prev` is the head of the fully reversed prefix, and `curr` is the head of the untouched suffix."* State the invariant and the code writes itself.

**The recursive version, for contrast:**

```java
Node reverseRecursive(Node head) {
    if (head == null || head.next == null) return head;   // base: 0 or 1 node
    Node newHead = reverseRecursive(head.next);            // reverse the REST
    head.next.next = head;                                 // make the next node point back
    head.next = null;                                      // sever the forward link
    return newHead;                                        // propagate the new head up
}
```

The pivotal line is `head.next.next = head;`. Read it as: *"my successor's successor should be me."* On the way back up the stack, `head.next` is still the old successor (we haven't touched it), and after the recursive call it is the *tail* of the reversed sublist — so appending `head` after it is exactly right.

```
   reverseRecursive([1,2,3]):
     recurse on [2,3]:
       recurse on [3]:  base case, return [3]
       head=[2], head.next=[3].  [3].next = [2].  [2].next = null.
       list is now: [3] -> [2] -> null.  return [3]
     head=[1], head.next=[2].  [2].next = [1].  [1].next = null.
     list is now: [3] -> [2] -> [1] -> null.  return [3]
```

**Iterative: O(n) time, O(1) space. Recursive: O(n) time, O(n) stack space.** In an interview, write the iterative version and *mention* the recursive one. The iterative version is strictly better here, and choosing the better of two correct solutions is the signal.

## 7.6 Java Implementation

### Singly linked list

```java
package com.dsa.linkedlist;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringJoiner;

/** A singly linked list with a size field and tail pointer for O(1) append. */
public final class SinglyLinkedList<T> implements Iterable<T> {

    /** Static nested class: does NOT hold a reference to the outer instance. */
    private static final class Node<T> {
        T val;
        Node<T> next;
        Node(T val, Node<T> next) { this.val = val; this.next = next; }
    }

    private Node<T> head;
    private Node<T> tail;          // enables O(1) addLast
    private int size;
    private int modCount;          // for fail-fast iteration

    // ---------- O(1) operations ----------

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    /** Insert at the front. O(1). */
    public void addFirst(T val) {
        Node<T> n = new Node<>(val, head);   // forward link set in the constructor
        head = n;
        if (tail == null) tail = n;          // first element: head AND tail
        size++;
        modCount++;
    }

    /** Append. O(1) thanks to the tail pointer. */
    public void addLast(T val) {
        Node<T> n = new Node<>(val, null);
        if (tail == null) {
            head = tail = n;                 // empty list
        } else {
            tail.next = n;
            tail = n;
        }
        size++;
        modCount++;
    }

    /** Remove and return the front element. O(1). */
    public T removeFirst() {
        if (head == null) throw new NoSuchElementException("list is empty");
        Node<T> old = head;
        head = head.next;
        old.next = null;                     // help GC; avoid stale outgoing links
        if (head == null) tail = null;       // list became empty
        size--;
        modCount++;
        return old.val;
    }

    public T getFirst() {
        if (head == null) throw new NoSuchElementException("list is empty");
        return head.val;
    }

    // ---------- O(n) operations ----------

    /** Insert at an arbitrary index. O(n). */
    public void add(int index, T val) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
        if (index == 0)    { addFirst(val); return; }
        if (index == size) { addLast(val);  return; }

        Node<T> prev = nodeAt(index - 1);
        prev.next = new Node<>(val, prev.next);   // forward link, then backward
        size++;
        modCount++;
    }

    /** Remove by index. O(n). */
    public T remove(int index) {
        checkIndex(index);
        if (index == 0) return removeFirst();

        Node<T> prev = nodeAt(index - 1);
        Node<T> target = prev.next;
        prev.next = target.next;
        if (target == tail) tail = prev;      // deleted the last node
        target.next = null;
        size--;
        modCount++;
        return target.val;
    }

    public T get(int index) {
        checkIndex(index);
        return nodeAt(index).val;
    }

    /** Reverse in place, iteratively. O(n) time, O(1) space. */
    public void reverse() {
        Node<T> prev = null, curr = head;
        tail = head;                          // the old head becomes the new tail
        while (curr != null) {
            Node<T> next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        head = prev;
        modCount++;
    }

    // ---------- internals ----------

    private Node<T> nodeAt(int index) {
        Node<T> curr = head;
        for (int i = 0; i < index; i++) curr = curr.next;
        return curr;
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> curr = head;
            private final int expectedModCount = modCount;

            @Override public boolean hasNext() { return curr != null; }
            @Override public T next() {
                if (modCount != expectedModCount) {
                    throw new java.util.ConcurrentModificationException();
                }
                if (curr == null) throw new NoSuchElementException();
                T v = curr.val;
                curr = curr.next;
                return v;
            }
        };
    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(" -> ", "[", " -> null]");
        for (T v : this) sj.add(String.valueOf(v));
        return size == 0 ? "[]" : sj.toString();
    }
}
```

### Doubly linked list

```java
/** Doubly linked list with sentinel head and tail. Every operation is uniform. */
public final class DoublyLinkedList<T> implements Iterable<T> {

    private static final class Node<T> {
        T val;
        Node<T> prev, next;
        Node(T val) { this.val = val; }
    }

    private final Node<T> sentinelHead = new Node<>(null);   // never holds data
    private final Node<T> sentinelTail = new Node<>(null);   // never holds data
    private int size;

    public DoublyLinkedList() {
        sentinelHead.next = sentinelTail;
        sentinelTail.prev = sentinelHead;
    }

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    public void addFirst(T val) { insertAfter(sentinelHead, val); }
    public void addLast(T val)  { insertAfter(sentinelTail.prev, val); }

    /** Insert a new node immediately after 'prev'. O(1). Four pointer writes. */
    private void insertAfter(Node<T> prev, T val) {
        Node<T> next = prev.next;
        Node<T> n = new Node<>(val);
        n.prev = prev;          // 1
        n.next = next;          // 2
        prev.next = n;          // 3
        next.prev = n;          // 4
        size++;
    }

    /** Unlink a node. O(1) — no traversal, no null checks, thanks to sentinels. */
    private T unlink(Node<T> n) {
        n.prev.next = n.next;
        n.next.prev = n.prev;
        n.prev = n.next = null;         // help GC
        size--;
        return n.val;
    }

    public T removeFirst() {
        if (isEmpty()) throw new NoSuchElementException("list is empty");
        return unlink(sentinelHead.next);
    }

    public T removeLast() {
        if (isEmpty()) throw new NoSuchElementException("list is empty");
        return unlink(sentinelTail.prev);
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> curr = sentinelHead.next;
            @Override public boolean hasNext() { return curr != sentinelTail; }
            @Override public T next() {
                if (curr == sentinelTail) throw new NoSuchElementException();
                T v = curr.val;
                curr = curr.next;
                return v;
            }
        };
    }
}
```

### Circular linked list

```java
/** Circular singly linked list. Keeps only a 'tail' pointer — head is tail.next. */
public final class CircularLinkedList<T> {

    private static final class Node<T> {
        T val;
        Node<T> next;
        Node(T val) { this.val = val; }
    }

    private Node<T> tail;      // tail.next IS the head
    private int size;

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    /** O(1). */
    public void addLast(T val) {
        Node<T> n = new Node<>(val);
        if (tail == null) {
            n.next = n;                 // single node points to ITSELF
            tail = n;
        } else {
            n.next = tail.next;         // new node points to the head
            tail.next = n;              // old tail points to the new node
            tail = n;                   // the new node becomes the tail
        }
        size++;
    }

    /**
     * O(1). Insert after tail WITHOUT moving tail — so the new node
     * becomes tail.next, which is the head. This is why we keep tail.
     */
    public void addFirst(T val) {
        Node<T> n = new Node<>(val);
        if (tail == null) {
            n.next = n;
            tail = n;
        } else {
            n.next = tail.next;         // point at the old head
            tail.next = n;              // tail now points at us -> we ARE the head
        }                               // tail deliberately UNCHANGED
        size++;
    }

    public T removeFirst() {
        if (tail == null) throw new NoSuchElementException("list is empty");
        Node<T> head = tail.next;
        if (head == tail) {              // exactly one node
            tail = null;
        } else {
            tail.next = head.next;
        }
        head.next = null;
        size--;
        return head.val;
    }

    /** Josephus-style rotation: advance the "start" position by one. O(1). */
    public void rotate() {
        if (tail != null) tail = tail.next;
    }

    /** Traversal MUST use a do-while or a counter — there is no null terminator. */
    @Override
    public String toString() {
        if (tail == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        Node<T> curr = tail.next;        // start at head
        do {
            sb.append(curr.val);
            curr = curr.next;
            if (curr != tail.next) sb.append(" -> ");
        } while (curr != tail.next);     // stop when we come back around
        return sb.append(" -> (back to head)]").toString();
    }
}
```

*(Note the asymmetry: `addLast` and `addFirst` share almost identical code and differ in exactly one line — whether `tail` moves. That is the whole trick, and it works because **on a singly linked circular list you can never step backward**, so any O(1) operation must be expressible as "insert after the node I already hold.")*

## 7.7 Line-by-Line Code Explanation

**`private static final class Node<T>`**

Three modifiers, three reasons:
- **`static`** — a *static* nested class does **not** hold an implicit reference to the enclosing `SinglyLinkedList` instance. A non-static inner class would add a hidden 4–8 byte field to every single node *and* keep the whole list alive as long as any node is referenced. For a class you allocate millions of, this matters enormously. **Always make node classes static.** This is a real, measurable Java memory bug and an excellent interview point.
- **`final`** — nobody subclasses a node.
- **`private`** — the node type is an implementation detail. Callers see only `T`.

**`Node(T val, Node<T> next) { ... }` — a two-arg constructor**

This lets us write `new Node<>(val, head)` in `addFirst`, which sets the forward link *at construction time*. That structurally eliminates the "wrong order of assignment" bug from §7.2 — you cannot forget to set `next` because the constructor demands it. **Designing the API so the bug is unrepresentable is better than remembering not to write the bug.**

**`private Node<T> tail;` — why keep a tail pointer**

Without it, `addLast` must walk the entire list to find the end: O(n). With it: O(1). The cost is that *every* structural operation must maintain it, and forgetting to update `tail` in one branch is the classic bug. Note the three places we handle it:
- `addFirst`: `if (tail == null) tail = n;` — the empty-list case.
- `removeFirst`: `if (head == null) tail = null;` — the became-empty case.
- `remove(index)`: `if (target == tail) tail = prev;` — deleted the last node.

Miss any one of those and you get a dangling `tail` that either points at a removed node or is null when it shouldn't be. **When an interviewer asks you to add a tail pointer, immediately enumerate these three cases out loud.**

**`private int size;`**

`java.util.LinkedList` keeps one too. Without it, `size()` is O(n). This is a pure space-for-time trade: 4 bytes for O(1) size queries. Note that `size` must be updated in *every* mutating method — another invariant to maintain.

**`old.next = null;` in `removeFirst`**

Not strictly necessary for correctness — the node is already unreachable from `head`. But if any external code still holds a reference to the removed node, that reference would keep the *entire remainder of the list* alive through `old.next`. Nulling it breaks the chain. `java.util.LinkedList.unlink()` does exactly this, with the comment "help GC". **This is a real memory-leak class**, and mentioning it demonstrates you think about object lifetimes.

**`if (index == 0) { addFirst(val); return; }` in `add(int, T)`**

The head is special because there is no `prev` node to rewire — we must modify the `head` field itself. Delegating to `addFirst` keeps the special case in exactly one place. (The sentinel/dummy-node technique in §7.9 removes this special case entirely; see the Medium problem.)

**`if (index < 0 || index > size)` — `>` not `>=`**

Same distinction as Module 2, §2.6: inserting *at* `size` means appending, which is legal. Reading at `size` is not. **This asymmetry between insert-bounds and access-bounds catches people constantly.**

**`prev.next = new Node<>(val, prev.next);` — a one-liner that's safe by construction**

Java evaluates the right-hand side first. So `prev.next` is read (giving the old successor) and passed to the constructor, and only *then* is `prev.next` assigned. The order-of-assignment hazard is gone. Elegant, and worth pointing out.

**`tail = head;` at the start of `reverse()`**

The old head becomes the new tail. Must be captured **before** the loop destroys the structure. Forgetting this leaves `tail` pointing at what is now the head — so the next `addLast` appends to the wrong end and silently corrupts the list. **A classic bug in "reverse an in-house list class."**

**`private int modCount;` and the iterator's `expectedModCount`**

The **fail-fast** pattern from the JDK. Every structural modification bumps `modCount`. The iterator snapshots it at creation and compares on every `next()`. If they diverge, someone modified the list during iteration and we throw `ConcurrentModificationException`.

Why bother? Because modifying a list while iterating it produces *undefined behaviour* — you might skip elements, see them twice, or follow a pointer into a removed node. **Failing loudly and immediately is vastly better than silently wrong results.** This is why `for (T x : list) list.remove(x);` throws instead of corrupting. Implementing `modCount` in your own collection is a strong signal of Java maturity.

### The sentinel technique in `DoublyLinkedList`

This is the most important design idea in the module, so let's be explicit.

**Without sentinels**, `insertAfter` needs branches:
```java
if (prev == null)      { /* inserting at head */ }
if (prev.next == null) { /* inserting at tail */ }
if (head == null)      { /* empty list */ }
```
Three special cases, each a place to write a bug.

**With sentinels**, the list is *never* empty:
```
   EMPTY list:
   
   [SH] <----> [ST]
    ^           ^
    sentinelHead, sentinelTail — permanent, never removed, hold no data


   After addLast(10), addLast(20):
   
   [SH] <----> [10] <----> [20] <----> [ST]
   
   Every real node ALWAYS has a non-null prev and a non-null next.
```

Now look at `unlink`:
```java
n.prev.next = n.next;
n.next.prev = n.prev;
```
**Two lines. Zero null checks. Zero special cases.** It works identically for the first node, the last node, and the only node — because `n.prev` and `n.next` are guaranteed non-null (worst case they're the sentinels).

Compare `java.util.LinkedList.unlink()`, which does *not* use sentinels and consequently needs:
```java
if (prev == null) first = next; else { prev.next = next; ... }
if (next == null) last = prev;  else { next.prev = prev; ... }
```
Four branches instead of two assignments.

**The cost:** two extra node objects, forever. **The benefit:** every operation loses its edge cases. For an LRU cache or any structure doing heavy unlinking, this is unambiguously worth it. **"I'd use sentinel nodes so that insertion and deletion have no special cases at the boundaries"** is one of the most efficient sentences you can say in a linked-list interview.

### Why `CircularLinkedList` keeps `tail`, not `head`

Counterintuitive at first, then obvious:
```
   Keep HEAD:  addFirst is O(1)  (head = new node)
               addLast  is O(n)  (must walk to find the last node)

   Keep TAIL:  head IS tail.next, so it's O(1) to reach
               addLast  is O(1)  (insert after tail, move tail)
               addFirst is O(1)  (insert after tail, DON'T move tail)
```
**Keeping `tail` gives O(1) at both ends with a single pointer.** That's the whole reason circular lists are used for round-robin schedulers and buffers.

**`n.next = n;` for the single-node case** — a one-element circular list points at itself. This is the base case that makes everything else uniform.

**`do { ... } while (curr != tail.next);` — you MUST use do-while**

A circular list has **no null terminator**. A `while (curr != head)` loop would exit immediately, because `curr` starts *at* head. The `do-while` guarantees at least one iteration before checking. **Forgetting this is either an infinite loop or a zero-iteration loop, and both are classic circular-list bugs.** The alternative is to iterate `size` times with a counter.

## 7.8 Complexity Analysis

| Operation | Singly | Doubly | Circular (tail-kept) | ArrayList |
|---|---|---|---|---|
| `get(i)` / random access | O(n) | O(n) | O(n) | **O(1)** |
| `addFirst` | **O(1)** | **O(1)** | **O(1)** | O(n) |
| `addLast` (with tail) | **O(1)** | **O(1)** | **O(1)** | **O(1)** amortized |
| `removeFirst` | **O(1)** | **O(1)** | **O(1)** | O(n) |
| `removeLast` | **O(n)** | **O(1)** | O(n) | **O(1)** |
| `add(i, x)` | O(n) | O(n) | O(n) | O(n) |
| Delete a node **given the node** | O(n)* | **O(1)** | O(n)* | O(n) |
| Search | O(n) | O(n) | O(n) | O(n) |
| Reverse | O(n), O(1) space | O(n) | O(n) | O(n) |
| Memory per element | ~24 B | ~32 B | ~24 B | ~4–16 B |

\* **The single most important cell in this table.** On a *singly* linked list, deleting a node you hold a pointer to is **O(n)**, not O(1) — because you need its **predecessor**, and finding that requires walking from the head. On a *doubly* linked list it's genuinely O(1), because `node.prev` is right there.

**This is exactly why `LinkedHashMap` and every LRU cache implementation use a doubly linked list.** Interviewers ask this specific question. Have the answer ready:

> *"Deleting a known node is O(1) on a doubly linked list and O(n) on a singly linked list, because the singly linked version has to find the predecessor. That's why LRU caches pair a HashMap with a doubly linked list — the map gives O(1) node lookup and the double links give O(1) unlinking."*

**`removeLast` on singly is O(n)** even with a tail pointer, for the same reason: after removing the tail you need to set `tail = secondToLast`, which requires a full traversal. Doubly linked: `tail.prev` — O(1).

## 7.9 Common Mistakes

1. **Wrong assignment order** — `prev.next = n; n.next = prev.next;` creates a self-loop and leaks the tail. §7.2.
2. **Losing the head** — reassigning `head` before saving it. The list becomes unreachable garbage.
3. **Not saving `next` before rewiring** in reverse. Loses the entire remainder.
4. **Returning `curr` instead of `prev`** from reverse. Returns null.
5. **Forgetting to update `tail`** in one of the three cases from §7.7.
6. **Forgetting to update `size`.**
7. **`while (curr.next != null)` when you meant `while (curr != null)`** — the first throws `NullPointerException` on an empty list, and stops one node early on a non-empty one. Choose deliberately: use `curr != null` to visit every node, `curr.next != null` to visit every node *that has a successor* (e.g. when you need pairs).
8. **Not handling the empty list or single-node list.** Always test n = 0 and n = 1. Most linked-list bugs live there.
9. **Non-static inner Node class** — hidden outer reference on every node. §7.7.
10. **Using `while (curr != head)` on a circular list** — zero iterations. Use `do-while`.
11. **Assuming `LinkedList.get(i)` is fast.** It's O(n). A `for (int i = 0; i < list.size(); i++) list.get(i)` loop over a `LinkedList` is **O(n²)**. Use the iterator or a for-each. This is a real production bug that shows up in profilers constantly.
12. **Modifying a list while iterating it** — `ConcurrentModificationException`, or silent corruption if you rolled your own.

## 7.10 Interview Perspective

Linked lists are pure **pointer-manipulation** tests. Unlike arrays, you can't fake your way through with library calls — you either understand references or you don't. That's exactly why interviewers like them.

**The four things they're evaluating:**

1. **Do you draw?** Draw four boxes. Redraw the arrows for each line. Candidates who draw succeed; candidates who don't lose track by line four. This is not optional advice.
2. **Do you handle n = 0 and n = 1 without being asked?** Say it upfront: *"Let me handle the empty list and single-node list first."* Then write the guards.
3. **Do you reach for a dummy head?** The moment a problem involves possibly-deleting-the-head, a dummy node eliminates the special case. Using it unprompted is a strong signal.
4. **Do you get O(1) space?** Most linked-list problems have an in-place pointer-rewiring solution. If you copied values into an `ArrayList`, expect *"now do it in O(1) space."*

**The five techniques, with the problems they unlock:**

**(1) Dummy head node.** Allocate a fake node before the real head. Now the real head has a predecessor, so *no* operation needs a special case.
```java
Node dummy = new Node(0);
dummy.next = head;
// ... work with dummy.next as "the head" ...
return dummy.next;    // the possibly-changed real head
```
Unlocks: *Remove Nth From End*, *Remove Elements*, *Merge Two Sorted Lists*, *Partition List*, *Remove Duplicates*.

**(2) Two pointers with a fixed offset.** Advance `fast` by `k`, then move both until `fast` hits the end. `slow` is now `k` from the end.
Unlocks: *Nth Node From End* in one pass.

**(3) Two pointers with different speeds (Floyd's tortoise & hare).** `slow` moves 1, `fast` moves 2.
```
   If they ever meet -> there is a CYCLE.
   When fast reaches the end -> slow is at the MIDDLE.
```
Unlocks: *Detect Cycle*, *Find Cycle Start*, *Find Middle*, *Palindrome List*, *Reorder List*.

**(4) Three-pointer walk (`prev`, `curr`, `next`).** In-place reversal. §7.5.
Unlocks: *Reverse List*, *Reverse Between Positions*, *Reverse in k-Groups*, *Swap Pairs*, *Add Two Numbers* (reversed digits).

**(5) Recursion.** A list *is* a node plus a smaller list — perfectly recursive.
Unlocks: *Merge Two Lists*, *Reverse*, *Flatten Multilevel List*. Just remember it's O(n) stack.

**The must-know question list** (each is a real, frequently-asked problem):
```
   Reverse a linked list                        -> three-pointer walk
   Detect a cycle                               -> Floyd's
   Find where the cycle starts                  -> Floyd's + reset one pointer to head
   Find the middle node                         -> slow/fast
   Merge two sorted lists                       -> dummy head + two pointers
   Remove the nth node from the end             -> offset two pointers
   Check if a list is a palindrome               -> find middle, reverse half, compare
   Intersection of two lists                    -> length difference, or two-pass switch
   Reverse in groups of k                       -> nested three-pointer walk
   LRU cache                                    -> HashMap + doubly linked list + sentinels
   Copy a list with random pointers             -> interleave nodes, or HashMap
   Add two numbers as lists                     -> carry propagation, dummy head
   Flatten a multilevel doubly linked list      -> stack or recursion
```

**What to say when asked "array or linked list?"**

> *"Almost always array — specifically `ArrayList` or `ArrayDeque`. Arrays win on random access, memory footprint, and cache locality, which in practice dominates. Linked lists win in one narrow but real case: when I already hold a reference to the node I want to modify. That's why LRU caches use a HashMap plus a doubly linked list. Also worth noting `LinkedList.get(i)` is O(n), so index-based loops over it are accidentally O(n²) — a bug I've seen in real code."*

## 7.11 Practice Problems

### Easy — Merge Two Sorted Linked Lists
Given the heads of two sorted linked lists, merge them into one sorted list and return its head. Splice the existing nodes; don't allocate new ones.
```
1 -> 2 -> 4
1 -> 3 -> 4
-> 1 -> 1 -> 2 -> 3 -> 4 -> 4
```

### Medium — Remove Nth Node From End of List
Given a list and an integer `n`, remove the nth node from the end and return the head. **One pass.**
```
1 -> 2 -> 3 -> 4 -> 5,  n = 2   ->  1 -> 2 -> 3 -> 5
1,                      n = 1   ->  (empty list)
```

### Hard — Detect a Cycle and Return Its Starting Node
Given a list that may contain a cycle, return the node where the cycle begins, or `null` if there is none. **O(1) space.**
```
3 -> 2 -> 0 -> -4
     ^          |
     +----------+
   -> returns the node with value 2
```

## 7.12 Solution Walkthrough

### Easy — Merge Two Sorted Lists

**The insight:** this is the `merge` step of merge sort (§6.6), except we relink pointers instead of copying into a buffer — so it's **O(1) space**.

**Why a dummy head?** Because the first node of the result could come from either list, and without a dummy you'd need a special case to initialise the head:
```java
// WITHOUT dummy — ugly
if (a.val <= b.val) { head = a; a = a.next; } else { head = b; b = b.next; }
Node curr = head;
// ... plus a null check on a and b before even that
```
With a dummy, there is no "first node" case at all. The loop handles everything.

```java
public Node mergeTwoLists(Node a, Node b) {
    Node dummy = new Node(0);       // fake node — never part of the answer
    Node curr = dummy;              // the "write cursor"

    while (a != null && b != null) {
        if (a.val <= b.val) {       // <= keeps it STABLE (a's nodes come first on ties)
            curr.next = a;
            a = a.next;
        } else {
            curr.next = b;
            b = b.next;
        }
        curr = curr.next;           // advance the write cursor
    }

    curr.next = (a != null) ? a : b;   // attach whichever list still has nodes

    return dummy.next;              // skip the dummy; return the real head
}
```

**Dry run on `a = 1->2->4`, `b = 1->3->4`:**

```
dummy -> null
curr = dummy
a -> [1a] -> [2] -> [4a]
b -> [1b] -> [3] -> [4b]

--- Iteration 1 ---
   a.val=1, b.val=1.  1 <= 1  ->  take from A (stability: A's node first)
   curr.next = [1a]
   dummy -> [1a]
   a -> [2] -> [4a]
   curr = [1a]

--- Iteration 2 ---
   a.val=2, b.val=1.  2 <= 1 is FALSE  ->  take from B
   curr.next = [1b]
   dummy -> [1a] -> [1b]
   b -> [3] -> [4b]
   curr = [1b]

--- Iteration 3 ---
   a.val=2, b.val=3.  2 <= 3  ->  take from A
   dummy -> [1a] -> [1b] -> [2]
   a -> [4a]
   curr = [2]

--- Iteration 4 ---
   a.val=4, b.val=3.  4 <= 3 FALSE  ->  take from B
   dummy -> [1a] -> [1b] -> [2] -> [3]
   b -> [4b]
   curr = [3]

--- Iteration 5 ---
   a.val=4, b.val=4.  4 <= 4  ->  take from A
   dummy -> [1a] -> [1b] -> [2] -> [3] -> [4a]
   a -> null
   curr = [4a]

--- Loop exits: a == null ---

   curr.next = b  ->  attaches [4b] AND everything after it in ONE assignment
   dummy -> [1a] -> [1b] -> [2] -> [3] -> [4a] -> [4b] -> null

return dummy.next = [1a]

FINAL: 1 -> 1 -> 2 -> 3 -> 4 -> 4    ✓
```

**Four details worth articulating:**

**1. `curr.next = (a != null) ? a : b;` — one line, not a loop.**
This is the linked-list advantage over arrays. In array merge sort we had to *copy* the remaining elements one by one. Here, attaching the rest of a list is a **single pointer assignment**, because the remaining nodes are already correctly linked to each other. O(1), not O(k). **Point this out** — it demonstrates you understand what linked lists are actually good at.

**2. `return dummy.next`, never `return dummy`.** The dummy is scaffolding. Returning it prepends a bogus 0 to the answer.

**3. `<=` preserves stability.** On ties, take from `a`. If these lists came from splitting a larger list, that maintains original relative order — exactly the same reasoning as merge sort's `<=` (§6.6).

**4. We allocated exactly one node** (the dummy), and it's discarded. The answer reuses all the original nodes. So **O(1) auxiliary space.** If an interviewer asks whether the dummy violates O(1), the answer is no — one node is a constant.

**Complexity:** **O(m + n) time** — each node is visited exactly once. **O(1) space.**

**The recursive version, for completeness:**
```java
public Node mergeTwoLists(Node a, Node b) {
    if (a == null) return b;
    if (b == null) return a;
    if (a.val <= b.val) { a.next = mergeTwoLists(a.next, b); return a; }
    else                { b.next = mergeTwoLists(a, b.next); return b; }
}
```
Beautiful — four lines, and it reads exactly like the definition. But **O(m + n) stack space**, which risks `StackOverflowError` on long lists. Present the iterative version as your answer and offer the recursive one as "more elegant but O(n) stack." Naming the trade-off is the point.

### Medium — Remove Nth Node From End (one pass)

**The naive two-pass approach:** walk once to count the length `L`, then walk again to node `L - n - 1` and unlink. Correct, O(n), but two passes. The interviewer wants one.

**The insight: a fixed gap between two pointers.**

If `fast` is exactly `n` nodes ahead of `slow`, then when `fast` reaches the end, `slow` is exactly `n` from the end. The gap does the counting for us — no length needed.

```
   List: 1 -> 2 -> 3 -> 4 -> 5 -> null,  n = 2

   Set up a gap of n = 2:
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
     ^              ^
   slow            fast          gap = 2

   Now advance BOTH until fast hits null:
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
             ^              ^
            slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                    ^              ^
                   slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                           ^              ^
                          slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                                  ^              ^
                                 slow           fast = null -> STOP
                                 
   Hmm — slow is at [4], but we want to DELETE [4] (2nd from end).
   To delete a node we need its PREDECESSOR. So we need slow to stop at [3].
   
   FIX: start slow at dummy and use a gap of n+1, OR equivalently
        advance fast n+1 times from dummy. Let's redo it properly.
```

Let me set it up correctly — and note that **getting this offset right is the whole problem**:

```java
public Node removeNthFromEnd(Node head, int n) {
    Node dummy = new Node(0);
    dummy.next = head;

    Node fast = dummy;
    Node slow = dummy;

    // Advance fast by n + 1 steps, so the gap between slow and fast is n + 1.
    for (int i = 0; i <= n; i++) {
        if (fast == null) return head;   // n is larger than the list length
        fast = fast.next;
    }

    // Move both until fast falls off the end.
    while (fast != null) {
        fast = fast.next;
        slow = slow.next;
    }

    // slow is now the PREDECESSOR of the node to delete.
    Node target = slow.next;
    slow.next = target.next;
    target.next = null;                  // help GC

    return dummy.next;
}
```

**Corrected dry run: `1 -> 2 -> 3 -> 4 -> 5`, n = 2.**

```
dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null

--- Setup: advance fast n+1 = 3 times from dummy ---
   i=0: fast = dummy.next = [1]
   i=1: fast = [2]
   i=2: fast = [3]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
     ^                     ^
   slow                   fast          gap = 3 = n+1

--- Advance both until fast == null ---
   Step 1: fast = [4], slow = [1]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
             ^                     ^
            slow                  fast

   Step 2: fast = [5], slow = [2]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                    ^                     ^
                   slow                  fast

   Step 3: fast = null, slow = [3]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                           ^                        ^
                          slow                    fast=null

--- fast is null -> stop. slow = [3]. ---

   target = slow.next = [4]        <-- the 2nd node from the end. CORRECT.
   slow.next = target.next = [5]
   
   dummy -> [1] -> [2] -> [3] --------> [5] -> null
   
   target.next = null   (detach [4] fully)

return dummy.next = [1]

FINAL: 1 -> 2 -> 3 -> 5    ✓
```

**Now the edge case that breaks naive solutions: `head = [1]`, n = 1** (delete the only node).

```
dummy -> [1] -> null

Setup: advance fast n+1 = 2 times from dummy:
   i=0: fast = [1]
   i=1: fast = null
   
   dummy -> [1] -> null
     ^              ^
   slow           fast = null

Loop doesn't execute (fast is already null). slow = dummy.

   target = slow.next = [1]
   slow.next = target.next = null
   
   dummy -> null

return dummy.next = null    ✓  correct: the list is now empty
```

**This is exactly why the dummy node is essential.** Without it, deleting the head requires a special branch (`if (target == head) return head.next;`). With it, `slow` can legitimately *be* the dummy, and the same two lines of unlinking code work. **State this out loud:** *"I'll use a dummy head so that deleting the actual head needs no special case."*

**Three details:**

**1. Why `n + 1` and not `n`?** Because to delete a node you need its **predecessor** (this is a singly linked list — §7.8). A gap of `n` puts `slow` *on* the target; a gap of `n + 1` puts it one before. Get this wrong and you delete the neighbour. **Verify the offset with the smallest case (`n = 1`, single node) — that's how you catch it in an interview.**

**2. `for (int i = 0; i <= n; i++)`** — note `<=`, giving `n + 1` iterations. Equivalent to `for (i = 0; i < n + 1; i++)`. Either is fine; be deliberate about which.

**3. `if (fast == null) return head;`** — defensive guard for `n > length`. The problem usually guarantees valid `n`, but volunteering the check shows you think about malformed input. In production you'd throw `IllegalArgumentException` instead of silently doing nothing — say that too.

**Complexity:** **O(L) time** — `fast` traverses the list once; `slow` traverses part of it. One pass. **O(1) space** — two pointers plus one dummy node.

### Hard — Detect a Cycle and Find Its Start (Floyd's Algorithm)

Two parts. Part 1 is well known; Part 2 has a genuinely surprising proof that interviewers love.

**Part 1 — detection. Why do slow and fast necessarily meet?**

`slow` moves 1 step per iteration; `fast` moves 2.

```
   NO CYCLE:  fast reaches null and we exit. Simple.

   CYCLE:     Once BOTH pointers are inside the loop, consider the
              GAP between them (measured forward, along the cycle).
              
              Each iteration:  slow advances 1, fast advances 2
                            -> fast gains exactly 1 on slow
                            -> the gap SHRINKS BY EXACTLY 1 each iteration
              
              A gap that decreases by exactly 1 must eventually reach 0.
              It can never "jump over" zero, because the step is exactly 1.
              
              -> They MUST meet.  Guaranteed, in at most (cycle length) iterations.
```

**This is why the speeds must be 1 and 2.** With speeds 1 and 3, the gap shrinks by 2 each step and could skip from +1 to −1 without ever being 0 — for cycles of even length, they may never meet. **"Why 2x and not 3x?" is a real interview follow-up.** The answer: a relative speed of exactly 1 guarantees the gap hits zero.

**Part 2 — finding the start. The result that looks like magic.**

Set up the geometry:

```
   head                    cycle start (S)
    |                            |
    v                            v
   [A]--->[B]--->...--->[C]--->[ S ]--->[X]--->[Y]
                                 ^               |
                                 |               v
                                [W]<---[V]<-----[Z]

   Let:
     F = distance from head to the cycle start S
     a = distance from S to the MEETING POINT M (going forward around the cycle)
     C = total cycle length

   +----------- F -----------+---- a ----+
   head                      S           M
                             |           |
                             +--- C - a -+  (rest of the way around)
```

**Now the algebra.** Say they meet after `k` iterations. Then:
```
   slow has travelled:  k        steps
   fast has travelled:  2k       steps
```

`slow` walked `F` to reach `S`, then `a` more to reach `M`. It may have looped some whole number of times too, but for the *first* meeting it won't have:
```
   k = F + a
```

`fast` walked `F` to reach `S`, then went around the cycle some number of full times `m`, then `a` more:
```
   2k = F + m·C + a
```

Substitute `k = F + a`:
```
   2(F + a) = F + m·C + a
   2F + 2a  = F + m·C + a
   F + a    = m·C
   F        = m·C - a
   F        = (m - 1)·C + (C - a)
```

**Read that last line.** `C - a` is the distance from the meeting point `M` forward around the cycle back to `S`. And `(m-1)·C` is just some whole number of extra laps, which changes nothing about where you end up.

> **So: the distance from the head to the cycle start equals the distance from the meeting point, going forward, back to the cycle start (plus whole laps).**

Therefore: **put one pointer back at `head`, leave the other at the meeting point, and advance both one step at a time. They will meet exactly at the cycle start.**

```
   Verify with a concrete example:
   
   List: 3 -> 2 -> 0 -> -4, with -4 pointing back to 2
   
   Indices: [0]=3, [1]=2, [2]=0, [3]=-4.  Cycle start = index 1.
   F = 1 (head to index 1),  C = 3 (nodes 1,2,3)
   
   slow/fast trace:
     start:  slow=[0], fast=[0]
     iter 1: slow=[1], fast=[2]
     iter 2: slow=[2], fast=[1]      (fast went [2]->[3]->[1])
     iter 3: slow=[3], fast=[3]      (fast went [1]->[2]->[3])   MEET at index 3
   
   So M = index 3, a = distance from S(index 1) to M(index 3) = 2
   Check: F = 1,  C - a = 3 - 2 = 1.   F == C - a.  ✓
   
   Phase 2: p1 = head = [0], p2 = M = [3]
     step 1: p1 = [1], p2 = [1]     (index 3's next IS index 1)
     They meet at index 1 = the cycle start.  ✓  Value 2.
```

```java
public Node detectCycleStart(Node head) {
    if (head == null || head.next == null) return null;

    // PHASE 1: detect whether a cycle exists, and find the meeting point.
    Node slow = head, fast = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;              // 1 step
        fast = fast.next.next;         // 2 steps
        if (slow == fast) break;       // met -> cycle exists
    }

    // If fast ran off the end, there is no cycle.
    if (fast == null || fast.next == null) return null;

    // PHASE 2: reset one pointer to head; advance both at the SAME speed.
    slow = head;
    while (slow != fast) {
        slow = slow.next;
        fast = fast.next;              // NOTE: 1 step now, not 2
    }
    return slow;                       // == the cycle start
}
```

**Four details that matter:**

**1. `while (fast != null && fast.next != null)` — both checks, in this order.**
`fast` advances two steps, so we must confirm *both* hops are legal before taking them. If `fast.next` were null and we wrote `fast.next.next`, that's a `NullPointerException`. And `fast != null` must come first, or `fast.next` itself throws. **Short-circuit `&&` order is load-bearing** — the same pattern as insertion sort's `j >= 0 &&` (§6.5) and binary search's bounds checks.

**2. `if (slow == fast)` uses reference equality, deliberately.**
We're asking *"are these the same node?"*, not *"do they hold equal values?"* A list can legitimately contain duplicate values without a cycle. `==` on references is exactly right here — one of the few places in Java where `==` is the correct comparison (contrast with strings, §3.3).

**3. Checking `slow == fast` AFTER moving, not before.**
Both start at `head`, so checking before the first move would report a cycle immediately on every list. Move first, then compare.

**4. In Phase 2, `fast` moves ONE step, not two.**
This trips people up because the variable is named `fast`. After Phase 1, `fast` is just "the pointer sitting at the meeting point." The proof requires both pointers to move at **equal** speed so that they cover `F` and `C - a` respectively in the same number of steps. Leave it at 2 and it overshoots. **A well-named refactor (`meetingPoint` instead of `fast`) would prevent this bug** — worth saying, since interviewers appreciate candidates who think about readability.

**Complexity.**
- **Phase 1:** `slow` travels at most `F + C` steps before the meeting (it enters the cycle after `F`, then meets within one lap). → O(n).
- **Phase 2:** exactly `F` steps. → O(n).
- **Total: O(n) time, O(1) space.**

**The alternative, and why Floyd's is better.** A `HashSet<Node>` of visited nodes detects the cycle in O(n) time — but **O(n) space**. The first node you see twice *is* the cycle start, which is arguably simpler. **Present both:** *"A HashSet gives O(n) time and O(n) space and is very simple. Floyd's gives O(n) time and O(1) space, at the cost of a non-obvious proof. If space matters, Floyd's; if readability matters and n is small, the HashSet."* Showing that you know both, and can articulate when each is preferable, is the complete answer.

**Where Floyd's turns up beyond linked lists.** The algorithm is really about **cycle detection in any functional graph** — any sequence where `xₙ₊₁ = f(xₙ)`. That includes:
- *Find the Duplicate Number* — treat `nums[i]` as a pointer to index `nums[i]`; the duplicate creates a cycle. O(n) time, O(1) space, without modifying the array.
- *Happy Number* — the digit-square-sum sequence either reaches 1 or cycles.
- Detecting cycles in pseudorandom number generators, and in Pollard's rho factorisation algorithm.

**Recognising that "sequence defined by repeated function application" means "Floyd's applies"** is a genuinely transferable insight, and it's the kind of connection that makes an interviewer sit up.

---
---

# End of Part 1

## What you now have

You've covered the foundation layer at full depth:

```
   Module 1  Complexity Analysis    -> the tool that GENERATES algorithms
   Module 2  Arrays                 -> contiguous memory, index-as-hash, two pointers
   Module 3  Strings                -> immutability, frequency arrays, sliding window
   Module 4  Recursion              -> the call stack, recursion trees, backtracking
   Module 5  Searching              -> two binary search templates, search-on-answer
   Module 6  Sorting                -> five paradigms in miniature, the Ω(n log n) proof
   Module 7  Linked Lists           -> pointer discipline, dummy heads, Floyd's
```

More importantly, you have the **techniques** that recur through everything that follows:

| Technique | First met | Reused in |
|---|---|---|
| Amortized argument | §1.4 | ArrayList, first-missing-positive, quickselect, monotonic stack |
| Prefix sum | §1.10 | counting sort, range queries, Fenwick tree, subarray-sum problems |
| Two pointers | §2.11 | palindromes, merge, partitioning, three-sum |
| Index-as-hash | §2.9 | cyclic sort, duplicate detection, Floyd on arrays |
| Frequency array | §3.5 | anagrams, sliding window, counting sort, radix |
| Sliding window | §3.10 | substrings, subarrays, rate limiting |
| Recursion tree | §4.4 | all divide-and-conquer, all DP complexity analysis |
| Backtrack + snapshot | §4.7 | subsets, permutations, N-queens, Sudoku, word search |
| Binary search on answer | §5.9 | eight-plus named problems |
| Divide-and-conquer counting | §6.14 | inversions, reverse pairs, range sums |
| Three-way partition | §6.14 | quicksort with duplicates, Dutch flag |
| Dummy head | §7.12 | every list-deletion problem |
| Floyd's cycle detection | §7.12 | duplicate number, happy number, Pollard's rho |

## What's next

Say **"continue"** and I'll append the next block to this same file, at exactly this depth:

```
   Module  8  Stacks                      (+ monotonic stack, expression evaluation)
   Module  9  Queues                      (circular queue, deque, priority queue)
   Module 10  Hashing                     (HashMap internals, collision handling, load factor)
   Module 11  Trees                       (binary tree, BST, AVL, segment tree, Fenwick)
   Module 12  Heaps                       (+ top-k, median maintenance)
   Module 13  Trie
   Module 14  Graphs                      (representation, BFS, DFS)
   Module 15  Disjoint Set Union
   Module 16  Topological Sort
   Module 17  Minimum Spanning Trees       (Prim, Kruskal)
   Module 18  Shortest Paths               (Dijkstra, Bellman-Ford, Floyd-Warshall)
   Module 19  Greedy Algorithms
   Module 20  Backtracking
   Module 21  Dynamic Programming          (memo, tabulation, state design, patterns)
   Module 22  Sliding Window               (formalised)
   Module 23  Two Pointers                 (formalised)
   Module 24  Binary Search Pattern        (extended)
   Module 25  Monotonic Stack
   Module 26  Monotonic Queue
   Module 27  Prefix Sum
   Module 28  Difference Array
   Module 29  Bit Manipulation
   Module 30  Advanced DP
   Module 31  Advanced Graph Algorithms
   Module 32  Interview Patterns
   Module 33  Java Collections in DSA
   Module 34  Competitive Programming Techniques
   Module 35  Most Frequently Asked Questions
```

## Before you move on — how to actually study this

Reading this file changes nothing. Here's the protocol that does:

**1. Implement from a blank file, not from memory of the text.** Close this document. Write `mergeSort`, `partition`, `reverse` (linked list), `lowerBound`, and `siftDown` from scratch. If you can't, you haven't learned them — reread that section and try again tomorrow.

**2. Test the three inputs that break everything.** For every function you write: empty input, single element, all-identical elements. Most bugs in this entire document live in those three cases.

**3. Do the dry runs by hand on paper.** Not in your head. On paper, with the boxes and arrows drawn. This is the single highest-leverage study habit for DSA and almost nobody does it.

**4. Say the complexity out loud after every solution.** "O(n log n) time because there are log n levels each doing O(n) work; O(n) space for the buffer." Build the habit now so it's automatic under pressure.

**5. When stuck on a new problem, run the checklists.** §2.9 for arrays, §3.8 for strings, §7.10 for linked lists. Pattern-matching to a technique is a learnable skill, and those checklists are the training wheels.

Now go implement merge sort without looking. I'll wait.
