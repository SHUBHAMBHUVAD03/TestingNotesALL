*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 2 — Arrays

## 2.1 Intuition

An array is a **row of identical mailboxes, numbered from zero, with no gaps.**

That mundane sentence contains the entire theory of arrays. Let me unpack why.

Picture a street of mailboxes. Each box is exactly the same size. They are physically adjacent. Box numbering starts at 0.

```
        index:   0      1      2      3      4
              +------+------+------+------+------+
    values:   |  10  |  20  |  30  |  40  |  50  |
              +------+------+------+------+------+
   address:    1000   1004   1008   1012   1016
                 ^      ^
                 |      +-- 4 bytes later (an int is 4 bytes)
                 +--------- base address
```

Now: I ask you for box 3. How long does it take you to find it?

You don't walk down the street counting. You **compute** where it is:

```
address of arr[i] = base_address + (i × size_of_one_element)
address of arr[3] = 1000 + (3 × 4) = 1012
```

One multiply, one add. **That's it.** Whether the array holds 5 elements or 5 billion, finding `arr[i]` is the same two arithmetic operations. That's **O(1) random access**, and it is the single reason arrays are the foundation of every other data structure.

**And now the price.** That formula only works because the boxes are adjacent and equal-sized. Which means:

- **The size is fixed at creation.** You cannot add a 6th mailbox if the neighbour's house is there. To grow, you must find a new plot and move everything.
- **Insertion in the middle is expensive.** To insert at index 1, everything from index 1 onwards must physically shift right to make a hole.

```
    Insert 15 at index 1:

    Before:  [ 10 | 20 | 30 | 40 | 50 ]
                    \    \    \    \
                     v    v    v    v      4 elements must MOVE
    After:   [ 10 | 15 | 20 | 30 | 40 ]    (50 falls off / needs bigger array)
```

Every array trade-off in existence falls out of that one geometric fact. **O(1) access, O(n) insertion/deletion, fixed size.** Not three separate facts to memorise — one fact with three consequences.

## 2.2 Mental Model

Three mental postures to adopt:

**Posture 1 — "Index is an offset, not a position."**

`arr[3]` does not mean "the 3rd thing." It means "3 elements' worth of bytes past the start." That's why arrays are 0-indexed: `arr[0]` is "0 bytes past the start" — the start itself. Once you internalise this, off-by-one errors mostly stop happening, because you start thinking in offsets and gaps rather than counting on your fingers.

**Posture 2 — "The last valid index is `n - 1`, always."**

An array of length 5 has indices 0, 1, 2, 3, 4. `arr[5]` throws `ArrayIndexOutOfBoundsException`. Write `< length`, never `<= length`. Every single time you type a loop condition, the `<` should be automatic.

**Posture 3 — "If you're scanning an array twice, ask whether one pass would do."**

Most array interview problems are secretly "can you do this in one pass with O(1) extra space?" Techniques like two pointers (Module 23), sliding window (Module 22), and prefix sums (Module 27) are all answers to that question. Arrays are where you learn the *habit* of collapsing multiple passes into one.

## 2.3 Internal Working — what the JVM actually does

This is where Java gets interesting, and where most tutorials stop far too early.

### An array in Java is an object

```java
int[] arr = new int[5];
```

Two separate things exist after this line:

```
       STACK                              HEAP
   +-------------+              +----------------------------+
   |  arr        |------------->|  Object header  (~16 bytes)|
   | (reference) |              |  - class ptr: int[]        |
   |  8 bytes    |              |  - mark word / hash / GC   |
   +-------------+              |  length: 5   (4 bytes)     |
                                +----------------------------+
                                |  [0] = 0                   |
                                |  [1] = 0                   |  contiguous
                                |  [2] = 0                   |  payload
                                |  [3] = 0                   |  5 × 4 = 20 bytes
                                |  [4] = 0                   |
                                +----------------------------+
```

Key facts, each of which has consequences:

1. **`arr` on the stack is just a reference** (a pointer, typically 8 bytes, or 4 with compressed oops). The actual data lives on the heap.
2. **`length` is stored in the object header.** This is why `arr.length` is O(1) and is a *field*, not a method — no parentheses. (`String.length()` *is* a method — an inconsistency in Java that trips up beginners constantly.)
3. **Java zero-initialises the payload.** `int[]` → all 0. `boolean[]` → all `false`. `double[]` → all 0.0. `Object[]` / `String[]` → all `null`. You never read garbage in Java, unlike C. This costs a memset at allocation time but eliminates an entire class of bugs.
4. **Every access is bounds-checked.** `arr[i]` compiles to a bytecode instruction that compares `i` against `length` and throws if out of range. This is a real cost — which the JIT compiler often eliminates when it can prove `i` is in range (loop bounds hoisting). This is why `for (int i = 0; i < arr.length; i++)` can be *faster* than caching the length in a variable: the JIT recognises the idiom.

### Object arrays are arrays of references, not objects

This is a huge one.

```java
int[]    primitives = {10, 20, 30};
String[] objects    = {"ab", "cd", "ef"};
```

```
   primitives (heap):                   objects (heap):
   +--------+                           +--------+
   | header |                           | header |
   | len 3  |                           | len 3  |
   +--------+                           +--------+
   |   10   |  <- actual value          |  ref --|---> String "ab" (elsewhere in heap)
   |   20   |  <- actual value          |  ref --|---> String "cd" (elsewhere in heap)
   |   30   |  <- actual value          |  ref --|---> String "ef" (elsewhere in heap)
   +--------+                           +--------+
   ONE contiguous block                 ONE contiguous block of POINTERS,
   Cache-friendly. Fast.                objects scattered across the heap.
```

Consequences you can state in an interview:

- `int[1000]` is one cache-friendly block; iterating it is extremely fast because the CPU prefetches the next cache line and gets 16 ints at once.
- `Integer[1000]` is 1000 pointers to 1000 separate heap objects, likely scattered. Iterating it causes **cache misses** — potentially 10–100× slower for the same logical operation.
- This is why **`int[]` beats `List<Integer>` for hot numeric loops**, and why competitive programmers religiously use primitive arrays. It's not superstition; it's memory locality.

### 2D arrays in Java are arrays of arrays

```java
int[][] grid = new int[3][4];
```

Java does **not** have true 2D arrays. It has an array of references, each pointing to a separate 1D array:

```
   grid
    |
    v
  +------+
  | ref -|---> +----+----+----+----+
  +------+     |  0 |  0 |  0 |  0 |   row 0  (separate heap object)
  | ref -|--   +----+----+----+----+
  +------+  \
  | ref -|-  \-> +----+----+----+----+
  +------+ \     |  0 |  0 |  0 |  0 |   row 1  (separate heap object)
            \    +----+----+----+----+
             \
              \> +----+----+----+----+
                 |  0 |  0 |  0 |  0 |   row 2  (separate heap object)
                 +----+----+----+----+

   That's 4 heap objects total: 1 outer + 3 rows.
```

Two practical consequences:

**(a) Jagged arrays are legal.** Rows can have different lengths:
```java
int[][] triangle = new int[3][];
triangle[0] = new int[1];   // [ _ ]
triangle[1] = new int[2];   // [ _ | _ ]
triangle[2] = new int[3];   // [ _ | _ | _ ]
```
This is exactly how you build Pascal's Triangle, and it saves memory in DP problems with triangular state spaces.

**(b) Row-major traversal is much faster than column-major.**
```java
// FAST - walks each row's contiguous memory in order
for (int i = 0; i < rows; i++)
    for (int j = 0; j < cols; j++)
        sum += grid[i][j];

// SLOW - jumps between different heap objects on every step
for (int j = 0; j < cols; j++)
    for (int i = 0; i < rows; i++)
        sum += grid[i][j];
```
Same complexity — O(rows × cols) both ways. But the first can be several times faster in wall-clock time due to cache behaviour. **Mentioning this in an interview marks you as someone who has thought about performance, not just Big O.**

## 2.4 Visual Explanation — the three core operations

### Access — O(1)

```
   arr[2]?
        |
        v  compute base + 2*4, read. Done. One step, always.
   +----+----+----+----+----+
   | 10 | 20 | 30 | 40 | 50 |
   +----+----+----+----+----+
     0    1    2    3    4
```

### Insert at index 1 — O(n)

```
Goal: insert 15 at index 1 in [10, 20, 30, 40, _] (size=4, capacity=5)

Step 1: Shift RIGHT, starting from the RIGHTMOST element.
        (Why rightmost first? Read on — this is the key insight.)

        i=3:  copy arr[3] -> arr[4]
        +----+----+----+----+----+
        | 10 | 20 | 30 | 40 | 40 |
        +----+----+----+----+----+
                              ^ copied

        i=2:  copy arr[2] -> arr[3]
        +----+----+----+----+----+
        | 10 | 20 | 30 | 30 | 40 |
        +----+----+----+----+----+
                         ^ copied

        i=1:  copy arr[1] -> arr[2]
        +----+----+----+----+----+
        | 10 | 20 | 20 | 30 | 40 |
        +----+----+----+----+----+
                    ^ copied      <- index 1 is now safe to overwrite

Step 2: write the new value
        +----+----+----+----+----+
        | 10 | 15 | 20 | 30 | 40 |
        +----+----+----+----+----+
               ^ inserted, size = 5
```

**Why right-to-left?** If you shifted left-to-right you would overwrite values before copying them:

```
   WRONG (left to right):
   arr[2] = arr[1]  ->  [10, 20, 20, 40]   <- 30 is GONE, destroyed
   arr[3] = arr[2]  ->  [10, 20, 20, 20]   <- catastrophe
```

This is the classic "shift direction" bug. The rule generalises:

> **When shifting right (making room), iterate right-to-left. When shifting left (closing a gap), iterate left-to-right.**
>
> Always copy *away from* the direction you're moving into.

### Delete at index 1 — O(n)

```
Delete arr[1] from [10, 20, 30, 40, 50]

Shift LEFT, starting from the LEFT (index 1 onwards):

   i=1: arr[1] = arr[2]  ->  [10, 30, 30, 40, 50]
   i=2: arr[2] = arr[3]  ->  [10, 30, 40, 40, 50]
   i=3: arr[3] = arr[4]  ->  [10, 30, 40, 50, 50]
                                              ^ stale duplicate

   size-- -> 4. Logically the array is [10, 30, 40, 50].
   The stale 50 at index 4 is beyond size, so it's invisible.
```

**For object arrays, you must null the trailing slot:**
```java
arr[--size] = null;   // else the array keeps a strong reference -> memory leak
```
This is a real bug class. `java.util.ArrayList.remove()` does exactly this — go read the JDK source, it's four lines and instructive.

## 2.5 Java Implementation — a production-quality dynamic array

We'll build our own `ArrayList` from scratch. Nothing teaches arrays like implementing the thing that wraps them.

```java
package com.dsa.arrays;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * A growable array of ints, built from first principles.
 * Uses int[] rather than Integer[] to avoid boxing overhead.
 */
public final class IntDynamicArray implements Iterable<Integer> {

    private static final int DEFAULT_CAPACITY = 10;
    private static final int MAX_CAPACITY = Integer.MAX_VALUE - 8;

    private int[] data;
    private int size;

    public IntDynamicArray() {
        this(DEFAULT_CAPACITY);
    }

    public IntDynamicArray(int initialCapacity) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("capacity must be >= 0: " + initialCapacity);
        }
        this.data = new int[initialCapacity];
        this.size = 0;
    }

    // ---------- O(1) operations ----------

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int get(int index) {
        checkIndex(index);
        return data[index];
    }

    public int set(int index, int value) {
        checkIndex(index);
        int old = data[index];
        data[index] = value;
        return old;
    }

    // ---------- amortized O(1) ----------

    public void add(int value) {
        ensureCapacity(size + 1);
        data[size++] = value;
    }

    // ---------- O(n) operations ----------

    public void add(int index, int value) {
        if (index < 0 || index > size) {                 // note: index == size is legal
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
        ensureCapacity(size + 1);
        System.arraycopy(data, index, data, index + 1, size - index);
        data[index] = value;
        size++;
    }

    public int removeAt(int index) {
        checkIndex(index);
        int removed = data[index];
        int elementsAfter = size - index - 1;
        if (elementsAfter > 0) {
            System.arraycopy(data, index + 1, data, index, elementsAfter);
        }
        size--;
        return removed;
    }

    public int indexOf(int value) {
        for (int i = 0; i < size; i++) {
            if (data[i] == value) return i;
        }
        return -1;
    }

    public boolean contains(int value) {
        return indexOf(value) >= 0;
    }

    // ---------- internals ----------

    private void ensureCapacity(int required) {
        if (required <= data.length) return;
        int oldCap = data.length;
        int newCap = oldCap + (oldCap >> 1);            // 1.5x growth
        if (newCap < required) newCap = required;       // handles oldCap 0 and 1
        if (newCap > MAX_CAPACITY) {
            if (required > MAX_CAPACITY) throw new OutOfMemoryError("array too large");
            newCap = MAX_CAPACITY;
        }
        data = Arrays.copyOf(data, newCap);
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
    }

    public int[] toArray() {
        return Arrays.copyOf(data, size);
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<>() {
            private int cursor = 0;
            @Override public boolean hasNext() { return cursor < size; }
            @Override public Integer next() {
                if (cursor >= size) throw new NoSuchElementException();
                return data[cursor++];
            }
        };
    }

    @Override
    public String toString() {
        if (size == 0) return "[]";
        StringBuilder sb = new StringBuilder(size * 4);
        sb.append('[');
        for (int i = 0; i < size; i++) {
            sb.append(data[i]);
            if (i < size - 1) sb.append(", ");
        }
        return sb.append(']').toString();
    }
}
```

## 2.6 Line-by-Line Code Explanation

Now I explain the choices, because *why* is the part you'll be asked about.

**`private static final int DEFAULT_CAPACITY = 10;`**
`static` → one copy for the whole class, not per instance. `final` → compile-time constant, so the JIT inlines the literal 10 with zero runtime cost. Ten is what the JDK uses; it's an empirical compromise between wasting memory on tiny lists and resizing immediately.

**`private static final int MAX_CAPACITY = Integer.MAX_VALUE - 8;`**
Why minus 8? Because the array **object header** takes bytes too, and some JVMs reserve a few words. Requesting exactly `Integer.MAX_VALUE` elements can throw `OutOfMemoryError: Requested array size exceeds VM limit`. The JDK uses this exact constant. Reproducing it signals you've read the JDK source.

**`private int[] data;`**
The backing store. `int[]`, not `Integer[]` — deliberately. `Integer[]` would mean every element is a separate heap object with a 16-byte header for 4 bytes of payload (a 5× memory blowup) plus a pointer dereference per access. For a numeric collection that's indefensible.

**`private int size;`**
The crucial invariant: **`size` is the number of live elements; `data.length` is the allocated room.** These are different numbers and confusing them is the #1 source of bugs in this class. Slots `[size, data.length)` are allocated but logically empty.

```
   data.length = 10  (capacity)
   size = 4          (live elements)

   +----+----+----+----+----+----+----+----+----+----+
   | 10 | 20 | 30 | 40 |  0 |  0 |  0 |  0 |  0 |  0 |
   +----+----+----+----+----+----+----+----+----+----+
   <---- live (size) --->|<------- allocated but dead ------>
```

**`public IntDynamicArray() { this(DEFAULT_CAPACITY); }`**
Constructor chaining via `this(...)`. One place initialises fields → no duplicated logic, no divergence between constructors.

**`if (initialCapacity < 0) throw new IllegalArgumentException(...)`**
**Fail fast.** A negative capacity is a programming error; surfacing it at the point of the mistake with the offending value in the message saves hours of debugging. Notice the message *includes the bad value*. Always include the value.

**`public int get(int index) { checkIndex(index); return data[index]; }`**
Two lines, both O(1). `checkIndex` guards against `index >= size` — because `data[7]` might be a legal *array* access (capacity 10) while being an illegal *list* access (size 4). Without our check the caller would silently read a stale 0. **The class must enforce its own invariant, not lean on the JVM's array bounds check**, because the two boundaries are in different places.

**`public void add(int value) { ensureCapacity(size + 1); data[size++] = value; }`**
`data[size++] = value` is the classic idiom. Post-increment: use the current `size` as the write index, *then* increment. Equivalent to `data[size] = value; size = size + 1;`. Amortized O(1) per §1.4.

**`if (index < 0 || index > size)` in `add(int, int)`**
Note `> size`, not `>= size`. Inserting *at* `size` means appending, which is legal. Compare with `checkIndex`, which uses `>= size` because reading at `size` is not legal. **These two boundary conditions are genuinely different and this is the exact spot where beginners write a bug.** Say it out loud: "for insertion, index == size is valid; for access, it is not."

**`System.arraycopy(data, index, data, index + 1, size - index);`**
The most important line in the file. Signature: `arraycopy(src, srcPos, dest, destPos, length)`. Here src and dest are the *same array* — a self-overlapping copy.

```
   size = 4, insert at index = 1, so we move (4 - 1) = 3 elements

   Before:  [ 10 | 20 | 30 | 40 | __ ]
                    |    |    |
                    +----+----+---> shifted one slot right
   After :  [ 10 | 20 | 20 | 30 | 40 ]
                    ^ about to be overwritten with the new value
```

`System.arraycopy` is a JVM **intrinsic** — the JIT replaces it with an optimised `memmove`, often using SIMD vector instructions. It is dramatically faster than a hand-written loop and, critically, **it handles overlapping ranges correctly** (it internally picks the right copy direction, solving the §2.4 problem for you). Still O(n), but with a tiny constant. In interviews, writing the manual loop shows you understand the mechanism; writing `arraycopy` shows you know the platform. Ideally, write `arraycopy` and *explain* the manual loop.

**`ensureCapacity`, line by line — this is the heart of the class:**

```java
if (required <= data.length) return;     // fast path: 99% of adds exit here
```
A single comparison in the common case. This is why `add` is amortized O(1): almost every call does one compare and one write.

```java
int newCap = oldCap + (oldCap >> 1);     // oldCap * 1.5
```
`oldCap >> 1` is `oldCap / 2` via bit shift. Why 1.5× and not 2×?
- **Time:** any multiplicative factor gives amortized O(1) (§1.4). Both work.
- **Memory:** 2× can waste up to 50% of allocated space; 1.5× wastes at most 33%.
- **Allocator reuse:** with 2× growth, the sum of all previously freed blocks (`n/2 + n/4 + ... < n`) is *always smaller* than the next request, so freed memory can never be reused for the new array. With 1.5×, freed blocks eventually do add up to enough. This is a real, documented reason Facebook's `folly::fbvector` and the JDK both chose 1.5×.

```java
if (newCap < required) newCap = required;
```
Guards `oldCap == 0` (where `0 + 0 = 0`, an infinite loop) and `oldCap == 1` (where `1 + 0 = 1`, no growth). Also handles bulk-add requests that jump past 1.5×. **This line is easy to omit and produces an infinite loop when you do.**

```java
data = Arrays.copyOf(data, newCap);
```
Allocates a new array of `newCap`, copies the old contents in (via `arraycopy` internally), zero-fills the tail, and reassigns `data`. The old array is now unreachable → **eligible for garbage collection**. Note the transient memory spike: for a moment both arrays are live, so growing a 1 GB list momentarily needs 2.5 GB. That's a real production consideration.

**`public int[] toArray() { return Arrays.copyOf(data, size); }`**
Returns a **defensive copy**, trimmed to `size`. Returning `data` directly would (a) leak the internal array so callers could corrupt our state, and (b) expose the dead slots past `size`. Encapsulation is not decoration; here it prevents an entire bug class.

**The anonymous `Iterator<>` with a diamond**
Java 9+ allows `new Iterator<>() { ... }` on anonymous classes — the type is inferred. The inner class captures `IntDynamicArray.this` implicitly, so it reads the live `size` and `data` fields. That's what makes `for (int x : myArray)` work. (A production version would track a `modCount` and throw `ConcurrentModificationException` on structural modification during iteration — exactly what `ArrayList` does.)

**`new StringBuilder(size * 4)` in `toString`**
Pre-sizing the builder to a good estimate avoids internal resizes. And using `StringBuilder` at all rather than `+=` avoids the O(n²) trap of §1.5 Example H.

## 2.7 Complexity Analysis

| Operation | Time | Why |
|---|---|---|
| `get(i)` / `set(i, v)` | **O(1)** | Address arithmetic: `base + i × 4`. No scanning. |
| `add(v)` (append) | **Amortized O(1)** | Usually one write. Occasionally an O(n) copy, but geometric growth means total copy work over n adds is < 3n (§1.4). |
| `add(i, v)` | **O(n)** | Must shift `size - i` elements right. Worst case i=0 → n moves. |
| `removeAt(i)` | **O(n)** | Must shift `size - i - 1` elements left. Worst case i=0 → n-1 moves. |
| `removeAt(size-1)` | **O(1)** | `elementsAfter == 0`, so `arraycopy` is skipped entirely. |
| `indexOf(v)` / `contains(v)` | **O(n)** | Unsorted data offers no shortcut — must inspect every element. |
| Space | **O(n)** | Between n and 1.5n slots. |

**The one-sentence summary to say in interviews:** *"Arrays give O(1) random access and O(1) amortized append, at the cost of O(n) middle insertion and O(n) worst-case memory copying on growth."*

## 2.8 Common Mistakes

**1. `<=` in the loop condition**
```java
for (int i = 0; i <= arr.length; i++)   // ArrayIndexOutOfBoundsException
```
Length 5 → valid indices 0..4. Use `<`. Burn this in.

**2. `arr.length()` vs `arr.length`**
Arrays: `arr.length` (field, no parens). Strings: `s.length()` (method). Collections: `list.size()`. Three different spellings for the same idea — a genuine Java wart. Memorise it.

**3. Shifting in the wrong direction** — §2.4. Destroys data silently, which is worse than crashing.

**4. Confusing `size` with `capacity`** — the invariant from §2.6. Iterating to `data.length` instead of `size` exposes dead zeros.

**5. `Arrays.asList` on a primitive array**
```java
int[] a = {1, 2, 3};
List<int[]> wrong = Arrays.asList(a);   // a List with ONE element: the array itself!
```
Generics don't accept primitives, so `int[]` is treated as a single object. Fix: `Arrays.stream(a).boxed().toList()`.

**6. Assuming `Arrays.asList` is mutable**
```java
List<String> l = Arrays.asList("a", "b");
l.add("c");    // UnsupportedOperationException
```
It's a fixed-size **view** over the array. `l.set(0, "z")` works; `add`/`remove` don't. Use `new ArrayList<>(Arrays.asList(...))` for a real list.

**7. Shallow copy of a 2D array**
```java
int[][] copy = original.clone();          // copies the OUTER array of references only
copy[0][0] = 99;                          // MUTATES original[0][0] too!
```
The rows are shared. For a deep copy:
```java
int[][] deep = new int[original.length][];
for (int i = 0; i < original.length; i++) {
    deep[i] = original[i].clone();
}
```
This bug is a favourite in DP and grid interview questions.

**8. `==` on arrays**
```java
int[] a = {1,2,3}, b = {1,2,3};
a == b               // false  (different objects)
a.equals(b)          // false  (Object.equals -> identity!)
Arrays.equals(a, b)  // true   <- the right answer
Arrays.deepEquals(x, y)  // for 2D+
```

## 2.9 Interview Perspective

Arrays are the most-tested topic in existence, because everything reduces to them. Interviewers use array problems to probe four specific things:

**(a) Do you handle edge cases without being asked?** `null` array, length 0, length 1, all-identical elements, all-negative values, integer overflow. **Say them out loud before coding.** "Let me confirm: can the array be null or empty? Can values be negative? Could the sum overflow int?" Three questions, and you've already outperformed most candidates.

**(b) Can you get to O(1) extra space?** Half of array problems have an in-place solution and interviewers wait for you to find it. If you used a `HashMap`, the follow-up will be "now do it with O(1) space."

**(c) Do you know the standard toolkit?** Given an array problem, run through this checklist mentally:
```
  Sorted?          -> binary search, two pointers
  Contiguous range? -> sliding window
  Range sums?      -> prefix sum
  Need extremes?   -> heap
  Need counts?     -> HashMap / frequency array
  Need previous
  greater/smaller? -> monotonic stack
  Values bounded
  by n?            -> index-as-hash (cyclic sort, negative marking)
```
That checklist covers roughly 80% of array interview questions. Practise running it in 15 seconds.

**(d) The "values are 1..n" superpower.** If an array of length `n` contains values in the range `1..n`, you can use **the array itself as a hash table** — because there's a natural bijection between values and indices. This unlocks O(1)-space solutions to "find the missing number", "find the duplicate", "first missing positive". We'll use it in the Hard problem below. Recognising this pattern is worth memorising as a single rule:

> **Values in range 1..n + O(1) space required → index-as-hash. Either sort by placing value v at index v-1, or mark visited by negating.**

## 2.10 Practice Problems

### Easy — Remove Duplicates from Sorted Array
Given a **sorted** `int[] nums`, remove duplicates **in place** so each element appears once. Return the new length. Elements beyond the returned length don't matter. O(1) extra space.
```
Input:  [0,0,1,1,1,2,2,3,3,4]
Output: 5, nums begins [0,1,2,3,4,...]
```

### Medium — Rotate Array by k
Rotate `int[] nums` right by `k` steps, **in place**, O(1) extra space.
```
Input:  [1,2,3,4,5,6,7], k = 3
Output: [5,6,7,1,2,3,4]
```

### Hard — First Missing Positive
Given an unsorted `int[] nums`, find the smallest **positive** integer not present. Must be **O(n) time and O(1) extra space.**
```
[1,2,0]        -> 3
[3,4,-1,1]     -> 2
[7,8,9,11,12]  -> 1
```

## 2.11 Solution Walkthrough

### Easy — Remove Duplicates

**The insight.** Maintain **two pointers with different jobs.** This is the "slow/fast" or "read/write" pattern and it appears everywhere.

- `write` — the index where the next unique element belongs. Everything left of it is finished and correct.
- `read` — scans forward, looking for something new.

Because the array is sorted, duplicates are adjacent. So "is this new?" reduces to "is it different from the last thing I wrote?" — a single comparison, no set needed.

```java
public int removeDuplicates(int[] nums) {
    if (nums == null || nums.length == 0) return 0;

    int write = 1;                                  // nums[0] is always unique
    for (int read = 1; read < nums.length; read++) {
        if (nums[read] != nums[write - 1]) {        // found something new
            nums[write] = nums[read];
            write++;
        }
    }
    return write;
}
```

**Dry run on `[0,0,1,1,2]`.** Trace this with your finger.

```
Initial:  [0, 0, 1, 1, 2]    write=1
           w
           r(next)

read=1: nums[1]=0, nums[write-1]=nums[0]=0.  0 == 0  -> duplicate, SKIP
        [0, 0, 1, 1, 2]      write=1  (unchanged)
            ^r

read=2: nums[2]=1, nums[0]=0.  1 != 0  -> NEW
        write nums[1] = 1, write -> 2
        [0, 1, 1, 1, 2]      write=2
            ^ overwritten     ^r
        (finished region: [0,1])

read=3: nums[3]=1, nums[write-1]=nums[1]=1.  1 == 1 -> duplicate, SKIP
        [0, 1, 1, 1, 2]      write=2
               ^r

read=4: nums[4]=2, nums[1]=1.  2 != 1 -> NEW
        write nums[2] = 2, write -> 3
        [0, 1, 2, 1, 2]      write=3
               ^                  ^r
        (finished region: [0,1,2])

Loop ends. Return 3. First 3 elements are [0,1,2]. Correct.
```

**Why `nums[write - 1]` and not `nums[read - 1]`?** Because `nums[read - 1]` may have been overwritten by our own writes. `nums[write - 1]` is always the last element we *committed*, which is exactly the correct comparison target. Getting this wrong is the standard bug here — and it only shows up on inputs with 3+ consecutive duplicates, so it passes naive testing.

**Complexity:** O(n) time (single pass, each element examined once), **O(1) space** (two ints). The `write` pointer never overtakes `read`, so we never clobber unread data — that's the safety proof of this pattern.

### Medium — Rotate Array by k

**The naive approaches and why they fail:**
- Rotate one step, k times → O(n·k). With n = 10⁵ and k = 10⁵ that's 10¹⁰. Dead.
- Copy into a new array at `(i + k) % n` → O(n) time but O(n) space. Violates the constraint.

**The elegant answer: three reversals.** Watch this — it's genuinely beautiful.

```
Original:                [1, 2, 3, 4, 5, 6, 7]   k = 3

Step 1 - reverse WHOLE array:
                         [7, 6, 5, 4, 3, 2, 1]

   Now the last 3 elements are at the front — correct group, wrong internal order.
   And the first 4 are at the back — also correct group, wrong internal order.

Step 2 - reverse first k = 3:
                         [5, 6, 7, 4, 3, 2, 1]
                          ^^^^^^^ fixed

Step 3 - reverse remaining n - k = 4:
                         [5, 6, 7, 1, 2, 3, 4]
                                   ^^^^^^^^^^ fixed

   Answer. Three linear passes, zero extra space.
```

**Why does this work?** Reversing the whole array puts both blocks in the right *place* but internally backwards. Reversing each block individually un-backwards them. In algebraic terms: for blocks A and B, `reverse(reverse(A) + reverse(B))` — read right to left — equals `B + A`. Rotation *is* block swapping, and reversal is how you swap blocks without extra memory.

```java
public void rotate(int[] nums, int k) {
    if (nums == null || nums.length <= 1) return;
    int n = nums.length;
    k = k % n;                          // k=10, n=7 -> k=3. Essential.
    if (k == 0) return;

    reverse(nums, 0, n - 1);            // whole
    reverse(nums, 0, k - 1);            // first k
    reverse(nums, k, n - 1);            // rest
}

private void reverse(int[] a, int lo, int hi) {
    while (lo < hi) {
        int tmp = a[lo];
        a[lo] = a[hi];
        a[hi] = tmp;
        lo++;
        hi--;
    }
}
```

**Line notes:**

`k = k % n;` — **non-negotiable.** Rotating by n is the identity, so only `k mod n` matters. Without this, `k = 10, n = 7` makes `reverse(nums, 0, 9)` read out of bounds. This single line is the most common failure in this problem.

`if (k == 0) return;` — after the modulo, `k` may be 0, and `reverse(nums, 0, -1)` would be a no-op anyway (since `0 < -1` is false), but returning early is clearer and documents the intent.

`while (lo < hi)` — strictly less-than. When `lo == hi` (odd-length middle element) there's nothing to swap; `<=` would swap the element with itself, which is harmless but wasteful and signals fuzzy thinking.

**Complexity:** three reversals each touching at most n elements → O(n) time. Each element is moved exactly twice total. **O(1) space** — one `tmp` int. 

**Interview note:** if asked for an alternative, the cyclic-replacement method also achieves O(n)/O(1) using GCD cycle counting. Mention it exists but that reversal is preferred because it's far harder to get wrong. Choosing the more robust of two equally optimal algorithms is a senior signal.

### Hard — First Missing Positive

**Start by bounding the answer** — this is the reasoning step interviewers want to see.

Array has `n` elements. The answer is a positive integer. In the best case for "large answers", the array is exactly `[1, 2, 3, ..., n]` and the answer is `n + 1`. There is no way to force the answer higher, because you'd need all of 1..n+1 present, which needs n+1 slots.

> **Therefore the answer is always in the range `[1, n+1]`.**

That's the whole problem. Values outside `1..n` (negatives, zeros, huge numbers) are **irrelevant noise**. We only need to know, for each `v` in `1..n`, whether `v` is present.

Normally you'd use a boolean array of size n+1 — but that's O(n) space. So: **use the array itself as the hash table** (the §2.9 superpower). Put value `v` at index `v - 1`:

```
   Desired state:  value 1 -> index 0
                   value 2 -> index 1
                   value v -> index v-1
```

Then one final scan: the first index `i` where `nums[i] != i + 1` tells us `i + 1` is missing.

```java
public int firstMissingPositive(int[] nums) {
    if (nums == null || nums.length == 0) return 1;
    int n = nums.length;

    // Phase 1: place each value v in [1, n] at index v-1
    for (int i = 0; i < n; i++) {
        while (nums[i] > 0 && nums[i] <= n && nums[nums[i] - 1] != nums[i]) {
            int target = nums[i] - 1;
            int tmp = nums[target];
            nums[target] = nums[i];
            nums[i] = tmp;
        }
    }

    // Phase 2: find the first index whose value is wrong
    for (int i = 0; i < n; i++) {
        if (nums[i] != i + 1) return i + 1;
    }
    return n + 1;                          // array was exactly [1..n]
}
```

**Dry run on `[3, 4, -1, 1]`,** n = 4. Follow closely — the `while` is the tricky part.

```
Start: [3, 4, -1, 1]

i=0: nums[0]=3. In [1,4]? yes. Target index = 3-1 = 2. nums[2] = -1.
     Is nums[2] != nums[0]?  -1 != 3  -> yes, swap needed.
     Swap positions 0 and 2:
     [-1, 4, 3, 1]
      ^^      ^^  3 has reached its home (index 2). Correct.

     while re-checks nums[0], which is now -1.
     -1 > 0? NO -> while exits.

i=1: nums[1]=4. In [1,4]? yes. Target = 4-1 = 3. nums[3] = 1.
     1 != 4 -> swap positions 1 and 3:
     [-1, 1, 3, 4]
         ^^     ^^  4 is home (index 3). Correct.

     while re-checks nums[1], now 1.
     1 in [1,4]? yes. Target = 0. nums[0] = -1. -1 != 1 -> swap 1 and 0:
     [1, -1, 3, 4]
      ^^ ^^^  1 is home (index 0). Correct.

     while re-checks nums[1], now -1. Not > 0 -> exit.

i=2: nums[2]=3. Target = 2. nums[2] == nums[2] -> already home -> exit immediately.
i=3: nums[3]=4. Target = 3. Already home -> exit.

Phase 1 result: [1, -1, 3, 4]

Phase 2:
  i=0: nums[0]=1, want 1. OK.
  i=1: nums[1]=-1, want 2. MISMATCH -> return 2.

Answer: 2. Correct.
```

**The three critical details:**

**1. Why `while` and not `if`?** After a swap, index `i` holds a *brand new* value that might itself belong elsewhere. In the dry run, `i=1` needed two swaps in a row. An `if` would place only one value per iteration and silently miss elements.

**2. Why the condition `nums[nums[i] - 1] != nums[i]` and not `nums[nums[i]-1] != nums[i]` expressed as "target is empty"?** Two reasons, both essential:
- It's the **duplicate guard**. Given `[1, 1]`: at i=1, `nums[1]=1`, target index 0 already holds 1. Since `nums[0] == nums[1]`, we skip. Without this check we'd swap 1 with 1 forever → **infinite loop**. This is *the* bug in this problem.
- It's also the "already correct" check, letting us skip work.

**3. Why is this O(n) when there's a loop inside a loop?** This is the question that separates a correct answer from a *convincing* answer. Use an **amortized argument** (§1.4):

> Every swap places at least one value into its permanently correct home. Once a value is home, it is never moved again. There are only `n` positions, so **across the entire run, at most `n` swaps can ever occur.** The outer loop contributes n iterations, and the inner `while` contributes at most n swaps *in total across all i* — not n per i. Total work: O(n) + O(n) = **O(n)**.

Say that out loud in an interview and you have demonstrated that you can reason about amortized complexity in a non-obvious setting, which is exactly what Module 1 was preparing you for.

**Complexity:** **O(n) time, O(1) space.** Two passes plus at most n swaps.

**The generalisable takeaway.** Whenever you see *"O(1) space"* + *"values relate to indices"*, reach for index-as-hash. Its two forms:
- **Cyclic sort** (used here) — physically move `v` to index `v-1`.
- **Negative marking** — visit index `|v|-1` and negate it as a "seen" flag. Non-destructive to magnitudes, and works when you must preserve values.

Both give O(1) space by storing bookkeeping inside the input.

---
---
