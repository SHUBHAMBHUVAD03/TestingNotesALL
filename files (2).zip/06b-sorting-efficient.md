*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 6 — Sorting (continued)

*Covers merge, quick, heap, counting and radix sort, the Java Collections angle, the Ω(n log n) lower bound proof, and the graded problems. Read `06a-sorting-quadratic.md` first.*

---

## 6.6 Merge Sort

### Intuition

**Two sorted lists can be merged into one sorted list in a single linear pass.**

That's the entire insight. If you believe it, merge sort writes itself: split the array in half, sort each half (by magic — the recursive leap of faith from Module 4), then merge.

Why is merging linear? Because the smallest remaining element overall must be at the front of one of the two lists. So you only ever compare the two front elements:

```
   Left:  [1, 4, 9]        Right: [2, 3, 8]
           ^                       ^
   Compare 1 vs 2 -> take 1. The smallest of everything MUST be one of these two.
   
   Left:  [4, 9]           Right: [2, 3, 8]      output: [1]
   Compare 4 vs 2 -> take 2.
   
   Left:  [4, 9]           Right: [3, 8]         output: [1, 2]
   Compare 4 vs 3 -> take 3.
   ... and so on. Each comparison outputs exactly one element. -> O(n).
```

Merge sort is the cleanest example of **divide and conquer**, and — critically — it is the sort with a **guaranteed** O(n log n). No adversarial input can slow it down. That guarantee is why it's used for external sorting (files too large for RAM), for linked lists, and inside TimSort.

### Visual Explanation — the full recursion tree on `[38, 27, 43, 3, 9, 82, 10]`

**Phase 1 — DIVIDE (going down). No comparisons happen here; we just split.**

```
                    [38, 27, 43, 3, 9, 82, 10]
                              |
                 +------------+------------+
                 |                         |
          [38, 27, 43, 3]            [9, 82, 10]
                 |                         |
          +------+------+            +-----+-----+
          |             |            |           |
      [38, 27]      [43, 3]        [9, 82]      [10]
          |             |            |            
      +---+---+     +---+---+    +---+---+       
      |       |     |       |    |       |       
    [38]    [27]  [43]     [3]  [9]    [82]     

   Depth = log2(7) rounded up = 3 levels of splitting.
   Bottom: 7 single-element arrays. A single element is sorted by definition.
```

**Phase 2 — CONQUER (coming back up). All the work happens here.**

```
LEVEL 3 -> LEVEL 2:  merge pairs of singletons

   merge [38], [27]:  compare 38 vs 27 -> 27, then 38   -->  [27, 38]
   merge [43], [3] :  compare 43 vs 3  -> 3,  then 43   -->  [3, 43]
   merge [9], [82] :  compare 9 vs 82  -> 9,  then 82   -->  [9, 82]
   [10] stays [10]

   State:  [27, 38]   [3, 43]   [9, 82]   [10]


LEVEL 2 -> LEVEL 1:  merge pairs of 2-element arrays

   merge [27, 38] and [3, 43]:
       L=[27,38] R=[3,43]  out=[]
       27 vs 3   -> take 3      out=[3]
       27 vs 43  -> take 27     out=[3,27]
       38 vs 43  -> take 38     out=[3,27,38]
       L exhausted -> drain R   out=[3,27,38,43]

   merge [9, 82] and [10]:
       9 vs 10   -> take 9      out=[9]
       82 vs 10  -> take 10     out=[9,10]
       R exhausted -> drain L   out=[9,10,82]

   State:  [3, 27, 38, 43]   [9, 10, 82]


LEVEL 1 -> LEVEL 0:  the final merge

   L = [3, 27, 38, 43]     R = [9, 10, 82]     out = []

   i     j
   3 vs  9   -> 3  smaller  -> out=[3]                        i->1
   27 vs 9   -> 9  smaller  -> out=[3,9]                      j->1
   27 vs 10  -> 10 smaller  -> out=[3,9,10]                   j->2
   27 vs 82  -> 27 smaller  -> out=[3,9,10,27]                i->2
   38 vs 82  -> 38 smaller  -> out=[3,9,10,27,38]             i->3
   43 vs 82  -> 43 smaller  -> out=[3,9,10,27,38,43]          i->4 (L exhausted)
   drain R   -> 82          -> out=[3,9,10,27,38,43,82]

FINAL:  [3, 9, 10, 27, 38, 43, 82]   ✓
```

**Now look at the work per level — this is the complexity proof:**

```
   Level 0:  merge 7 elements total          -> 7 operations
   Level 1:  merge 4 + 3 = 7 elements        -> 7 operations
   Level 2:  merge 2+2+2+1 = 7 elements      -> 7 operations
   Level 3:  (base cases, no work)

   EVERY level touches every element exactly once  ->  O(n) per level
   Number of levels = log₂ n
   Total = O(n log n)      <- and this is unconditional
```

That's the whole proof, and it's the same recursion-tree argument from Module 1, Hard Problem 1.

### Java Implementation

```java
/** Top-down merge sort. Guaranteed O(n log n), stable, O(n) extra space. */
public static void mergeSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int[] buffer = new int[arr.length];        // ONE buffer, allocated ONCE
    mergeSort(arr, buffer, 0, arr.length - 1);
}

private static void mergeSort(int[] arr, int[] buffer, int lo, int hi) {
    if (lo >= hi) return;                      // base case: 0 or 1 element

    // Hybrid optimisation: insertion sort is faster on small ranges
    if (hi - lo + 1 <= 16) {
        insertionSort(arr, lo, hi);
        return;
    }

    int mid = lo + (hi - lo) / 2;              // overflow-safe
    mergeSort(arr, buffer, lo, mid);            // sort left half
    mergeSort(arr, buffer, mid + 1, hi);        // sort right half

    if (arr[mid] <= arr[mid + 1]) return;      // already ordered -> skip the merge
    merge(arr, buffer, lo, mid, hi);
}

private static void merge(int[] arr, int[] buffer, int lo, int mid, int hi) {
    // Copy the range we're about to overwrite into the buffer
    System.arraycopy(arr, lo, buffer, lo, hi - lo + 1);

    int i = lo;          // cursor into the left half of the BUFFER
    int j = mid + 1;     // cursor into the right half of the BUFFER
    int k = lo;          // write cursor into the ORIGINAL array

    while (i <= mid && j <= hi) {
        if (buffer[i] <= buffer[j]) {          // <= PRESERVES STABILITY
            arr[k++] = buffer[i++];
        } else {
            arr[k++] = buffer[j++];
        }
    }
    while (i <= mid) arr[k++] = buffer[i++];   // drain leftovers from the left
    // No need to drain the right: those elements are already in place in arr.
}
```

### Line-by-Line

**`int[] buffer = new int[arr.length];` — allocated ONCE, outside the recursion.**
This is the most important engineering decision in the file. The naive implementation allocates two new arrays inside every `merge` call:
```java
int[] left = new int[n1];  int[] right = new int[n2];   // BAD: allocates at every node
```
There are O(n) nodes in the recursion tree, so that's O(n) allocations — enormous GC pressure. One shared buffer, reused at every level, gives the same O(n) space with **one** allocation. **Mentioning this optimisation unprompted is a strong senior signal.**

**`if (lo >= hi) return;`** — base case. `lo == hi` means one element (sorted). `lo > hi` means empty. `>=` covers both.

**`if (hi - lo + 1 <= 16) { insertionSort(arr, lo, hi); return; }`**
The hybrid cut-off. Below ~16 elements, insertion sort's tiny constants beat recursion overhead. This typically gives a **10–25% real-world speedup** and is exactly what production sorts do (§6.5). Note it doesn't change the asymptotic complexity — the bottom `log 16` levels of the tree are simply replaced by one insertion sort each.

**`int mid = lo + (hi - lo) / 2;`** — the overflow-safe form from Module 5. In an array of 2 billion elements, `lo + hi` would overflow.

**`if (arr[mid] <= arr[mid + 1]) return;`**
A beautiful, cheap adaptivity check. If the largest element of the sorted left half is `<=` the smallest of the sorted right half, then concatenating them is *already* sorted — the merge would just copy everything back unchanged. One comparison saves an O(n) pass. **On already-sorted input this makes merge sort O(n log n) with almost no data movement**, and on real-world partially-sorted data it's a significant win. This is one of TimSort's core ideas in miniature.

**`System.arraycopy(arr, lo, buffer, lo, hi - lo + 1);`**
Note we copy into the buffer at **the same indices** (`lo` → `lo`), not starting at 0. That means `i` and `j` can index the buffer using the same coordinates as the original array — no index translation, no off-by-one arithmetic. **This is why the merge loop is so clean.** A JVM intrinsic, so it's as fast as `memcpy`.

**`if (buffer[i] <= buffer[j])` — the `<=` is the stability guarantee.**
When the two values are **equal**, we take from the **left** half. The left half holds elements that came earlier in the original array, so equal elements retain their original relative order. Change this to `<` and merge sort becomes **unstable**.

```
   Left half (earlier in original):  [ (5,a) ]
   Right half (later in original):   [ (5,b) ]

   With <= : take left first  ->  [(5,a), (5,b)]   original order preserved  ✅
   With <  : 5 < 5 is false   ->  take right first ->  [(5,b), (5,a)]        ❌
```

**This one character is the entire stability property of merge sort.** It is one of the most commonly asked "explain this line" questions in interviews. Know it.

**`while (i <= mid) arr[k++] = buffer[i++];` — and why there's no matching right drain.**
Subtle and elegant. If the left half is exhausted first, the remaining right-half elements are already sitting in `arr` at exactly the positions they need to be — we copied them there... actually, we never *moved* them; `arr[k..hi]` still holds the original right-half values in order, and `k` has advanced to exactly where they start. So draining the right is a no-op copy. Omitting it is correct and saves work.

Prove it to yourself: if `i > mid` (left exhausted), then the number of elements written so far is `(mid - lo + 1) + (j - mid - 1) = j - lo`, so `k = lo + (j - lo) = j`. Writing `arr[k] = buffer[j]` for the rest is writing each value back to its own position. Genuinely a no-op. **Explaining this in an interview is a real flex.**

### Complexity

- **Time: O(n log n) in all cases** — best, average, worst. `log n` levels × O(n) work per level. **No input can degrade it.** This unconditional guarantee is merge sort's defining virtue.
- **Space: O(n)** for the buffer, plus **O(log n)** for the recursion stack → **O(n)** overall. This is merge sort's defining weakness.
- **Stable: yes.** **In-place: no.**

**Recurrence:** `T(n) = 2T(n/2) + O(n)` → `Θ(n log n)` by the Master Theorem, or by the level-summing argument above (which is better to present).

### Interview Perspective

**When to choose merge sort:**
1. **Stability is required.** (Sorting objects by a secondary key.)
2. **You need a worst-case guarantee.** (Real-time systems, adversarial input, SLA guarantees.)
3. **Sorting a linked list.** Merge sort is *the* answer here — it needs no random access, and it can be done with **O(1) extra space** on a linked list by relinking pointers instead of copying. Quicksort on a linked list is awkward; heap sort is impossible without random access. **"How do you sort a linked list in O(n log n)?" → merge sort. Have this ready.**
4. **External sorting.** Data too large for RAM: sort chunks that fit in memory, write them to disk, then k-way merge the sorted files. Merge sort is inherently sequential-access, which is exactly what disks and tapes want.
5. **Counting inversions** and other divide-and-conquer counting problems (see the Hard problem in §6.13).

**The classic follow-up:** *"Merge sort is O(n log n) guaranteed and quicksort can be O(n²). Why does the JDK use quicksort for primitives?"*

Your answer: *"Three reasons. Quicksort is in-place, so no O(n) buffer. Its constant factor is smaller — partitioning is a tight sequential scan with excellent cache locality, while merging requires copying to and from a buffer. And with randomised or median-of-three pivot selection, the O(n²) case becomes astronomically unlikely. For objects, though, the JDK uses TimSort — because stability is required for `Comparator`-based sorting and object comparisons are expensive enough that TimSort's run-detection pays for itself."*

That answer covers memory, constants, cache, probability, and the primitive/object split. It is close to a complete answer to "tell me about sorting."

---

## 6.7 Quick Sort

### Intuition

**Pick a pivot. Put everything smaller on its left, everything larger on its right. The pivot is now in its FINAL position. Recurse on both sides.**

The contrast with merge sort is illuminating:
```
   MERGE SORT:  divide trivially (just split in half), 
                combine with effort (the merge does the work)

   QUICK SORT:  divide with effort (partitioning does the work),
                combine trivially (nothing to do — the pieces are already in place)
```

Quicksort front-loads the work. And that's why it needs no buffer: after partitioning, the left part, the pivot, and the right part are already in their correct **regions** of the same array. There is nothing to merge.

### Visual Explanation — Lomuto partition on `[10, 80, 30, 90, 40, 50, 70]`

We'll use the last element as pivot: **70**.

```
Array:   10  80  30  90  40  50  70
                                 ^^ pivot

The invariant we maintain:
   +------------------+------------------+-------+
   |  all <= pivot    |  all > pivot     | unseen|  pivot
   +------------------+------------------+-------+
   lo               i    i+1           j-1        hi
   
   i = boundary of the "<= pivot" region (starts at lo-1)
   j = scanning cursor

--- j=0, arr[0]=10.  10 <= 70?  YES ---
    i moves from -1 to 0. Swap arr[0] with arr[0] (self, no-op).
    10 | 80  30  90  40  50 | 70
    ^^ small region = {10}

--- j=1, arr[1]=80.  80 <= 70?  NO  ---
    Do nothing. 80 stays in the "large" region.
    10 | 80 | 30  90  40  50 | 70
       small  large={80}

--- j=2, arr[2]=30.  30 <= 70?  YES ---
    i moves 0 -> 1. Swap arr[1] and arr[2]:  80 <-> 30
    10  30 | 80 | 90  40  50 | 70
    ^^^^^^  small={10,30}, large={80}

--- j=3, arr[3]=90.  90 <= 70?  NO ---
    Do nothing.
    10  30 | 80  90 | 40  50 | 70
            large={80,90}

--- j=4, arr[4]=40.  40 <= 70?  YES ---
    i moves 1 -> 2. Swap arr[2] and arr[4]:  80 <-> 40
    10  30  40 | 90  80 | 50 | 70
    ^^^^^^^^^^  small={10,30,40}
                Note: 80 and 90 are still both in the "large" region,
                just internally reordered. That's fine — and it's WHY
                quicksort is unstable.

--- j=5, arr[5]=50.  50 <= 70?  YES ---
    i moves 2 -> 3. Swap arr[3] and arr[5]:  90 <-> 50
    10  30  40  50 | 80  90 | 70
    ^^^^^^^^^^^^^^  small={10,30,40,50}

--- j reaches hi. FINAL STEP: place the pivot ---
    Swap arr[i+1] with arr[hi]:  arr[4]=80 <-> arr[6]=70
    
    10  30  40  50  70  90  80
                    ^^ PIVOT IS HOME. Index 4. FOREVER.
    
    <---- all <= 70 ----> ^  <-- all > 70 -->

Return 4 (the pivot's final index).

Now recurse on [10,30,40,50] (indices 0..3) and [90,80] (indices 5..6).
Nothing needs to be merged afterward.
```

**Read that final line again:** `70` is at index 4 and will *never move again*. That's the guarantee partitioning gives you, and it's what eliminates the combine step.

### Java Implementation

```java
import java.util.Random;

private static final Random RNG = new Random();

/** Quicksort with randomised pivot, tail-call elimination, and hybrid cutoff. */
public static void quickSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    quickSort(arr, 0, arr.length - 1);
}

private static void quickSort(int[] arr, int lo, int hi) {
    while (lo < hi) {                                  // loop instead of tail recursion
        if (hi - lo + 1 <= 16) {                       // hybrid cutoff
            insertionSort(arr, lo, hi);
            return;
        }

        int pivotIdx = lo + RNG.nextInt(hi - lo + 1);   // RANDOM pivot
        swap(arr, pivotIdx, hi);                        // move it to the end
        int p = partition(arr, lo, hi);

        // Recurse into the SMALLER side; loop on the larger.
        // This bounds stack depth at O(log n) even in the worst case.
        if (p - lo < hi - p) {
            quickSort(arr, lo, p - 1);
            lo = p + 1;                                 // tail-call eliminated
        } else {
            quickSort(arr, p + 1, hi);
            hi = p - 1;
        }
    }
}

/** Lomuto partition. Returns the pivot's final index. */
private static int partition(int[] arr, int lo, int hi) {
    int pivot = arr[hi];
    int i = lo - 1;                                     // boundary of the "<= pivot" region

    for (int j = lo; j < hi; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i + 1, hi);                               // pivot into its final slot
    return i + 1;
}

private static void swap(int[] a, int x, int y) {
    int t = a[x]; a[x] = a[y]; a[y] = t;
}
```

### Line-by-Line

**`int pivotIdx = lo + RNG.nextInt(hi - lo + 1);` — randomisation is not optional.**

With a fixed pivot (say, always the last element), the worst case is triggered by **sorted input** — the most common real-world case:
```
   Sorted [1,2,3,4,5], pivot = last = 5.
   Partition: everything is <= 5, so the pivot lands at the end.
   Left subarray = [1,2,3,4]  (size n-1),  Right = empty.
   
   Recursion: n -> n-1 -> n-2 -> ... -> 1
   Depth = n.  Work per level = n.  ->  O(n²) time AND O(n) stack (StackOverflowError!)
```

**A fixed-pivot quicksort is quadratic on sorted data.** That is a catastrophic, easily-triggered failure — and in a networked service it's a denial-of-service vector (an attacker sends pre-sorted input). Randomisation makes the probability of a bad split independent of the input, so no adversary can force it. **Expected** time becomes O(n log n) with the worst case occurring with probability ~1/n!.

Alternatives: **median-of-three** (take the median of first, middle, last) is cheaper than randomisation and handles sorted input well, but is still defeatable by a crafted input. The JDK's dual-pivot quicksort uses a sophisticated median-of-five-ish scheme plus a check that falls back to merge sort on detected structure.

**`swap(arr, pivotIdx, hi);`** — after choosing a random pivot, move it to the end so `partition` can use its standard "pivot is at `hi`" convention. Cleaner than parameterising the partition.

**`int i = lo - 1;`** — the boundary starts *before* the array, meaning "the `<= pivot` region is currently empty." This is why the first qualifying element triggers `i++` to `lo` and then a self-swap. Slightly odd-looking, but it makes the invariant uniform with no special cases.

**`if (arr[j] <= pivot)`** — `<=`, not `<`. Why? Consider an array of all-identical elements `[5,5,5,5,5]` with pivot 5:
```
   With <= : every element qualifies, i advances each time,
             pivot lands in the MIDDLE. Balanced split. O(n log n).  ✅
   With <  : NO element qualifies, i stays at lo-1,
             pivot lands at position lo. Left empty, right = n-1.
             -> O(n²) on all-duplicate input.                        ❌
```
**One character, and duplicate-heavy input goes from O(n log n) to O(n²).** Arrays with many duplicates are extremely common in practice (sorting by status, category, boolean flags). This is why serious implementations use **three-way partitioning** (Dutch National Flag) which groups `< pivot`, `== pivot`, `> pivot` and achieves O(n) on all-duplicate input.

**`swap(arr, i + 1, hi);`** — the final placement. After the loop, `arr[lo..i]` are all `<= pivot` and `arr[i+1..hi-1]` are all `> pivot`. Position `i+1` holds the first "large" element, which is exactly where the pivot belongs. Swapping sends that large element to the end (still in the "large" region — correct) and brings the pivot to `i+1`.

**`while (lo < hi)` with `lo = p + 1` — tail-call elimination by hand.**
The natural code is:
```java
quickSort(arr, lo, p - 1);
quickSort(arr, p + 1, hi);     // this call is in TAIL POSITION
```
Java doesn't optimise tail calls (Module 4), so the second call costs a frame. Rewriting it as a loop assignment (`lo = p + 1; continue;`) eliminates one of the two recursive branches. Combined with **always recursing into the smaller half**, this bounds the stack at:

```
   Each recursive call handles a range of size <= half the current range.
   So depth <= log2(n).   ->  O(log n) space, GUARANTEED,
                              even if partitions are maximally unbalanced.
```

**This is the fix for quicksort's `StackOverflowError` risk.** Without it, worst-case partitioning gives O(n) stack depth and a crash on large arrays. With it, quicksort's *space* is O(log n) unconditionally, even when its *time* degrades. Explaining this optimisation is one of the strongest things you can say about quicksort in an interview — very few candidates know it.

### Complexity

**Best/average — balanced partitions:**
```
   T(n) = 2T(n/2) + O(n)  ->  O(n log n)
   
   Even a 90/10 split is fine:
   T(n) = T(0.9n) + T(0.1n) + O(n)
   Depth = log_{10/9}(n) ≈ 6.6 log₂ n   -> still O(n log n), just a bigger constant.
```
**Quicksort is remarkably robust to unbalanced splits.** You need *consistently* terrible splits to hit O(n²).

**Worst — maximally unbalanced:**
```
   T(n) = T(n-1) + O(n)  ->  n + (n-1) + ... + 1 = O(n²)
```
Probability with a random pivot: vanishingly small (you'd need to pick the min or max at every level).

**Space: O(log n)** with the smaller-side-first optimisation. O(n) without it.

**Stable: no** — long-distance swaps in `partition` reorder equal elements (see the `j=4` step in the dry run, where 80 and 90 swapped places).

### Interview Perspective

**The single most important thing to be able to say:** *"Quicksort is O(n log n) on average but O(n²) in the worst case. I mitigate that with a randomised pivot, which makes the bad case independent of the input, and I recurse into the smaller partition first to bound stack depth at O(log n)."*

**"Why is quicksort used more than merge sort despite the worse guarantee?"**
1. **In-place** — O(log n) space vs O(n).
2. **Better constants** — partitioning is one sequential pass with excellent cache locality; merging requires reading and writing a separate buffer.
3. **Randomisation** makes the worst case practically impossible.
4. And where the guarantee genuinely matters, hybrids like **introsort** (used by C++'s `std::sort`) detect excessive recursion depth and switch to heap sort — getting quicksort's speed with merge sort's guarantee.

**Quickselect — the essential relative.** If you only need the kth smallest element, you don't need to sort both halves:
```java
// After partitioning, if p == k you're done. Otherwise recurse into ONE side only.
   T(n) = T(n/2) + O(n)  ->  O(n) EXPECTED, not O(n log n)
```
This solves "find the kth largest element" and "find the median" in **expected O(n)**. It's a top-10 interview question and it falls straight out of the partition function you just wrote. **Know that quickselect exists and that it's O(n) expected, O(n²) worst.**

---

## 6.8 Heap Sort

### Intuition

**Selection sort's problem is that finding the maximum costs O(n). A heap finds the maximum in O(1) and removes it in O(log n).**

That's the whole idea. Heap sort is selection sort with a better tool:
```
   Selection sort: n passes × O(n) to find the max  ->  O(n²)
   Heap sort:      n passes × O(log n) to extract the max  ->  O(n log n)
```

A **max-heap** is a complete binary tree where every parent is `>=` its children. The maximum is always at the root. Stored in an array with no pointers:

```
   For index i (0-based):
       parent(i)      = (i - 1) / 2
       leftChild(i)   = 2i + 1
       rightChild(i)  = 2i + 2

   Tree:              Array:
        50            [50, 30, 40, 10, 20, 35]
       /  \             0   1   2   3   4   5
     30    40
    /  \   /
  10   20 35

   Check: parent of index 4 (value 20) = (4-1)/2 = 1 -> value 30.  ✓ 30 >= 20
          children of index 1 = indices 3, 4 -> values 10, 20.     ✓ 30 >= both
```

We'll cover heaps properly in Module 12. Here we just use them to sort.

### Visual Explanation — heap sort on `[4, 10, 3, 5, 1]`

**Phase 1 — BUILD the max-heap (bottom-up heapify).**

```
Initial array: [4, 10, 3, 5, 1]

Tree view:        4
                /   \
              10     3
             /  \
            5    1

Start from the last NON-LEAF node: index (n/2 - 1) = (5/2 - 1) = 1.
(Leaves are already valid 1-element heaps — no need to touch indices 2,3,4.)

--- heapify(index 1, value 10) ---
   children: index 3 (5), index 4 (1).  Largest of {10, 5, 1} is 10 = itself.
   No swap needed.
        4
      /   \
    10     3
   /  \
  5    1

--- heapify(index 0, value 4) ---
   children: index 1 (10), index 2 (3).  Largest of {4, 10, 3} is 10 at index 1.
   SWAP index 0 and 1:
       10
      /   \
     4     3
    /  \
   5    1
   Array: [10, 4, 3, 5, 1]
   
   Now RECURSE down: 4 moved to index 1. Is the subtree at index 1 still valid?
   heapify(index 1, value 4): children are 5 (idx 3) and 1 (idx 4).
   Largest of {4, 5, 1} is 5 at index 3. SWAP index 1 and 3:
       10
      /   \
     5     3
    /  \
   4    1
   Array: [10, 5, 3, 4, 1]
   
   Recurse to index 3: it's a leaf. Done.

MAX-HEAP BUILT:  [10, 5, 3, 4, 1]
       10
      /   \
     5     3
    /  \
   4    1
   Verify: 10>=5,3 ✓   5>=4,1 ✓   Valid max-heap.
```

**Phase 2 — SORT by repeatedly extracting the max.**

```
--- Extraction 1 ---
   Swap root (index 0) with the LAST heap element (index 4):
   [1, 5, 3, 4 | 10]
                 ^^^ 10 is HOME (largest, goes at the end). Heap size shrinks to 4.
   
   Heap is now broken at the root (1 is too small). heapify(0) on size 4:
       1                     5
      / \        ->         / \
     5   3                 4   3
    /                     /
   4                     1
   heapify(0): children 5,3 -> largest 5 at idx 1. Swap 0,1: [5,1,3,4|10]
   heapify(1): child 4 at idx 3 -> largest 4. Swap 1,3:      [5,4,3,1|10]
   
   Array: [5, 4, 3, 1 | 10]

--- Extraction 2 ---
   Swap index 0 with index 3:  [1, 4, 3 | 5, 10]
   heapify(0) on size 3: children 4 (idx1), 3 (idx2). Largest 4. Swap:
                                [4, 1, 3 | 5, 10]
   heapify(1): idx 1 has no children within size 3? left = 3, which is >= size. Done.
   
   Array: [4, 1, 3 | 5, 10]

--- Extraction 3 ---
   Swap index 0 with index 2:  [3, 1 | 4, 5, 10]
   heapify(0) on size 2: child 1 (idx 1). 3 >= 1, no swap.
   
   Array: [3, 1 | 4, 5, 10]

--- Extraction 4 ---
   Swap index 0 with index 1:  [1 | 3, 4, 5, 10]
   heapify(0) on size 1: nothing to do.

--- Heap size is 1: done ---

FINAL:  [1, 3, 4, 5, 10]   ✓
```

**Notice the array's dual life:**
```
   +---------------------------+------------------------+
   |     ACTIVE MAX-HEAP       |   SORTED (final)       |
   +---------------------------+------------------------+
   0                   size-1  size                   n-1
   
   The boundary marches LEFT. One array, two data structures. Zero extra space.
```

### Java Implementation

```java
/** Heap sort. Guaranteed O(n log n) with O(1) space. Not stable. */
public static void heapSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    // PHASE 1: build a max-heap, bottom-up. O(n) — see the analysis below.
    for (int i = n / 2 - 1; i >= 0; i--) {
        siftDown(arr, i, n);
    }

    // PHASE 2: repeatedly move the max to the end and restore the heap.
    for (int end = n - 1; end > 0; end--) {
        swap(arr, 0, end);           // max goes to its final position
        siftDown(arr, 0, end);       // restore heap property on the shrunken heap
    }
}

/**
 * Restores the max-heap property at index i, for a heap occupying arr[0, size).
 * Moves arr[i] down until both children are <= it.
 */
private static void siftDown(int[] arr, int i, int size) {
    while (true) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int largest = i;

        if (left  < size && arr[left]  > arr[largest]) largest = left;
        if (right < size && arr[right] > arr[largest]) largest = right;

        if (largest == i) return;    // heap property satisfied -> stop
        swap(arr, i, largest);
        i = largest;                 // follow the element down (iterative, no stack)
    }
}
```

### Line-by-Line

**`for (int i = n / 2 - 1; i >= 0; i--)`**
`n/2 - 1` is the index of the **last non-leaf node**. Everything from `n/2` to `n-1` is a leaf, and a single node is trivially a valid heap. Starting there skips half the array for free.

We iterate **downward** (`i--`), which is essential: `siftDown(i)` assumes both subtrees of `i` are already valid heaps. Processing from the bottom up guarantees that. Going top-down would be wrong.

**Why is Phase 1 O(n) and not O(n log n)?** This is a genuinely surprising result and a favourite interview question.

Naive reasoning: n/2 calls to `siftDown`, each O(log n) → O(n log n). **But that's a loose bound**, because most nodes are near the *bottom*, where `siftDown` has almost nowhere to go:

```
   Level (from bottom)   #nodes      max sift distance    work
   -------------------   ---------   ------------------   --------
   0 (leaves)            n/2         0                    0
   1                     n/4         1                    n/4
   2                     n/8         2                    2n/8
   3                     n/16        3                    3n/16
   ...
   log n (root)          1           log n                log n

   Total = Σ (h × n/2^(h+1)) for h = 0..log n
         = n × Σ (h / 2^(h+1))
         = n × (1/2 · Σ h/2^h)
   
   And Σ h/2^h converges to 2.   ->  Total = n × 1 = O(n)
```

**Half the nodes do zero work. Only one node does log n work.** The sum converges, giving **O(n)** for building a heap. Say this in an interview — it's precise, non-obvious, and demonstrates real analytical skill.

**`for (int end = n - 1; end > 0; end--)`**
`end` is both "the last index of the current heap" and "where the extracted max should go." Stop at `end > 0`: when only one element remains, it's necessarily the minimum and already in place.

**`swap(arr, 0, end);`**
The root holds the maximum of the remaining heap. Swapping it to `end` places it in its final sorted position and simultaneously brings a (likely small) leaf value to the root — which is why we must immediately restore the heap.

**`siftDown(arr, 0, end);` — note `end`, not `end + 1`.**
`size = end` means the heap now occupies `arr[0..end-1]`, **excluding** the element we just placed at `end`. If you pass `end + 1`, the sifting will see the already-finalised maximum, pull it back into the heap, and the sort silently produces garbage. **This off-by-one is the classic heap sort bug.** Trace it once with `n = 3` to burn it in.

**`if (left < size && arr[left] > arr[largest])`**
The bounds check `left < size` comes **first** — short-circuit `&&` prevents reading past the heap boundary into the sorted region. Same pattern as insertion sort's `j >= 0 &&`.

**`i = largest;` inside a `while (true)` — iteration, not recursion.**
`siftDown` is naturally tail-recursive, so converting it to a loop is mechanical (Module 4, §4.5) and eliminates O(log n) stack frames. **This is what gives heap sort its O(1) space.** If you write `siftDown` recursively, heap sort becomes O(log n) space — still good, but you've given away its unique selling point.

### Complexity

- **Time: O(n log n) in ALL cases.** Phase 1 is O(n); Phase 2 is n extractions × O(log n) sift = O(n log n). Total O(n log n). **No input degrades it** — same guarantee as merge sort.
- **Space: O(1).** The only algorithm here with *both* a guaranteed O(n log n) and O(1) space.
- **Stable: no.** The root-to-end swap moves elements arbitrarily far.
- **Adaptive: no.** Sorted input costs the same.

### Interview Perspective

**The question you must be able to answer:** *"Heap sort has a better worst case than quicksort and better space than merge sort. Why isn't it the default?"*

*"Cache locality. Quicksort's partition is a linear scan — the CPU prefetcher loads the next cache line and it's exactly what you need. Heap sort's `siftDown` jumps from index `i` to `2i+1`, which for large arrays is a different cache line, then a different page. Every level of every sift is potentially a cache miss. So despite identical Big O, heap sort typically runs 2–3× slower than quicksort in wall-clock time on large arrays. Big O measures comparisons, not memory latency."*

That answer demonstrates that you understand the gap between theoretical and practical performance, which is exactly what distinguishes senior engineers.

**Where heap sort genuinely shines:**
1. **Memory-constrained environments** — embedded systems where an O(n) buffer is unaffordable.
2. **As the fallback in introsort** — C++'s `std::sort` starts with quicksort and switches to heap sort if recursion depth exceeds `2 log n`, converting quicksort's O(n²) risk into a guaranteed O(n log n). **Best of both worlds; this is the design to describe if asked "how would you build a production sort?"**
3. **The heap itself** is far more useful than heap sort — `PriorityQueue`, top-k problems, Dijkstra, median maintenance. Module 12.

**The top-k insight:** for "find the k largest of n elements", don't sort. Build a **min-heap of size k** and stream through the data: **O(n log k)** time, **O(k)** space. For n = 10⁹ and k = 10, that's essentially O(n) with 10 elements of memory. Sorting would be O(n log n) and require all n in memory. This is one of the most practically useful algorithms in this entire course.

---

## 6.9 Counting Sort

### Intuition

**If you know the values are small integers, don't compare them at all — just count them.**

To sort exam scores from 0 to 100, you don't compare scores. You tally how many students got each score, then read the tally in order.

```
   Input:  [3, 1, 3, 0, 2, 1, 3]
   
   Tally:  value:  0  1  2  3
           count:  1  2  1  3
   
   Read out: 0 once, 1 twice, 2 once, 3 three times
   Output: [0, 1, 1, 2, 3, 3, 3]   ✓
   
   Zero comparisons were performed.
```

This **breaks the Ω(n log n) barrier** — legally, because the barrier applies only to comparison-based sorts (§6.12). We're not comparing; we're using values as array indices, which is a fundamentally more powerful operation.

### Visual Explanation on `[4, 2, 2, 8, 3, 3, 1]`, k = 9 (values 0..8)

```
--- STEP 1: count occurrences ---
   
   count[v] = how many times v appears
   
   index:  0  1  2  3  4  5  6  7  8
   count:  0  1  2  2  1  0  0  0  1
              ^  ^  ^  ^           ^
              |  |  |  |           +-- one 8
              |  |  |  +-- one 4
              |  |  +-- two 3s
              |  +-- two 2s
              +-- one 1

--- STEP 2: prefix-sum the counts ---

   Transform count[] into "how many elements are <= v"
   
   count[i] += count[i-1]  for i = 1..k-1
   
   before:  0  1  2  2  1  0  0  0  1
   after:   0  1  3  5  6  6  6  6  7
            ^  ^  ^  ^  ^           ^
            |  |  |  |  |           +-- 7 elements are <= 8 (all of them)
            |  |  |  |  +-- 6 elements are <= 4
            |  |  |  +-- 5 elements are <= 3
            |  |  +-- 3 elements are <= 2
            |  +-- 1 element is <= 1
            +-- 0 elements are <= 0

   INTERPRETATION: count[v] is now the index JUST PAST where the last v goes.
   So count[v] - 1 is where the last occurrence of v belongs.

--- STEP 3: place elements, iterating the INPUT BACKWARD ---

   Why backward? For STABILITY. See the explanation below.
   
   input:  [4, 2, 2, 8, 3, 3, 1]
                                ^ start here (i = 6)
   
   i=6, v=1:  count[1]=1  ->  place at index 1-1 = 0.  count[1] -> 0
              output: [_, 1, _, _, _, _, _]
              
   Wait — index 0? Let me redo with correct output indexing:
              output[0] = 1
              output: [1, _, _, _, _, _, _]
   
   i=5, v=3:  count[3]=5  ->  output[4] = 3.  count[3] -> 4
              output: [1, _, _, _, 3, _, _]
   
   i=4, v=3:  count[3]=4  ->  output[3] = 3.  count[3] -> 3
              output: [1, _, _, 3, 3, _, _]
   
   i=3, v=8:  count[8]=7  ->  output[6] = 8.  count[8] -> 6
              output: [1, _, _, 3, 3, _, 8]
   
   i=2, v=2:  count[2]=3  ->  output[2] = 2.  count[2] -> 2
              output: [1, _, 2, 3, 3, _, 8]
   
   i=1, v=2:  count[2]=2  ->  output[1] = 2.  count[2] -> 1
              output: [1, 2, 2, 3, 3, _, 8]
   
   i=0, v=4:  count[4]=6  ->  output[5] = 4.  count[4] -> 5
              output: [1, 2, 2, 3, 3, 4, 8]

FINAL:  [1, 2, 2, 3, 3, 4, 8]   ✓
```

**Why iterate the input backward?** This is the stability mechanism, and it's the part that gets asked about.

Each `count[v]` tells us the **last** available slot for value `v`. So we must fill slots from the back. If we walk the input backward, the *last* occurrence of `v` in the input gets the *last* slot, the second-to-last gets the second-to-last slot, and so on — **original relative order is preserved.**

```
   Input has two 2s: 2ᵃ at index 1, 2ᵇ at index 2.
   Slots available for value 2: indices 1 and 2.
   
   BACKWARD iteration: we meet 2ᵇ first -> gets index 2. Then 2ᵃ -> gets index 1.
   Output: [.., 2ᵃ, 2ᵇ, ..]   ORDER PRESERVED  ✅
   
   FORWARD iteration: we meet 2ᵃ first -> gets index 2. Then 2ᵇ -> gets index 1.
   Output: [.., 2ᵇ, 2ᵃ, ..]   ORDER REVERSED   ❌
```

**This matters enormously** because radix sort *requires* a stable subsort. Break counting sort's stability and radix sort breaks completely (§6.10).

### Java Implementation

```java
/**
 * Counting sort for non-negative ints. Stable. O(n + k) where k = max value + 1.
 * Only appropriate when k is O(n) — otherwise the count array dominates.
 */
public static void countingSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    int min = arr[0], max = arr[0];
    for (int v : arr) {                            // find the range in one pass
        if (v < min) min = v;
        if (v > max) max = v;
    }

    int range = max - min + 1;                     // offset by min: handles NEGATIVES
    if (range > 10L * arr.length + 1000) {
        // Range is huge relative to n; counting sort would waste memory.
        Arrays.sort(arr);
        return;
    }

    int[] count = new int[range];
    for (int v : arr) {
        count[v - min]++;                          // STEP 1: tally
    }
    for (int i = 1; i < range; i++) {
        count[i] += count[i - 1];                  // STEP 2: prefix sums
    }

    int[] output = new int[arr.length];
    for (int i = arr.length - 1; i >= 0; i--) {    // STEP 3: BACKWARD for stability
        int v = arr[i];
        output[--count[v - min]] = v;
    }

    System.arraycopy(output, 0, arr, 0, arr.length);
}
```

### Line-by-Line

**`int range = max - min + 1;` and `count[v - min]++`**
Offsetting by `min` is what lets counting sort handle **negative numbers**. Without it, `count[-5]` throws. With it, `-5` maps to index `-5 - min`. Most textbook implementations omit this and only work on non-negative input — including this generalisation is a nice touch.

Note the potential overflow: if `max = Integer.MAX_VALUE` and `min = Integer.MIN_VALUE`, then `max - min` overflows. A truly production-grade version would compute the range as a `long`.

**`if (range > 10L * arr.length + 1000)`**
The guard that makes this **safe to actually use**. Counting sort's fatal flaw: sorting `[1, 1000000000]` (n = 2) would allocate a billion-element array — 4 GB — to sort two numbers. **The complexity is O(n + k), and when k >> n the k dominates completely.** This check falls back to a comparison sort when the range is unreasonable. Volunteering this guard shows engineering judgment, not just algorithm knowledge.

**`for (int i = 1; i < range; i++) count[i] += count[i-1];`**
The prefix-sum transformation (this is Module 27 arriving again). It converts "how many equal `v`" into "how many `<= v`", which is exactly the *position* information we need. Note it starts at `i = 1` — `count[0]` needs no predecessor.

**`output[--count[v - min]] = v;`**
Dense but precise. Read it right to left:
1. `count[v - min]` = the number of elements `<= v` = one past the last slot for `v`.
2. `--` pre-decrements, giving the actual last available index **and** reserving it (so the next occurrence of `v` gets the slot before).
3. Write `v` there.

Pre-decrement (`--count[...]`) not post-decrement is essential. With `count[...]--` you'd write one slot too high and go out of bounds on the largest value.

**`for (int i = arr.length - 1; i >= 0; i--)`** — backward, for stability. Discussed above. **This is the line interviewers ask about.**

**`System.arraycopy(output, 0, arr, 0, arr.length);`** — counting sort is **not in-place**; it needs the `output` array. Copying back gives the caller an in-place-looking API. Total extra space: O(n + k).

### Complexity
- **Time: O(n + k)** — three O(n) passes plus one O(k) pass. **Linear when k = O(n).**
- **Space: O(n + k).**
- **Stable: yes** (with backward iteration).

### Interview Perspective

**The question that unlocks it:** *"Sort n integers where all values are between 0 and 100."* Or *"...where values are ages"*, *"...are ASCII characters"*, *"...are exam scores"*, *"...are years"*. Any bounded-range hint means **counting sort — O(n), beating the O(n log n) bound.**

**Always state the trade-off unprompted:** *"Counting sort gives O(n + k). It's a clear win when k is comparable to n — bounded ranges like ages or scores. But if the values are arbitrary 32-bit integers, k is 4 billion and the count array is unusable; I'd fall back to a comparison sort or use radix sort, which decomposes large values into small digit-sized pieces."*

**The most common real use** is as a subroutine: counting sort by a single digit is the engine inside radix sort, and counting sort by character is the engine inside bucket-based string sorting.

---

## 6.10 Radix Sort

### Intuition

**Counting sort is great when values are small. Radix sort makes values small by looking at one digit at a time.**

A 32-bit integer has a range of 4 billion (unusable for counting sort). But each *decimal digit* has a range of 10. Each *byte* has a range of 256. So: **sort by the last digit, then the next, then the next.** After processing all digits, the array is fully sorted.

**And the magic requirement:** each digit-pass must be **stable**. That's the entire correctness argument. When we sort by the tens digit, elements with equal tens digits must retain the order established by the previous (ones-digit) pass. Stability is what carries earlier work forward.

```
   Think of it as: "sort by the least significant thing first,
                    and let stability preserve it while you sort by more significant things."
```

This is exactly how humans sorted punched cards mechanically in the 1890s — Hollerith's machines did LSD radix sort. It predates computers.

### Visual Explanation on `[170, 45, 75, 90, 802, 24, 2, 66]`

Max is 802, so 3 digits → 3 passes.

```
INITIAL:  170  45  75  90  802  24  2  66

=== PASS 1: sort by the ONES digit (place value 1) ===

   Extract digits:  170->0  45->5  75->5  90->0  802->2  24->4  2->2  66->6
   
   Buckets:
       0:  170, 90
       1:  (empty)
       2:  802, 2
       3:  (empty)
       4:  24
       5:  45, 75
       6:  66
       7,8,9: (empty)
   
   Read buckets in order:
   AFTER PASS 1:  170  90  802  2  24  45  75  66
                  ^^^  ^^  ordered by last digit: 0,0,2,2,4,5,5,6
   
   Note 170 before 90 (both end in 0) — that was their original relative order.
   Note 802 before 2 (both end in 2) — also original order. STABILITY AT WORK.

=== PASS 2: sort by the TENS digit (place value 10) ===

   Extract tens digits:  170->7  90->9  802->0  2->0  24->2  45->4  75->7  66->6
   
   Buckets:
       0:  802, 2
       1:  (empty)
       2:  24
       3:  (empty)
       4:  45
       5:  (empty)
       6:  66
       7:  170, 75
       8:  (empty)
       9:  90
   
   AFTER PASS 2:  802  2  24  45  66  170  75  90
                  ^^^^^^  tens digits: 0,0,2,4,6,7,7,9
   
   CRUCIAL: 170 and 75 both have tens digit 7. Pass 1 left 170 before 75
   (ones digits 0 and 5), and stability preserved that. So within tens-digit 7,
   they are correctly ordered by ones digit already.

=== PASS 3: sort by the HUNDREDS digit (place value 100) ===

   Extract hundreds:  802->8  2->0  24->0  45->0  66->0  170->1  75->0  90->0
   
   Buckets:
       0:  2, 24, 45, 66, 75, 90     <- all preserved in their pass-2 order!
       1:  170
       2..7: (empty)
       8:  802
   
   AFTER PASS 3:  2  24  45  66  75  90  170  802

FINAL:  [2, 24, 45, 66, 75, 90, 170, 802]   ✓  FULLY SORTED
```

**Now watch what happens WITHOUT stability.** Suppose pass 2's subsort scrambled equal keys:

```
   After pass 1:  170  90  802  2  24  45  75  66
   
   Pass 2 (UNSTABLE) puts bucket-7 as [75, 170] instead of [170, 75]:
   After pass 2:  802  2  24  45  66  75  170  90
   
   Pass 3: all of {2,24,45,66,75,90} have hundreds digit 0, and 
           an unstable sort might emit them in any order:
   Result: 45  2  75  24  90  66  170  802     ← COMPLETELY WRONG
```

**Radix sort's correctness rests entirely on the stability of its subsort.** This is *the* reason counting sort iterates backward (§6.9), and it's why "why must the subsort be stable?" is a standard interview question. Answer: *"because each pass must preserve the ordering established by all previous, less-significant passes. Without stability, earlier work is destroyed."*

### Java Implementation

```java
/**
 * LSD radix sort for non-negative ints, base 256 (one byte per pass).
 * O(d(n + k)) where d = 4 passes, k = 256.  Effectively O(n).
 */
public static void radixSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    final int BITS = 8;                    // 8 bits per pass
    final int BUCKETS = 1 << BITS;         // 256
    final int MASK = BUCKETS - 1;          // 0xFF
    final int PASSES = 4;                  // 32 bits / 8 = 4 passes

    int n = arr.length;
    int[] buffer = new int[n];             // ONE buffer, reused
    int[] count = new int[BUCKETS];

    int[] src = arr, dst = buffer;

    for (int pass = 0; pass < PASSES; pass++) {
        int shift = pass * BITS;
        Arrays.fill(count, 0);             // reset the tally each pass

        // STEP 1: count occurrences of each byte value
        for (int i = 0; i < n; i++) {
            int bucket = (src[i] >>> shift) & MASK;
            count[bucket]++;
        }

        // Skip this pass entirely if all values share the same byte here
        if (count[(src[0] >>> shift) & MASK] == n) continue;

        // STEP 2: prefix sums -> starting index of each bucket
        int total = 0;
        for (int b = 0; b < BUCKETS; b++) {
            int c = count[b];
            count[b] = total;
            total += c;
        }

        // STEP 3: stable distribution, FORWARD (works with start-index counts)
        for (int i = 0; i < n; i++) {
            int bucket = (src[i] >>> shift) & MASK;
            dst[count[bucket]++] = src[i];
        }

        // STEP 4: swap the roles of src and dst — no copying needed
        int[] tmp = src; src = dst; dst = tmp;
    }

    // After 4 passes (even number), src == arr. If it weren't, copy back.
    if (src != arr) {
        System.arraycopy(src, 0, arr, 0, n);
    }
}
```

### Line-by-Line

**`final int BITS = 8; final int BUCKETS = 1 << BITS;`**
Base 256, not base 10. Why? Because `(x >>> shift) & 0xFF` extracts a byte with **two single-cycle bit operations**, whereas base 10 needs `(x / placeValue) % 10` — an integer division, which is 20–40× slower on most CPUs. And 4 passes (32/8) instead of 10 passes (for 10-digit ints). **Base 256 radix sort is roughly 5–10× faster than base-10 radix sort.** This choice is why radix sort is genuinely competitive with quicksort on large integer arrays.

Trade-off: a 256-entry count array instead of 10. Utterly negligible.

**`int bucket = (src[i] >>> shift) & MASK;`**
`>>>` is the **unsigned** right shift. Using `>>` (signed) would sign-extend negative numbers, corrupting the digit extraction. Then `& 0xFF` isolates the low 8 bits of the shifted value.

```
   value = 0x12345678, pass = 1, shift = 8
   value >>> 8  = 0x00123456
   & 0xFF       = 0x56          <- the second byte. Correct.
```

**Important caveat this implementation carries:** it treats the top byte as unsigned, so **negative numbers sort after positives** (because their sign bit makes the top byte ≥ 0x80). The standard fix is to flip the sign bit during the final pass: `bucket = ((src[i] >>> 24) ^ 0x80) & 0xFF`. Mention this limitation if asked — knowing where your implementation's boundaries are is more impressive than pretending it handles everything.

**`if (count[(src[0] >>> shift) & MASK] == n) continue;`**
If one bucket holds all `n` elements, this digit is identical across the whole array and the pass would be a pure copy. Skip it. For arrays of small values (the common case), the top two or three passes are skipped entirely — **turning 4 passes into 1 or 2.** A big practical win, and a nice thing to point out.

**STEP 2 computes STARTING indices, not "one past the end."**
```java
int c = count[b]; count[b] = total; total += c;
```
This is an **exclusive** prefix sum: after it, `count[b]` = the index where bucket `b` begins. That changes the distribution loop:
```
   Counting sort (§6.9): count[] = one-past-end  ->  iterate input BACKWARD, use --count[]
   Radix here:           count[] = start index   ->  iterate input FORWARD,  use count[]++
```
**Both are stable.** They're two encodings of the same idea. The forward version is more cache-friendly (sequential reads of `src`), which is why high-performance radix sorts use it. Understanding that *both* forms achieve stability — and why — means you actually understand the mechanism rather than having memorised one recipe.

**`int[] tmp = src; src = dst; dst = tmp;` — pointer swapping, not copying.**
After each pass the sorted-by-this-digit data lives in `dst`. Instead of copying it back to `arr` (an O(n) copy per pass), we just **swap which array we call "source."** Next pass reads from what was `dst`. This is **double buffering** and it eliminates 4 full array copies. With an even number of passes, `src` ends up back at `arr` — hence the final `if (src != arr)` guard for safety.

### Complexity

- **Time: O(d · (n + k))** where `d` = number of passes, `k` = bucket count.
  - Here `d = 4`, `k = 256`, both **constants** → **O(n)**.
  - More precisely: `4 × (n + 256)` ≈ `4n`. **Four linear passes.** Compare quicksort's `n log n` ≈ `n × 30` for n = 10⁹.
- **Space: O(n + k)** = one n-element buffer plus 256 counters.
- **Stable: yes** (essential, and by construction).
- **Not in-place.**

**Is radix sort actually faster than quicksort in practice?** For large arrays of primitive integers, **yes, often by 2–3×.** For small arrays, no (the constant overhead of 4 passes and buffer allocation dominates). For objects with expensive comparators, radix isn't applicable at all. This is why the JDK doesn't use it — a general-purpose library sort must handle `Comparator`, but a specialised numeric sort absolutely should consider radix.

### Interview Perspective

**When to bring it up:** *"sort 10 million 32-bit integers"*, *"sort IP addresses"*, *"sort fixed-length strings"*, *"sort dates"*, *"can you beat O(n log n)?"*

**How to present it:** *"Since these are fixed-width integers, I can use radix sort — LSD, base 256, four passes with a stable counting sort per pass. That's O(4n) — linear — and it beats the comparison lower bound because I'm not comparing, I'm bucketing by digit. The requirements are that keys are fixed-width and decomposable into small digits, and that each pass is stable, since stability is what preserves the ordering from less-significant digits."*

That paragraph contains: the algorithm, the base choice, the complexity, why the lower bound doesn't apply, and the correctness condition. It's about as complete as an interview answer gets.

**MSD vs LSD:** we did LSD (least significant digit first), which processes all elements every pass and needs no recursion. **MSD** (most significant first) partitions into buckets and recurses — it's how you radix-sort **variable-length strings**, and it can terminate early once buckets have one element. Knowing both exist, and that MSD is the string variant, is worth a sentence.

---

## 6.11 The Java Collections angle (asked constantly)

```
   Arrays.sort(int[] a)            ->  Dual-Pivot Quicksort
                                       In-place, O(n log n) expected, O(n²) worst (mitigated),
                                       NOT stable (irrelevant for primitives).
                                       Falls back to insertion sort below 47 elements.
                                       Falls back to merge sort if it detects
                                       structure that would hurt quicksort.

   Arrays.sort(Object[] a)         ->  TimSort
   Collections.sort(List)          ->  (delegates to Arrays.sort)
   List.sort(Comparator)
                                       STABLE, guaranteed O(n log n), O(n) space.
                                       Adaptive: finds existing "runs" and merges them.
                                       O(n) on already-sorted input.

   Arrays.parallelSort(...)        ->  Parallel merge sort via ForkJoinPool.
                                       Worth it above ~8192 elements.

   Arrays.sort(a, fromIndex, toIndex)  ->  sorts a subrange.
```

**Why the split?** *"Primitives have no identity beyond their value, so stability is meaningless — the JDK can use the faster in-place quicksort. Objects are distinguishable, so `Comparator`-based sorting must be stable to support multi-key sorting, and object comparisons are expensive enough that TimSort's run-detection pays for itself."* That's the complete answer.

**TimSort in one paragraph** (worth knowing — it's the most-used sort on Earth, in both Java and Python):
1. Scan for **natural runs** — already-ascending or already-descending sequences. Reverse the descending ones.
2. Extend short runs to a minimum length (32–64) using **binary insertion sort**.
3. Push runs onto a stack and **merge** them, maintaining invariants that keep the merge tree balanced.
4. Use **galloping mode** during merges: if one run is consistently winning, binary-search ahead instead of comparing one at a time.

Result: **O(n) on sorted or reverse-sorted input, O(n log n) worst case, stable.** It's merge sort that exploits real-world data's tendency to be partially ordered.

**One gotcha worth knowing:** `Arrays.sort(Object[])` throws `IllegalArgumentException: Comparison method violates its general contract!` if your `Comparator` is inconsistent (e.g. not transitive, or `compare(a,b)` and `compare(b,a)` disagree). TimSort *detects* broken comparators. A common cause is `return a.value - b.value` **overflowing** for large values — use `Integer.compare(a.value, b.value)` instead. **This is a real production bug and a great thing to mention.**

## 6.12 The Ω(n log n) lower bound — why comparison sorts can't do better

This proof gets asked at strong companies, and it's short.

Think of a sorting algorithm as a **decision tree**. Each internal node is a comparison ("is a[i] < a[j]?") with two branches. Each leaf is one possible output ordering.

```
                    a<b?
                   /     \
                yes       no
                /           \
            b<c?             a<c?
           /    \           /    \
      [a,b,c]  a<c?    [b,a,c]  b<c?
              /    \            /    \
        [a,c,b] [c,a,b]   [b,c,a] [c,b,a]
```

For `n` distinct elements there are **n!** possible orderings, so the tree needs **at least n! leaves**.

A binary tree of height `h` has at most `2^h` leaves. Therefore:
```
   2^h  >=  n!
   h    >=  log₂(n!)
```
By Stirling's approximation, `log₂(n!) ≈ n log₂ n − n log₂ e ≈ n log₂ n`.

```
   h  >=  Ω(n log n)
```

The height of the tree is the **worst-case number of comparisons**. So:

> **No comparison-based sort can do better than Ω(n log n) comparisons in the worst case.** Merge sort and heap sort achieve this bound, so they are **optimal** among comparison sorts.

**And why counting/radix escape it:** they never perform a comparison. Using a value as an **array index** is not a binary decision — it's a `k`-way branch in constant time, which sits outside this model entirely. That's the loophole, and it costs you the requirement that values be small integers.

## 6.13 Practice Problems

### Easy — Sort Colors (Dutch National Flag)
Given `int[] nums` containing only 0, 1, and 2, sort it **in place** in **one pass** with **O(1) space**. Do not use a library sort or counting sort's two passes.
```
[2,0,2,1,1,0] -> [0,0,1,1,2,2]
```

### Medium — Kth Largest Element in an Array
Find the kth largest element in an unsorted array. Aim for **average O(n)**.
```
[3,2,1,5,6,4], k = 2 -> 5
[3,2,3,1,2,4,5,5,6], k = 4 -> 4
```

### Hard — Count Inversions
Count the pairs `(i, j)` with `i < j` and `arr[i] > arr[j]`. This measures "how unsorted" an array is. Must be **O(n log n)**.
```
[2, 4, 1, 3, 5] -> 3     pairs: (2,1), (4,1), (4,3)
[5, 4, 3, 2, 1] -> 10    (fully reversed: n(n-1)/2)
```

## 6.14 Solution Walkthrough

### Easy — Sort Colors (Dutch National Flag)

**Why not counting sort?** It works (count 0s, 1s, 2s; overwrite) but takes **two passes**. The problem asks for one. And the one-pass solution teaches the **three-way partitioning** technique that fixes quicksort's duplicate problem (§6.7).

**The idea: three pointers carving the array into four regions.**

```
   +----------+----------+------------------+----------+
   |   = 0    |   = 1    |     UNKNOWN      |   = 2    |
   +----------+----------+------------------+----------+
   0        low-1  low        mid        high      n-1
                                       high+1

   INVARIANT (state this out loud — it IS the solution):
     nums[0 .. low-1]    are all 0
     nums[low .. mid-1]  are all 1
     nums[mid .. high]   are UNEXAMINED
     nums[high+1 .. n-1] are all 2

   Loop while mid <= high, shrinking the unknown region to nothing.
```

```java
public void sortColors(int[] nums) {
    if (nums == null || nums.length < 2) return;
    int low = 0, mid = 0, high = nums.length - 1;

    while (mid <= high) {
        if (nums[mid] == 0) {
            swap(nums, low, mid);
            low++;
            mid++;                 // safe to advance: we swapped in a known 1 (or self)
        } else if (nums[mid] == 1) {
            mid++;                 // already in the right region
        } else {                   // nums[mid] == 2
            swap(nums, mid, high);
            high--;
            // DO NOT advance mid — the value swapped in is UNEXAMINED
        }
    }
}
```

**Dry run on `[2, 0, 2, 1, 1, 0]`.**

```
Start: [2, 0, 2, 1, 1, 0]   low=0, mid=0, high=5

--- mid=0, nums[0]=2 ---
   Swap mid(0) and high(5):  [0, 0, 2, 1, 1, 2]
   high -> 4.  mid stays 0 (the 0 we just received is unexamined).
   [0, 0, 2, 1, 1 | 2]

--- mid=0, nums[0]=0 ---
   Swap low(0) and mid(0) — self swap, no-op.
   low -> 1, mid -> 1.
   [0 | 0, 2, 1, 1 | 2]

--- mid=1, nums[1]=0 ---
   Swap low(1) and mid(1) — self swap.
   low -> 2, mid -> 2.
   [0, 0 | 2, 1, 1 | 2]

--- mid=2, nums[2]=2 ---
   Swap mid(2) and high(4):  [0, 0, 1, 1, 2, 2]
   high -> 3.  mid stays 2.
   [0, 0 | 1, 1 | 2, 2]

--- mid=2, nums[2]=1 ---
   Just advance. mid -> 3.
   [0, 0 | 1 | 1 | 2, 2]

--- mid=3, nums[3]=1 ---
   Advance. mid -> 4.
   
--- mid=4 > high=3  ->  LOOP EXITS ---

FINAL: [0, 0, 1, 1, 2, 2]   ✓  ONE pass.
```

**The detail that is the entire problem: why does `mid` advance on 0 but NOT on 2?**

This is the question interviewers ask, and it's a beautiful piece of reasoning.

- **When `nums[mid] == 0`:** we swap with `nums[low]`. But what was at `low`? By the invariant, `low` is the start of the "= 1" region, so `nums[low]` is either a **1** or `low == mid` (self-swap). Either way, the value arriving at `mid` is **already examined and known**. Safe to advance.

- **When `nums[mid] == 2`:** we swap with `nums[high]`. By the invariant, `nums[high]` is in the **UNKNOWN** region. The value arriving at `mid` could be 0, 1, or 2 — **we have no idea.** We must examine it on the next iteration, so `mid` must **not** advance.

```
   Case 0:  swap with low  ->  receive a known 1  ->  advance mid  ✅
   Case 2:  swap with high ->  receive an UNKNOWN ->  do NOT advance  ✅
```

Advance `mid` in the 2-case and you skip an element, which can leave a 0 stranded in the middle. **Trace `[2, 2, 0]` by hand with the bug** and you'll watch the 0 get skipped over and stranded.

**Also: `while (mid <= high)`, not `<`.** When `mid == high` there is still **one** unexamined element. Using `<` leaves it unsorted. Same boundary logic as binary search Template A.

**Complexity:** **O(n) time** — each iteration either advances `mid` or decrements `high`, so the unknown region shrinks by one every step; at most n iterations. **O(1) space.** One pass, three pointers.

**Why this matters beyond the problem:** this *is* the three-way partition that makes quicksort O(n) on all-duplicate input. Replace "0/1/2" with "< pivot / == pivot / > pivot" and you have production-grade quicksort partitioning. **Say that connection out loud** — it shows you see the pattern rather than the puzzle.

### Medium — Kth Largest Element

**Four approaches. Present them in ascending order of quality — this progression *is* the interview.**

**1. Sort and index.** `Arrays.sort(nums); return nums[n - k];` → **O(n log n)** time, O(1) space. Two lines. **Say this first** — it's correct, and it establishes a baseline.

**2. Min-heap of size k.** Stream through the array, keeping only the k largest seen so far:
```java
PriorityQueue<Integer> heap = new PriorityQueue<>();   // min-heap by default
for (int v : nums) {
    heap.offer(v);
    if (heap.size() > k) heap.poll();                  // evict the smallest
}
return heap.peek();                                    // the kth largest
```
→ **O(n log k)** time, **O(k)** space. Better than sorting when `k << n`. **And it's the only viable approach if the data is a stream that doesn't fit in memory** — a follow-up you should volunteer.

**3. Quickselect.** → **O(n) expected**, O(1) space. The optimal answer.

**4. Median of medians.** → O(n) **worst case**, but with constants so large it's slower in practice. Mention it exists; don't implement it.

**Quickselect, the answer:**

```java
private static final Random RNG = new Random();

public int findKthLargest(int[] nums, int k) {
    // kth LARGEST == the element at index (n - k) in ascending order
    int targetIdx = nums.length - k;
    int lo = 0, hi = nums.length - 1;

    while (lo < hi) {
        int pivotIdx = lo + RNG.nextInt(hi - lo + 1);
        swap(nums, pivotIdx, hi);
        int p = partition(nums, lo, hi);         // same Lomuto partition as §6.7

        if (p == targetIdx) {
            return nums[p];                      // found it
        } else if (p < targetIdx) {
            lo = p + 1;                          // target is to the RIGHT
        } else {
            hi = p - 1;                          // target is to the LEFT
        }
    }
    return nums[lo];
}
```

**Dry run: `nums = [3,2,1,5,6,4]`, k = 2.**

```
n = 6, so targetIdx = 6 - 2 = 4.
(In ascending order [1,2,3,4,5,6], index 4 holds 5. And 5 IS the 2nd largest. ✓)

--- Iteration 1 ---
lo=0, hi=5. Suppose the random pivot lands on 4 (value 6). Swap to hi:
   [3, 2, 1, 5, 4, 6]      pivot = 6

   partition: every element <= 6, so i advances all the way to 4,
   then pivot swaps to index 5.
   [3, 2, 1, 5, 4, 6]   p = 5

   p=5 > targetIdx=4  ->  the answer is LEFT of index 5.  hi = 4.
   Search space: [0, 4] = [3, 2, 1, 5, 4]
   
   NOTE: we did NOT recurse into the right side at all. Half the work discarded.

--- Iteration 2 ---
lo=0, hi=4. Suppose the pivot is 4 (value 4, already at hi). pivot = 4.
   
   partition [3,2,1,5,4] with pivot 4:
     j=0: 3<=4 YES, i->0, swap(0,0)      [3,2,1,5,4]
     j=1: 2<=4 YES, i->1, swap(1,1)      [3,2,1,5,4]
     j=2: 1<=4 YES, i->2, swap(2,2)      [3,2,1,5,4]
     j=3: 5<=4 NO                        [3,2,1,5,4]
     final: swap(i+1=3, hi=4)            [3,2,1,4,5]
   p = 3

   p=3 < targetIdx=4  ->  answer is RIGHT.  lo = 4.
   Search space: [4, 4] — a single element.

--- lo == hi == 4  ->  loop exits.  return nums[4] = 5.  ✓
```

**Why quickselect is O(n) and not O(n log n)** — this derivation is the interview answer:

```
   QUICKSORT:    recurses into BOTH sides
                 T(n) = 2T(n/2) + O(n)  ->  O(n log n)
                 
   QUICKSELECT:  recurses into ONE side (the other cannot contain the answer)
                 T(n) = T(n/2) + O(n)
                      = n + n/2 + n/4 + n/8 + ...
                      = n × (1 + 1/2 + 1/4 + ...)
                      = n × 2
                      = O(n)
```

**A geometric series that converges to 2.** Discarding half the search space each time makes the *total* work linear, not linearithmic. That's the same convergence trick as amortized ArrayList growth (§1.4) — the pattern recurs constantly.

**`while (lo < hi)` instead of recursion** — quickselect only ever recurses into one side, so that call is in tail position and converts directly to a loop (Module 4, §4.5). Result: **O(1) space** instead of O(log n). Do this; it's strictly better and shows you recognised the tail call.

**`targetIdx = nums.length - k`** — the index conversion, and a classic off-by-one trap. Verify with a tiny case: `n=6, k=1` (largest) → `targetIdx = 5` = the last index in ascending order. ✓ `k=6` (smallest) → `targetIdx = 0`. ✓

**Complexity:** **O(n) expected, O(n²) worst** (mitigated by the random pivot, exactly as in quicksort). **O(1) space.**

**What to say when asked "which would you use in production?"** *"Quickselect for a one-shot query on an in-memory array — O(n) expected and in-place. But a size-k min-heap if the data arrives as a stream, or if I need the answer repeatedly as data changes, since the heap maintains the invariant incrementally in O(log k) per element."* Recognising that the *best* algorithm depends on the access pattern is exactly the judgment interviews are testing.

### Hard — Count Inversions

**Brute force:** two nested loops, count every out-of-order pair → O(n²). For n = 10⁵ that's 10¹⁰. Too slow.

**The insight: merge sort already finds every inversion — we just have to count them.**

Think about the merge step. We have two sorted halves, `L` and `R`. Every element of `L` came *before* every element of `R` in the original array. So if we ever take an element from `R` **before** exhausting `L`, that element is smaller than everything remaining in `L` — and each of those is an inversion.

```
   L = [3, 5, 9]        R = [1, 4, 8]
        i                    j
   
   Compare 3 vs 1.  R wins  ->  take 1.
   
   How many inversions did we just discover?
   1 is smaller than 3, 5, AND 9 — all remaining elements of L.
   And all of them come EARLIER in the original array.
   
   So we found (mid - i + 1) = 3 inversions in ONE step:
       (3,1), (5,1), (9,1)
   
   +--------------------------+
   |  L: [3, 5, 9]            |
   |       ^^^^^^^ all 3 are > 1 and all come before it  -> 3 inversions
   |  R: [1, ...]             |
   +--------------------------+
```

**One comparison reveals up to `n/2` inversions at once.** That's how we get from O(n²) to O(n log n).

```java
public long countInversions(int[] arr) {
    if (arr == null || arr.length < 2) return 0;
    int[] buffer = new int[arr.length];
    return sortAndCount(arr, buffer, 0, arr.length - 1);
}

private long sortAndCount(int[] arr, int[] buf, int lo, int hi) {
    if (lo >= hi) return 0;

    int mid = lo + (hi - lo) / 2;
    long count = sortAndCount(arr, buf, lo, mid)          // inversions fully inside left
               + sortAndCount(arr, buf, mid + 1, hi);     // inversions fully inside right
    count += mergeAndCount(arr, buf, lo, mid, hi);        // inversions ACROSS the halves
    return count;
}

private long mergeAndCount(int[] arr, int[] buf, int lo, int mid, int hi) {
    System.arraycopy(arr, lo, buf, lo, hi - lo + 1);

    long inversions = 0;
    int i = lo, j = mid + 1, k = lo;

    while (i <= mid && j <= hi) {
        if (buf[i] <= buf[j]) {
            arr[k++] = buf[i++];             // no inversion: left element is smaller
        } else {
            arr[k++] = buf[j++];
            inversions += (mid - i + 1);     // <-- THE ENTIRE ALGORITHM IS THIS LINE
        }
    }
    while (i <= mid) arr[k++] = buf[i++];
    while (j <= hi)  arr[k++] = buf[j++];
    return inversions;
}
```

**The decomposition to state out loud:** every inversion `(i, j)` falls into exactly one of three buckets —
1. both indices in the left half → counted by the left recursive call,
2. both in the right half → counted by the right recursive call,
3. `i` in the left, `j` in the right → counted during the merge.

Three mutually exclusive, collectively exhaustive cases. **That's the correctness proof, and it's the same divide-and-conquer decomposition you'd use for "count pairs with property P".**

**Dry run on `[2, 4, 1, 3, 5]`.** Expected answer: 3, from pairs (2,1), (4,1), (4,3).

```
Split: [2, 4]  and  [1, 3, 5]

=== LEFT: [2, 4] ===
   Split into [2] and [4].
   Merge: 2 <= 4, take 2 (no inversion). Then drain 4.
   Result: [2, 4].  Inversions: 0

=== RIGHT: [1, 3, 5] ===
   Split into [1] and [3, 5].
   [3,5]: split [3],[5]. Merge: 3<=5, no inversion. Result [3,5]. Inversions: 0
   Merge [1] with [3,5]: 1 <= 3, take 1 (no inversion). Drain 3, 5.
   Result: [1, 3, 5].  Inversions: 0

=== TOP-LEVEL MERGE: L = [2, 4], R = [1, 3, 5] ===
   buf = [2, 4, 1, 3, 5]
   i=0 (points at 2), mid=1, j=2 (points at 1), k=0

   Step 1: buf[0]=2 vs buf[2]=1.  2 > 1  ->  take from RIGHT.
           arr[0] = 1.  j -> 3
           inversions += (mid - i + 1) = (1 - 0 + 1) = 2
           
           WHY 2?  Elements remaining in L are buf[0..1] = {2, 4}.
                   Both are > 1, and both come before 1 in the original array.
                   Inversions found: (2,1) and (4,1).   ✓ exactly right.
           
           running total: 2

   Step 2: buf[0]=2 vs buf[3]=3.  2 <= 3  ->  take from LEFT.
           arr[1] = 2.  i -> 1.  No inversion (2 comes before 3 and is smaller).
           
   Step 3: buf[1]=4 vs buf[3]=3.  4 > 3  ->  take from RIGHT.
           arr[2] = 3.  j -> 4
           inversions += (mid - i + 1) = (1 - 1 + 1) = 1
           
           WHY 1?  Only buf[1] = {4} remains in L. 4 > 3 and comes earlier.
                   Inversion found: (4,3).   ✓
           
           running total: 3

   Step 4: buf[1]=4 vs buf[4]=5.  4 <= 5  ->  take from LEFT.
           arr[3] = 4.  i -> 2.  i > mid, left exhausted.

   Drain right: arr[4] = 5.

   Merged array: [1, 2, 3, 4, 5]
   Inversions from this merge: 3

TOTAL: 0 (left) + 0 (right) + 3 (merge) = 3   ✓
```

**Three critical details:**

**1. `inversions += (mid - i + 1)` — why that formula?**
`i` points at the first *unconsumed* element of the left half; `mid` is its last index. So the count of remaining left elements is `mid - i + 1`. Every one of them is `>= buf[i] > buf[j]` (the left half is sorted!) and every one sits at an earlier original index. **All of them form an inversion with `buf[j]`.** Off-by-one check: if `i == mid`, one element remains → `mid - mid + 1 = 1`. ✓

**2. `if (buf[i] <= buf[j])` — the `<=` is mandatory here, and not just for stability.**
An inversion requires `arr[i] > arr[j]` **strictly**. Equal elements are *not* inversions. With `<`, equal values would take the right branch and be miscounted as inversions. **This single character changes the answer.** The stability property and the correctness property happen to coincide — a nice observation to make.

**3. `long`, not `int`, for the count.**
Maximum inversions is `n(n-1)/2`. For n = 10⁵ that's ~5×10⁹, which **overflows `int`** (max 2.1×10⁹). Silent wraparound to a negative number. Declaring `inversions` and the return type as `long` is not paranoia — it's required for the stated constraints. **Volunteering this is exactly the overflow-awareness that distinguishes strong candidates** (see also Module 4, §4.7).

**Complexity:** **O(n log n) time** — it's merge sort with one extra addition per step, so the complexity is unchanged. **O(n) space** for the buffer plus O(log n) stack.

**The transferable pattern.** "Count pairs `(i, j)` with `i < j` and some relationship between `arr[i]` and `arr[j]`" is almost always solvable by **merge sort with counting**, or by a **Fenwick tree / BIT** (Module 11). Problems this exact technique solves:
- Count Inversions
- Reverse Pairs (`arr[i] > 2·arr[j]`)
- Count of Smaller Numbers After Self
- Count of Range Sum
- Global and Local Inversions

**The generalisable idea, stated once:** *when a problem asks about pairs across a sequence, split the sequence and count pairs that (a) lie entirely left, (b) lie entirely right, (c) straddle the split. The straddling case is where the algorithm lives, and sortedness of the two halves is what makes counting it linear.* That sentence is the core of divide-and-conquer counting, and it will serve you across a dozen problems.

---
---
