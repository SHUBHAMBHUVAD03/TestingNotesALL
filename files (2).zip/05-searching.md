*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 5 — Searching (and the Binary Search Pattern)

## 5.1 Intuition

Searching answers one question: **"where is it?"** And there are exactly two strategies in the universe.

**Linear search — look at everything.** Works always. Costs O(n).

**Binary search — eliminate half, repeatedly.** Costs O(log n). Requires *order*.

That word "requires" is the whole lesson. Binary search doesn't need a sorted array. **It needs a monotonic predicate** — a yes/no question whose answer flips exactly once as you move left to right. Sortedness is just the most familiar way to get that property.

Back to the phone book from Module 1. You open the middle and ask "is Ramesh after this?" The answer is NO for a while, then YES forever:

```
   Names:      Aarav  Bhavna  Deepak  Kavya  Ramesh  Sneha  Vikram
   "Is name >= Ramesh?"
               NO     NO      NO      NO     YES     YES    YES
                                             ^
                                             the flip point = the answer
```

**That flip point is what binary search finds.** Not "the target" — the *boundary*. Reframing binary search as "find the boundary of a monotonic predicate" instead of "find a value in a sorted array" is the single upgrade that lets you solve the hard variants. We'll build to that.

Why is halving so powerful? Because information doubles per question:

```
   Array size    Questions needed
   ------------  ----------------
   1             0
   2             1
   4             2
   1,000         10
   1,000,000     20
   1,000,000,000 30
   
   Every DOUBLING of the array costs exactly ONE more question.
```

Thirty questions to find one item among a billion. That's binary search.

## 5.2 Mental Model

**Model 1 — "I maintain a search space and I shrink it."**

Binary search is not about `mid`. It's about the **invariant**: *"if the answer exists, it is inside `[lo, hi]`."* Every step must preserve that. If you can state your invariant, you can write the loop correctly. If you can't, you'll fight off-by-one errors forever.

```
   Start:   [lo ........................ hi]     answer is somewhere in here
   Step:    compute mid, ask a question
   Discard: [lo ... mid]  or  [mid ... hi]        HALF is proven answer-free
   Repeat until the space holds one candidate (or is empty)
```

**Model 2 — "Never write `(lo + hi) / 2`."**

```java
int mid = (lo + hi) / 2;          // BUG: overflows when lo + hi > Integer.MAX_VALUE
int mid = lo + (hi - lo) / 2;     // CORRECT: hi - lo can never overflow
```
`hi - lo` is at most the array length, so it's always safe; adding it to `lo` keeps us in range. **This exact bug existed in `java.util.Arrays.binarySearch` for nine years** and in Joshua Bloch's own published binary search. Fixed in Java 6. Mentioning this story in an interview is genuinely charming and demonstrates real depth. Type the safe form every single time until it's muscle memory.

**Model 3 — "Answer these three questions before writing the loop."**
```
   1. Is my search space [lo, hi] inclusive, or [lo, hi) exclusive?
   2. Is my loop condition  lo <= hi  or  lo < hi ?
   3. When I discard, do I move to  mid ± 1  or to  mid ?
```
Those three must be *consistent*, and different variants need different combinations. Below I give you two templates that are internally consistent; **memorise them exactly and never improvise.**

## 5.3 Internal Working

### Why O(log n), derived

Each iteration keeps at most half the space. After `k` iterations the space has size `n / 2^k`. We stop when it holds 1 element:

```
   n / 2^k = 1
   2^k = n
   k = log₂ n
```

For n = 1,000,000: `k = 20`. Confirmed by the table in §5.1.

### What binary search costs that linear search doesn't

```
   Linear search:  no preconditions. O(n).  Works on anything.
   Binary search:  needs sorted data. O(log n) per query.
                   But sorting costs O(n log n) once.
```

**The break-even calculation** — this is the practical engineering question, and interviewers love it:

```
   q queries on n elements:
     Linear:  q × n
     Sort + binary:  n log n + q log n

   Sorting wins when:  n log n + q log n  <  q × n
   
   n = 1,000,000, log n = 20:
     1 query:    2×10^7 + 20        vs  10^6         -> LINEAR wins
     100 queries: 2×10^7 + 2000     vs  10^8         -> BINARY wins
     
   Roughly: if q > log n, pay the sort. Otherwise don't.
```

**One query? Just scan.** Many queries? Sort once, then binary search forever. Say this trade-off out loud — it shows you think about amortising preprocessing.

### Cache behaviour (the honest footnote)

Binary search jumps around memory, causing a cache miss almost every step. Linear search walks contiguous memory, which the CPU prefetches beautifully. **For small arrays (roughly n < 50–100), linear search is often *faster in wall-clock time* despite being O(n).** This is why real-world implementations (including the JDK's `TimSort`) switch to insertion sort / linear scanning below a threshold. Big O is about growth, not about small inputs.

## 5.4 Visual Explanation

### Successful search: find 23 in a sorted array

```
Index:   0    1    2    3    4    5    6    7    8    9
Value:   2    5    8   12   16   23   38   56   72   91

--- Iteration 1 ---
lo=0, hi=9    mid = 0 + (9-0)/2 = 4
              arr[4] = 16.  16 < 23  ->  target is to the RIGHT
              
   [ 2    5    8   12   16 ] 23   38   56   72   91
   \_____ DISCARDED _____/  ^^^^^^^^^^^^^^^^^^^^^^
                            new search space: lo = 5

--- Iteration 2 ---
lo=5, hi=9    mid = 5 + (9-5)/2 = 5 + 2 = 7
              arr[7] = 56.  56 > 23  ->  target is to the LEFT
              
                            23   38 [ 56   72   91 ]
                            ^^^^^^^^  \_ DISCARDED _/
                            new search space: hi = 6

--- Iteration 3 ---
lo=5, hi=6    mid = 5 + (6-5)/2 = 5 + 0 = 5
              arr[5] = 23.  FOUND. Return 5.

Total: 3 comparisons for 10 elements. Linear search would have taken 6.
```

### Failed search: find 40 — watch the pointers cross

```
Index:   0    1    2    3    4    5    6    7    8    9
Value:   2    5    8   12   16   23   38   56   72   91

lo=0, hi=9,  mid=4:  arr[4]=16 < 40  ->  lo = 5
lo=5, hi=9,  mid=7:  arr[7]=56 > 40  ->  hi = 6
lo=5, hi=6,  mid=5:  arr[5]=23 < 40  ->  lo = 6
lo=6, hi=6,  mid=6:  arr[6]=38 < 40  ->  lo = 7
lo=7, hi=6:  lo > hi  ->  LOOP ENDS. Not found.

   Final state:      ... 38 | 56 ...
                        ^     ^
                       hi=6   lo=7
                       
   The pointers CROSSED. And notice where they ended up:
     hi points to the largest element < 40
     lo points to the smallest element > 40
     
   lo is exactly the INSERTION POINT for 40.
```

**That last observation is enormously useful.** When binary search fails, `lo` is the index where the target *would* go. This is why `Arrays.binarySearch` returns `-(insertionPoint) - 1` on failure — the negative encodes "not found" while preserving the position. It also solves "lower bound", "ceiling", and "count of elements less than x" for free.

## 5.5 Java Implementation

### Template A — exact match (inclusive bounds)

```java
package com.dsa.searching;

public final class Searching {

    private Searching() { }

    /** Linear search. O(n). Works on unsorted data, and on anything. */
    public static int linearSearch(int[] arr, int target) {
        if (arr == null) return -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) return i;
        }
        return -1;
    }

    /** TEMPLATE A: exact match on a sorted array. O(log n) time, O(1) space. */
    public static int binarySearch(int[] arr, int target) {
        if (arr == null || arr.length == 0) return -1;

        int lo = 0, hi = arr.length - 1;          // INCLUSIVE bounds
        while (lo <= hi) {                        // continue while space is non-empty
            int mid = lo + (hi - lo) / 2;         // overflow-safe
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                lo = mid + 1;                     // mid is proven too small -> exclude it
            } else {
                hi = mid - 1;                     // mid is proven too big -> exclude it
            }
        }
        return -1;                                // lo > hi: space exhausted
    }

    /** Recursive form, for comparison. O(log n) time, O(log n) STACK space. */
    public static int binarySearchRecursive(int[] arr, int target) {
        return bsr(arr, target, 0, arr.length - 1);
    }
    private static int bsr(int[] arr, int target, int lo, int hi) {
        if (lo > hi) return -1;
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        return (arr[mid] < target)
                ? bsr(arr, target, mid + 1, hi)
                : bsr(arr, target, lo, mid - 1);
    }

    // ---------- TEMPLATE B: boundary search (the powerful one) ----------

    /**
     * First index where arr[i] >= target (C++'s lower_bound).
     * Returns arr.length if no such index exists.
     */
    public static int lowerBound(int[] arr, int target) {
        int lo = 0, hi = arr.length;              // NOTE: hi = length, EXCLUSIVE
        while (lo < hi) {                         // NOTE: strict <
            int mid = lo + (hi - lo) / 2;
            if (arr[mid] >= target) {
                hi = mid;                         // mid is a CANDIDATE -> keep it
            } else {
                lo = mid + 1;                     // mid fails -> exclude it
            }
        }
        return lo;                                // lo == hi == the boundary
    }

    /** First index where arr[i] > target (C++'s upper_bound). */
    public static int upperBound(int[] arr, int target) {
        int lo = 0, hi = arr.length;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            if (arr[mid] > target) hi = mid;
            else                   lo = mid + 1;
        }
        return lo;
    }

    /** Count of occurrences of target. O(log n). */
    public static int countOccurrences(int[] arr, int target) {
        return upperBound(arr, target) - lowerBound(arr, target);
    }

    /** Largest element <= target, or Integer.MIN_VALUE if none. */
    public static int floor(int[] arr, int target) {
        int idx = upperBound(arr, target) - 1;
        return (idx >= 0) ? arr[idx] : Integer.MIN_VALUE;
    }

    /** Smallest element >= target, or Integer.MAX_VALUE if none. */
    public static int ceiling(int[] arr, int target) {
        int idx = lowerBound(arr, target);
        return (idx < arr.length) ? arr[idx] : Integer.MAX_VALUE;
    }
}
```

## 5.6 Line-by-Line Code Explanation

**`int lo = 0, hi = arr.length - 1;` (Template A)**
Both bounds are **inclusive** — the search space is `[lo, hi]`, and `hi` is a real index we might return. That's why it's `length - 1`.

**`while (lo <= hi)` (Template A)**
`<=` because when `lo == hi` the space still contains **one** element that we haven't examined yet. Using `<` here would skip single-element spaces and fail to find elements at the boundaries. **This is the single most common binary search bug.** Test your implementation on a 1-element array — if it fails, this is why.

**`lo = mid + 1;` and `hi = mid - 1;` (Template A)**
The `± 1` is mandatory and it's what guarantees termination. We just *proved* `arr[mid]` is not the target, so excluding it is correct — and it strictly shrinks the space. Writing `lo = mid` instead creates an infinite loop when `lo == mid` (which happens whenever `hi == lo + 1`). **Every "my binary search hangs" bug is this line.**

**`int lo = 0, hi = arr.length;` (Template B — note the difference!)**
Now `hi` is **exclusive** — one past the end. The search space is `[lo, hi)`. Why? Because the answer to "first index where the predicate is true" might be *"nowhere"*, and `arr.length` is the natural encoding of that. Template B's return value is a **position**, possibly past the end; Template A's is an **index that must exist**.

**`while (lo < hi)` (Template B)**
Strict `<`. When `lo == hi` the half-open space `[lo, hi)` is **empty** — there's nothing left to examine, and `lo` *is* the answer. The loop condition and the bound convention must match: `[lo, hi]` pairs with `<=`; `[lo, hi)` pairs with `<`.

**`hi = mid;` — no minus one! (Template B)**
This is the crucial asymmetry, and it's where everyone stumbles. In Template B we're not looking for an exact value; we're looking for the **first** position satisfying a condition. When `arr[mid] >= target`, `mid` **might be the answer** — it satisfies the predicate. We must not discard it. So `hi = mid` keeps it in range (as the new exclusive upper bound, `mid` is still reachable as a value of `lo`).

Meanwhile `lo = mid + 1` in the else branch *is* safe, because `arr[mid] < target` proves `mid` is not a candidate.

```
   Template A: mid is EITHER the answer OR excludable  -> always ±1
   Template B: mid may be a CANDIDATE -> keep it (hi = mid)
                                      -> or exclude it (lo = mid + 1)
```

**Why does Template B still terminate with `hi = mid`?** Because `mid < hi` always holds when `lo < hi`:
```
   lo < hi  =>  mid = lo + (hi-lo)/2  <  hi     (integer division rounds down)
   So hi = mid STRICTLY decreases hi. Progress guaranteed.
```
Note that `mid` can equal `lo` (when `hi == lo + 1`), which is exactly why `lo = mid` would *not* be safe but `hi = mid` is. Understanding this asymmetry is the difference between someone who memorised binary search and someone who understands it.

**`return lo;` (Template B)**
At exit `lo == hi`. Everything before `lo` fails the predicate; everything from `lo` onward satisfies it. **`lo` is the boundary.** That's the invariant, and it's true even when the answer is `0` (everything satisfies) or `arr.length` (nothing does).

**`upperBound(t) - lowerBound(t)` for counting**
Beautiful and worth internalising:
```
   arr = [1, 2, 2, 2, 3],  target = 2
   
   lowerBound(2) = 1   (first index with value >= 2)
   upperBound(2) = 4   (first index with value >  2)
   count = 4 - 1 = 3   ✓
   
   [1,  2,  2,  2,  3]
        ^           ^
        lo=1        up=4
        \___3 twos_/
```
Two O(log n) searches instead of an O(n) scan. This is how you answer "count occurrences in a sorted array with duplicates" — a top-20 interview question.

**`floor` = `upperBound(t) - 1`**
`upperBound` gives the first element strictly greater than `t`. Step back one and you have the last element `<= t`. Guard `idx >= 0` for when every element exceeds `t`.

**The recursive version's space complexity**
`O(log n)` stack frames versus `O(1)` for the iterative form. Binary search is one of the few cases where **iterative is strictly better** — the recursion buys no clarity and costs stack. Prefer iterative, and say why if asked.

## 5.7 Complexity Analysis

| Algorithm | Time (worst) | Time (best) | Space | Precondition |
|---|---|---|---|---|
| Linear search | O(n) | O(1) | O(1) | none |
| Binary search (iterative) | O(log n) | O(1) | **O(1)** | sorted / monotonic |
| Binary search (recursive) | O(log n) | O(1) | O(log n) | sorted / monotonic |
| `lowerBound` / `upperBound` | O(log n) | O(log n) | O(1) | sorted |
| Count occurrences | O(log n) | — | O(1) | sorted |
| Sort + q binary searches | O(n log n + q log n) | — | O(log n)–O(n) | none |

**Why `lowerBound` has no O(1) best case:** it always runs the full `log n` iterations, because it never returns early on a match — it must confirm it found the *first* one. Slightly more work than Template A on lucky inputs, but far more powerful.

## 5.8 Common Mistakes

1. **`(lo + hi) / 2`** — overflow. Always `lo + (hi - lo) / 2`.
2. **`while (lo < hi)` with inclusive bounds** — skips single-element spaces. Misses elements.
3. **`lo = mid` in Template A** — infinite loop.
4. **`hi = mid - 1` in Template B** — skips the answer when `mid` is the boundary.
5. **Mixing the templates.** Inclusive `hi = length - 1` with `while (lo < hi)` and `hi = mid`? That combination is *almost* right and fails on specific inputs. **Don't improvise. Pick a template and reproduce it exactly.**
6. **Binary searching unsorted data** — returns garbage, silently. No exception. `Arrays.binarySearch` explicitly documents that results are undefined on unsorted input.
7. **Forgetting duplicates.** Template A returns *some* matching index, not the first or last. If duplicates matter, use Template B.
8. **Not checking for null / empty arrays.**
9. **Off-by-one in the answer-space version** — when binary searching over a *range of answers* rather than array indices (§5.9), getting the initial `lo`/`hi` wrong is fatal. Set them to provably-valid extremes.

## 5.9 Interview Perspective — the pattern that matters most

Plain "find x in a sorted array" is a warm-up. The real interview skill is recognising the **generalised** form:

> **Binary Search on the Answer.** If you can write a boolean function `isFeasible(x)` that is *monotonic* — false, false, false, then true, true, true — you can binary search for the flip point, even when there is no array to search.

```
   candidate answers:  1    2    3    4    5    6    7    8
   isFeasible(x):      F    F    F    T    T    T    T    T
                                      ^
                                 binary search finds this
```

**The trigger phrases.** When you hear any of these, think binary search on the answer:
- "minimum capacity such that..."
- "minimum days to..."
- "maximum value of the minimum..."  (or "minimise the maximum")
- "smallest k such that..."
- "can we do it within X?" as a subproblem

**How to structure your answer, every time:**
1. **Identify the answer range.** "The answer is between `lo` and `hi` because..." (lowest conceivable and highest conceivable values).
2. **Write `isFeasible(x)`** — usually a simple O(n) greedy scan.
3. **Prove monotonicity out loud.** "If capacity `x` works, then `x+1` certainly works, since more capacity can never hurt." **This proof is the whole answer.** Without monotonicity, binary search is invalid.
4. **Binary search** with Template B for the boundary.
5. **State complexity:** `O(n · log(range))`.

That five-step script converts a large family of hard problems into mechanical work. It's probably the highest return-on-investment pattern in interview preparation.

**The other must-know variants** (each a real interview question):
```
   Find first / last occurrence with duplicates      -> Template B
   Search in a rotated sorted array                  -> find which half is sorted
   Find the peak element                             -> compare mid with mid+1
   Find sqrt(x) with integer arithmetic              -> binary search on the answer
   Median of two sorted arrays                       -> binary search on the partition
   Koko eating bananas / ship packages in D days     -> binary search on the answer
   Find minimum in a rotated sorted array            -> compare mid with hi
```

## 5.10 Practice Problems

### Easy — Search Insert Position
Given a sorted array of distinct integers and a target, return the index if found; otherwise return the index where it would be inserted. Must be O(log n).
```
[1,3,5,6], target=5 -> 2
[1,3,5,6], target=2 -> 1
[1,3,5,6], target=7 -> 4
```

### Medium — Find First and Last Position of Element in Sorted Array
Given a sorted array with possible duplicates and a target, return `[firstIndex, lastIndex]`, or `[-1,-1]` if absent. O(log n).
```
[5,7,7,8,8,10], target=8 -> [3,4]
[5,7,7,8,8,10], target=6 -> [-1,-1]
```

### Hard — Koko Eating Bananas
`piles[i]` bananas in pile `i`. Koko eats for `h` hours. Each hour she picks one pile and eats up to `k` bananas from it; if the pile has fewer than `k`, she eats it all and stops for that hour. Find the **minimum** `k` allowing her to finish all piles within `h` hours.
```
piles = [3,6,7,11], h = 8  ->  4
piles = [30,11,23,4,20], h = 5 -> 30
```

## 5.11 Solution Walkthrough

### Easy — Search Insert Position

**The realisation:** this is *exactly* `lowerBound`. "The first index where `arr[i] >= target`" is both the location of the target (if present) and the correct insertion point (if not). One function, both cases, no special handling.

```java
public int searchInsert(int[] nums, int target) {
    int lo = 0, hi = nums.length;              // exclusive upper bound
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (nums[mid] >= target) hi = mid;     // candidate — keep it
        else                     lo = mid + 1; // too small — discard
    }
    return lo;
}
```

**Dry run: `[1,3,5,6]`, target = 2.**
```
lo=0, hi=4:  mid = 0 + 4/2 = 2.  nums[2]=5 >= 2  -> hi = 2
             space [0,2):  [1, 3]
lo=0, hi=2:  mid = 0 + 2/2 = 1.  nums[1]=3 >= 2  -> hi = 1
             space [0,1):  [1]
lo=0, hi=1:  mid = 0 + 1/2 = 0.  nums[0]=1 <  2  -> lo = 1
             space [1,1):  EMPTY
lo=1, hi=1:  loop exits.  return 1.   ✓  (2 would be inserted at index 1)
```

**Dry run: target = 7 (beyond everything).**
```
lo=0, hi=4:  mid=2, nums[2]=5 < 7  -> lo = 3
lo=3, hi=4:  mid=3, nums[3]=6 < 7  -> lo = 4
lo=4, hi=4:  exits.  return 4 == nums.length.   ✓
```
Notice how `hi = length` (not `length - 1`) is what makes returning `4` possible. If you'd used the inclusive template you'd need a special case for "greater than everything." **Template B eliminates the edge cases by construction** — that's the argument for learning it.

**Complexity:** O(log n) time, O(1) space.

### Medium — First and Last Position

**The mistake to avoid:** finding the target with Template A, then linearly scanning left and right for the boundaries. On input `[8,8,8,8,...,8]` (n copies) that scan is O(n) — you've thrown away your logarithm. Interviewers plant this input.

**The correct approach:** two boundary searches.
```
   first index of target  = lowerBound(target)
   last  index of target  = upperBound(target) - 1
```

```java
public int[] searchRange(int[] nums, int target) {
    if (nums == null || nums.length == 0) return new int[]{-1, -1};

    int first = lowerBound(nums, target);
    // If target is absent, first is either out of range or points elsewhere.
    if (first == nums.length || nums[first] != target) {
        return new int[]{-1, -1};
    }
    int last = upperBound(nums, target) - 1;
    return new int[]{first, last};
}

private int lowerBound(int[] a, int t) {
    int lo = 0, hi = a.length;
    while (lo < hi) { int m = lo + (hi-lo)/2; if (a[m] >= t) hi = m; else lo = m+1; }
    return lo;
}
private int upperBound(int[] a, int t) {
    int lo = 0, hi = a.length;
    while (lo < hi) { int m = lo + (hi-lo)/2; if (a[m] >  t) hi = m; else lo = m+1; }
    return lo;
}
```

**Dry run: `[5,7,7,8,8,10]`, target = 8.**

```
Index:   0   1   2   3   4   5
Value:   5   7   7   8   8  10

--- lowerBound(8): first index with value >= 8 ---
lo=0, hi=6:  mid=3, a[3]=8 >= 8  -> hi=3        space [0,3) = [5,7,7]
lo=0, hi=3:  mid=1, a[1]=7 <  8  -> lo=2        space [2,3) = [7]
lo=2, hi=3:  mid=2, a[2]=7 <  8  -> lo=3        space [3,3) = empty
exits, first = 3.   nums[3] == 8  ✓ target exists

--- upperBound(8): first index with value > 8 ---
lo=0, hi=6:  mid=3, a[3]=8 not > 8  -> lo=4     space [4,6) = [8,10]
lo=4, hi=6:  mid=5, a[5]=10 > 8     -> hi=5     space [4,5) = [8]
lo=4, hi=5:  mid=4, a[4]=8 not > 8  -> lo=5     space [5,5) = empty
exits, upper = 5.   last = 5 - 1 = 4

Answer: [3, 4]   ✓
```

**The two guards in `if (first == nums.length || nums[first] != target)`:**
- `first == nums.length` → target is larger than every element. Must check this **first**, or `nums[first]` throws `ArrayIndexOutOfBoundsException`. **Short-circuit `||` order is load-bearing here.**
- `nums[first] != target` → target is absent, and `first` points at the next larger element. E.g. searching for 6 in `[5,7,7,8,8,10]` gives `first = 1`, and `nums[1] = 7 ≠ 6`.

Both guards are needed. Omit either and you have a bug. **Say out loud: "lowerBound tells me where the target *would* be, so I must verify it's actually there."**

**Complexity:** two O(log n) searches → **O(log n) time, O(1) space.** Crucially, this holds even when the entire array is the target — the whole point.

### Hard — Koko Eating Bananas

**This is the flagship "binary search on the answer" problem.** Work the five-step script.

**Step 0 — recognise the pattern.** "Find the *minimum* `k` such that she *can* finish in `h` hours." Minimum-something-such-that-feasible. That's the trigger.

**Step 1 — the answer range.**
- Lowest conceivable `k` is **1** (she must eat at least one banana per hour, or she never finishes).
- Highest conceivable `k` is **`max(piles)`**. With `k = max(piles)`, she clears one entire pile per hour, taking exactly `piles.length` hours. Any larger `k` gives the *same* time, so it's wasted. So `hi = max(piles)`.

Also note: if `h < piles.length`, it's impossible — she can't finish even one pile per hour. The problem guarantees `h >= piles.length`, but say it out loud.

**Step 2 — `isFeasible(k)`: can she finish with speed `k`?**

Hours needed for one pile of size `p` at speed `k` is `ceil(p / k)`. Why ceiling? Because a partial pile still costs a full hour — she stops eating for that hour once the pile is gone.

```
   pile = 7, k = 3:  hours 1 and 2 eat 3 each (6 total), hour 3 eats the last 1.
                     -> 3 hours = ceil(7/3) = 3   ✓
```

Total hours = `Σ ceil(piles[i] / k)`. Feasible iff that total `<= h`.

**Step 3 — prove monotonicity. This is the heart of the answer.**

> "If speed `k` lets her finish in time, then speed `k+1` certainly does — she eats at least as fast from every pile, so `ceil(p/(k+1)) <= ceil(p/k)` for every pile, so the total hours can only decrease. Therefore `isFeasible` is monotonically non-decreasing in `k`: false for small `k`, then true for all larger `k`. That single flip point is what binary search finds."

Visualise it:
```
   k:               1    2    3    4    5    6    7   ... 11
   hours needed:   27   15   10    8    7    6    6   ...  4
   feasible (h=8)?  F    F    F    T    T    T    T   ...  T
                                   ^
                              answer = 4
```

**Step 4 — the code.**

```java
public int minEatingSpeed(int[] piles, int h) {
    int lo = 1;
    int hi = 0;
    for (int p : piles) hi = Math.max(hi, p);     // hi = max pile

    while (lo < hi) {                              // Template B: find the boundary
        int mid = lo + (hi - lo) / 2;
        if (canFinish(piles, mid, h)) {
            hi = mid;                              // mid works -> it's a candidate, keep it
        } else {
            lo = mid + 1;                          // mid too slow -> discard
        }
    }
    return lo;                                     // smallest feasible speed
}

private boolean canFinish(int[] piles, int k, int h) {
    long hours = 0;                                // long: guards against overflow
    for (int p : piles) {
        hours += (p + k - 1) / k;                  // integer ceiling division
        if (hours > h) return false;               // early exit: already too slow
    }
    return hours <= h;
}
```

**Dry run: `piles = [3,6,7,11]`, `h = 8`.**

```
hi = max(3,6,7,11) = 11.  Search space: k in [1, 11].

--- Iteration 1 ---
lo=1, hi=11.  mid = 1 + (11-1)/2 = 1 + 5 = 6
canFinish(k=6):
    ceil(3/6)  = 1
    ceil(6/6)  = 1
    ceil(7/6)  = 2
    ceil(11/6) = 2
    total = 6 hours.  6 <= 8  ->  FEASIBLE
-> hi = 6.   Space [1, 6]

--- Iteration 2 ---
lo=1, hi=6.   mid = 1 + (6-1)/2 = 1 + 2 = 3
canFinish(k=3):
    ceil(3/3)  = 1
    ceil(6/3)  = 2
    ceil(7/3)  = 3
    ceil(11/3) = 4
    total = 10 hours.  10 > 8  ->  NOT feasible
-> lo = 4.   Space [4, 6]

--- Iteration 3 ---
lo=4, hi=6.   mid = 4 + (6-4)/2 = 4 + 1 = 5
canFinish(k=5):
    ceil(3/5)  = 1
    ceil(6/5)  = 2
    ceil(7/5)  = 2
    ceil(11/5) = 3
    total = 8 hours.  8 <= 8  ->  FEASIBLE
-> hi = 5.   Space [4, 5]

--- Iteration 4 ---
lo=4, hi=5.   mid = 4 + (5-4)/2 = 4 + 0 = 4
canFinish(k=4):
    ceil(3/4)  = 1
    ceil(6/4)  = 2
    ceil(7/4)  = 2
    ceil(11/4) = 3
    total = 8 hours.  8 <= 8  ->  FEASIBLE
-> hi = 4.   Space [4, 4]

lo == hi == 4.  Loop exits.  Return 4.   ✓

Notice: we tested 4 speeds out of 11, and never tested most of them.
Only log2(11) ≈ 4 evaluations of canFinish were needed.
```

**Three implementation details that separate a working solution from a great one:**

**1. `(p + k - 1) / k` — integer ceiling division.**
Java's `/` truncates toward zero, so `7/3 = 2` when we want 3. The idiom `(a + b - 1) / b` computes `ceil(a/b)` for positive integers:
```
   p=7, k=3:  (7 + 3 - 1) / 3 = 9 / 3 = 3      ✓ ceil(7/3) = 3
   p=6, k=3:  (6 + 3 - 1) / 3 = 8 / 3 = 2      ✓ ceil(6/3) = 2 (exact division unaffected)
   p=3, k=6:  (3 + 6 - 1) / 6 = 8 / 6 = 1      ✓ ceil(3/6) = 1
```
Why it works: adding `k-1` pushes any non-zero remainder over the next multiple of `k`, while an exact multiple is left in the same bucket. **Memorise this idiom** — it appears in dozens of problems. The alternative `Math.ceil((double) p / k)` works but introduces floating-point imprecision on large values; integer arithmetic is exact and preferred.

**2. `long hours` and the early exit.**
With `piles.length` up to 10⁴ and pile sizes up to 10⁹, at `k = 1` the total hours could reach 10¹³ — which overflows `int` (max ≈ 2.1×10⁹). Declaring `hours` as `long` prevents a silent wrap to a negative number that would falsely report feasibility. And `if (hours > h) return false;` bails out the instant we exceed the budget, which often saves most of the scan.

**Overflow reasoning volunteered unprompted is one of the strongest signals a candidate can give.** Do it.

**3. Why Template B, and why `hi = mid` without the −1.**
We want the *smallest* feasible `k`. When `mid` is feasible, `mid` **might be the answer** — so we keep it (`hi = mid`) and keep looking left for something smaller. When `mid` is infeasible, `mid` is definitively not the answer (`lo = mid + 1`). This is exactly the boundary-search shape from §5.6, applied to a space of *answers* rather than array indices.

**Complexity.**
- `canFinish` is O(n) where n = `piles.length`.
- Binary search runs O(log(max(piles))) iterations — note the log is over the **value range**, not the array length.
- Total: **O(n · log(max(piles)))**.
- For n = 10⁴ and max pile = 10⁹: `10⁴ × 30 = 3×10⁵` operations. Instant.
- **Space: O(1).**

**Compare with brute force:** try every `k` from 1 upward, checking each in O(n) → `O(n · max(piles))` = 10⁴ × 10⁹ = **10¹³ operations**. Binary search improves this by a factor of ~30 million, purely by exploiting monotonicity.

**The transferable script.** Every "binary search on the answer" problem reduces to:
```
   1. What is the answer's range?         -> lo, hi
   2. Write isFeasible(candidate)         -> usually a simple O(n) greedy pass
   3. PROVE monotonicity out loud         -> "if x works, x+1 works, because..."
   4. Template B for the boundary
   5. Complexity = O(n · log(range))
```
Problems this solves verbatim: *Ship Packages in D Days*, *Split Array Largest Sum*, *Minimum Number of Days to Make m Bouquets*, *Capacity To Ship*, *Magnetic Force Between Two Balls*, *Minimize Max Distance to Gas Station*, *Kth Smallest in a Sorted Matrix*, *Find the Smallest Divisor Given a Threshold*. Learn the script once; solve eight problems.

---
---
