*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 4 — Recursion

## 4.1 Intuition

Recursion is **delegation to a slightly smaller version of yourself.**

Here's the analogy I want you to hold onto for the rest of your career. You're standing in a cinema queue and you want to know your position from the front. You can't see the front. What do you do?

You tap the person ahead of you and ask: **"What position are you?"**

You have no idea how they'll find out. You don't care. You trust that they will. When they answer "I'm 7th," you immediately know you're 8th. You add one and report it back.

Every person in that queue runs the identical algorithm:
```
   "If nobody is in front of me, I am position 1."          <- BASE CASE
   "Otherwise, ask the person ahead, add 1, report."        <- RECURSIVE CASE
```

That is recursion. Completely. And notice what you *didn't* do:

- You didn't manage a loop.
- You didn't track how many people are ahead.
- You didn't need to see the whole queue.

You solved a problem you couldn't see the whole of, by trusting a smaller instance of the same problem.

**The single hardest mental shift** — and I want to name it explicitly, because it's where everyone gets stuck — is this:

> **Stop trying to trace the whole recursion in your head.**

Beginners try to mentally simulate every call, get four levels deep, lose track, and conclude recursion is confusing. That's like trying to understand a `for` loop by visualising all million iterations simultaneously. You don't do that. You reason about *one* iteration and the invariant.

For recursion, reason about **one call**, assuming the recursive call already works. This is called the **recursive leap of faith**, and it isn't hand-waving — it's mathematical induction, the same tool that proves statements about all integers by proving one step.

## 4.2 Mental Model

Every correct recursive function has exactly three parts. Write them in this order, every time, no exceptions.

```
   +--------------------------------------------------------------+
   |  1. BASE CASE      When is the answer obvious with no        |
   |                    further work? Handle it, return.          |
   |                                                              |
   |  2. RECURSIVE CASE Assume the function works for smaller     |
   |                    input. Call it. Use the result.           |
   |                                                              |
   |  3. PROGRESS       Prove every call moves strictly closer    |
   |                    to the base case.                         |
   +--------------------------------------------------------------+
```

Miss #1 → infinite recursion → `StackOverflowError`.
Miss #3 → infinite recursion → `StackOverflowError`.
Miss #2 → you wrote a loop, badly.

**The three questions to ask out loud** (yes, in the interview — interviewers love hearing this):

1. **"What's the smallest input I can answer instantly?"** → base case.
2. **"If I had the answer for a smaller input, how would I build my answer from it?"** → recursive case.
3. **"Does my input definitely shrink toward the base case?"** → progress.

Let's apply it to `factorial(n)`:

1. Smallest input? `factorial(0) = 1`. By definition. Done.
2. If I knew `factorial(n-1)`, could I get `factorial(n)`? Yes — multiply by `n`.
3. Does `n-1` approach 0? Yes, for `n ≥ 0`.

Three sentences, and the code is already written:
```java
long factorial(int n) {
    if (n <= 1) return 1;              // 1
    return n * factorial(n - 1);       // 2, with 3 guaranteed by n-1
}
```

**The two-phase model.** This is the visualisation that fixes most confusion. Every recursion has a way **down** and a way **back up**:

```
   DOWN (the "winding" phase)          UP (the "unwinding" phase)
   calls get made, nothing returns     returns flow back, work happens
   arguments SHRINK                    results COMBINE

        f(4)                                f(4) = 4 * 6 = 24
         |                                   ^
         v                                   |  returns 6
        f(3)                                f(3) = 3 * 2 = 6
         |                                   ^
         v                                   |  returns 2
        f(2)                                f(2) = 2 * 1 = 2
         |                                   ^
         v                                   |  returns 1
        f(1) -> base case, returns 1 --------+
```

**Work done on the way down** = *pre-order* thinking (pass information downward as parameters).
**Work done on the way up** = *post-order* thinking (combine results returned from below).

Almost every recursion question is really asking: *do you compute before or after the recursive call?* Once you can answer that, tree traversals, DFS, and backtracking all become the same skill.

## 4.3 Internal Working — the Call Stack

This is the part that makes recursion *concrete* rather than magical. And it's where Java-specific interview questions live.

### What a stack frame is

Every method call — recursive or not — pushes a **stack frame** onto the current thread's **JVM stack**. A frame contains:

```
   +-----------------------------------------+
   |  STACK FRAME for factorial(3)           |
   +-----------------------------------------+
   |  Local variable array:                  |
   |     [0] n = 3          <- parameters live here too
   |  Operand stack:                         |
   |     (intermediate values for bytecode)  |
   |  Return address:                        |
   |     "resume in factorial(4) at the      |
   |      multiply instruction"              |
   |  Reference to constant pool             |
   +-----------------------------------------+
```

Crucially: **each frame has its own copy of the local variables.** When `factorial(4)` calls `factorial(3)`, there are now two `n`s in existence — one equal to 4, one equal to 3, in separate frames. They do not interfere. This is why recursion works at all, and it's why students who imagine "one shared n that keeps changing" get confused.

### Full stack trace for `factorial(4)`

Watch the stack grow, then shrink. This diagram is worth ten explanations.

```
TIME ->

t1: main calls factorial(4)
    +----------------+
    | factorial(4)   |  n=4, waiting on factorial(3)
    +----------------+
    | main           |
    +----------------+

t2: factorial(4) calls factorial(3)
    +----------------+
    | factorial(3)   |  n=3, waiting on factorial(2)
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED mid-expression
    +----------------+
    | main           |
    +----------------+

t3:
    +----------------+
    | factorial(2)   |  n=2, waiting
    +----------------+
    | factorial(3)   |  n=3, SUSPENDED
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED
    +----------------+
    | main           |
    +----------------+

t4: MAXIMUM DEPTH — base case reached
    +----------------+
    | factorial(1)   |  n=1 -> BASE CASE, returns 1 immediately
    +----------------+
    | factorial(2)   |  n=2, SUSPENDED
    +----------------+
    | factorial(3)   |  n=3, SUSPENDED
    +----------------+
    | factorial(4)   |  n=4, SUSPENDED
    +----------------+
    | main           |
    +----------------+
    ^^^ FOUR frames alive at once. THIS is the O(n) space.

t5: factorial(1) returns 1 -> its frame is POPPED
    factorial(2) resumes: computes 2 * 1 = 2
    +----------------+
    | factorial(2)   |  about to return 2
    +----------------+
    | factorial(3)   |
    +----------------+
    | factorial(4)   |
    +----------------+
    | main           |
    +----------------+

t6: factorial(2) returns 2 -> POPPED
    factorial(3) resumes: 3 * 2 = 6
    +----------------+
    | factorial(3)   |  about to return 6
    +----------------+
    | factorial(4)   |
    +----------------+
    | main           |
    +----------------+

t7: factorial(3) returns 6 -> POPPED
    factorial(4) resumes: 4 * 6 = 24
    +----------------+
    | factorial(4)   |  about to return 24
    +----------------+
    | main           |
    +----------------+

t8: factorial(4) returns 24 -> POPPED. Stack back to just main.
    +----------------+
    | main           |  receives 24
    +----------------+
```

**Read t4 again.** Four frames coexist. That's the entire reason recursion costs O(depth) space, and the reason `StackOverflowError` exists.

### `StackOverflowError` — the practical limit

```java
static int depth = 0;
static void boom() { depth++; boom(); }
```
Run this and you'll get `StackOverflowError` at roughly **10,000–25,000** frames on a default JVM (default thread stack is typically 512 KB–1 MB; each frame is tens of bytes).

You can raise it with `java -Xss16m YourClass`, but **that's a workaround, not a fix.** If your recursion depth scales with input size and input can be large, convert to iteration or use an explicit stack.

**The interview question:** *"Your recursive solution works but crashes on large input. What do you do?"*

Your answer, in order of preference:
1. **Reduce the depth.** Is there an O(log n)-depth formulation? (Divide and conquer instead of linear recursion.)
2. **Convert to iteration.** Linear recursions (`factorial`, list traversal) convert to a simple loop. Tree/graph recursions convert to an explicit `Deque` used as a stack.
3. **Only then** raise `-Xss`, and document why.

Note that Java **does not perform tail-call optimisation**, unlike Scala or functional languages. Writing your recursion in tail position does *not* make it constant-space in Java. It's still one frame per call. This is a genuinely good thing to know: it's a common misconception, and correcting it politely in an interview lands well.

## 4.4 Visual Explanation — Recursion Trees

Linear recursion (`factorial`) is a straight line. But most interesting recursions **branch**, and the shape of the branching *is* the complexity.

### Naive Fibonacci — the exponential disaster

```java
int fib(int n) {
    if (n <= 1) return n;
    return fib(n - 1) + fib(n - 2);
}
```

Draw the tree for `fib(5)`:

```
                            fib(5)
                          /        \
                    fib(4)          fib(3)
                   /      \        /      \
              fib(3)     fib(2) fib(2)    fib(1)
             /     \     /   \   /   \
        fib(2)  fib(1) fib(1) fib(0) fib(1) fib(0)
        /    \
   fib(1)  fib(0)
```

Count the calls: **15 calls to compute fib(5).** Now look for the waste:

```
   fib(3) is computed 2 times
   fib(2) is computed 3 times
   fib(1) is computed 5 times
   fib(0) is computed 3 times
```

The subtree under the left `fib(3)` is **identical** to the right `fib(3)` subtree. We rebuild it from scratch. And that duplication compounds at every level.

**How bad?** The tree has roughly `2^n` nodes:
```
   fib(10)  ->  177 calls
   fib(20)  ->  21,891 calls
   fib(30)  ->  2,692,537 calls
   fib(40)  ->  331,160,281 calls        (~1 second)
   fib(50)  ->  40,730,022,147 calls     (~2 minutes)
   fib(100) ->  more calls than atoms you'll ever count
```

Precisely, `T(n) = O(φ^n)` where φ ≈ 1.618 (the golden ratio). Call it **O(2^n)**.

**The fix — memoization.** Cache each result the first time you compute it:

```java
long fib(int n, long[] memo) {
    if (n <= 1) return n;
    if (memo[n] != 0) return memo[n];              // already known -> return instantly
    return memo[n] = fib(n - 1, memo) + fib(n - 2, memo);
}
```

The tree **collapses**:

```
   Without memo:                    With memo:
                                    (X = cache hit, returns immediately)
        fib(5)                           fib(5)
       /      \                         /      \
   fib(4)    fib(3)                 fib(4)    fib(3) X
   /    \    /    \                 /    \
 fib(3) fib(2) ...                fib(3)  fib(2) X
 ...    ...                       /    \
 15 nodes                       fib(2) fib(1) X
                                /    \
                             fib(1) fib(0)
                             9 nodes, and only 6 do real work
```

Each value `0..n` is computed **exactly once** → **O(n) time, O(n) space.** From 40 billion operations to 50. That is the single most dramatic complexity improvement in all of DSA, and it's the doorway to Dynamic Programming (Module 21).

> **The DP insight, stated once and reused forever: memoization = recursion + a cache. If your recursion tree has repeated subproblems, cache them. That's the whole idea.**

### Recursion tree for divide-and-conquer

Contrast Fibonacci's branching (2 children, input shrinks by 1) with merge sort's (2 children, input **halves**):

```
   FIBONACCI: n -> n-1 and n-2       MERGE SORT: n -> n/2 and n/2
   Shrinks by SUBTRACTION            Shrinks by DIVISION

           n                                  n
          / \                                / \
       n-1   n-2                          n/2   n/2
       / \   / \                          / \   / \
     ...  ...  ...                     n/4 n/4 n/4 n/4

   Depth: n                           Depth: log n
   Nodes: 2^n                         Nodes: 2n
   -> EXPONENTIAL                     -> LINEARITHMIC
```

**This is the single most important structural distinction in recursion.** Memorise it:

> **Subtracting from the input with branching → exponential. Dividing the input with branching → n log n.**
>
> If your recursion branches, make sure it *divides*.

## 4.5 Step-by-Step Dry Run — Recursive Array Sum

Let's trace something with an array, since that's what interviews use.

```java
int sum(int[] arr, int i) {
    if (i == arr.length) return 0;         // base: past the end, nothing to add
    return arr[i] + sum(arr, i + 1);       // this element + sum of the rest
}
```

For `arr = [3, 1, 4]`:

```
DOWN (winding):

sum(arr, 0):  i=0 != 3, so return arr[0] + sum(arr, 1)
              = 3 + <waiting...>
                     |
                     v
sum(arr, 1):  i=1 != 3, so return arr[1] + sum(arr, 2)
              = 1 + <waiting...>
                     |
                     v
sum(arr, 2):  i=2 != 3, so return arr[2] + sum(arr, 3)
              = 4 + <waiting...>
                     |
                     v
sum(arr, 3):  i=3 == 3  ->  BASE CASE  ->  return 0
                     |
UP (unwinding):      |
                     v
sum(arr, 2):  = 4 + 0   = 4    ---> returns 4
                     |
                     v
sum(arr, 1):  = 1 + 4   = 5    ---> returns 5
                     |
                     v
sum(arr, 0):  = 3 + 5   = 8    ---> returns 8

Answer: 8.  (3 + 1 + 4 = 8 ✓)
```

**Notice the shape of the suspended computation.** At maximum depth, the machine is holding:
```
   3 + (1 + (4 + (0)))
```
The additions all happen on the way **up**. Nothing is added on the way down — the calls just stack up with pending `+` operations. That's post-order work.

Compare a version that does work on the way **down**:
```java
int sum(int[] arr, int i, int acc) {
    if (i == arr.length) return acc;
    return sum(arr, i + 1, acc + arr[i]);   // accumulate BEFORE recursing
}
```
```
sum(arr,0,0) -> sum(arr,1,3) -> sum(arr,2,4) -> sum(arr,3,8) -> returns 8
                          ^ acc built on the way DOWN; nothing to do on the way up
```
This is **tail recursion** — the recursive call is the last thing that happens, with no pending work. In a language with TCO this compiles to a loop with O(1) space. **In Java it does not** — it's still O(n) frames. But the *shape* matters enormously, because a tail-recursive function converts to a loop mechanically:

```java
int sum(int[] arr) {
    int acc = 0;
    for (int i = 0; i < arr.length; i++) acc += arr[i];   // the accumulator became a variable
    return acc;
}
```

> **Recognising tail position tells you the recursion can become a simple loop. Recognising non-tail position (pending work on the way up) tells you it needs an explicit stack.**

## 4.6 Java Implementation — a graded set of recursions

```java
package com.dsa.recursion;

import java.util.ArrayList;
import java.util.List;

public final class Recursion {

    private Recursion() { }

    // ---------- 1. Linear recursion ----------

    /** n! with overflow awareness. Depth O(n). */
    public static long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0, got " + n);
        if (n > 20) throw new ArithmeticException("21! overflows long");
        if (n <= 1) return 1L;                    // base case handles both 0 and 1
        return n * factorial(n - 1);
    }

    // ---------- 2. Two-way recursion with memo ----------

    /** Fibonacci in O(n) via top-down memoization. */
    public static long fib(int n) {
        if (n < 0) throw new IllegalArgumentException("n must be >= 0");
        long[] memo = new long[n + 1];
        boolean[] computed = new boolean[n + 1];   // avoids the "0 is ambiguous" problem
        return fibHelper(n, memo, computed);
    }

    private static long fibHelper(int n, long[] memo, boolean[] computed) {
        if (n <= 1) return n;
        if (computed[n]) return memo[n];
        computed[n] = true;
        memo[n] = fibHelper(n - 1, memo, computed) + fibHelper(n - 2, memo, computed);
        return memo[n];
    }

    // ---------- 3. Divide and conquer ----------

    /** Fast exponentiation: x^n in O(log n). */
    public static double power(double x, int n) {
        if (n == 0) return 1.0;
        if (n < 0) {
            // Guard against n == Integer.MIN_VALUE, where -n overflows.
            return 1.0 / (power(x, -(n / 2)) * power(x, -(n - n / 2)));
        }
        double half = power(x, n / 2);
        return (n % 2 == 0) ? half * half : half * half * x;
    }

    // ---------- 4. Recursion producing a collection ----------

    /** All subsets of a distinct-element array. O(2^n) results. */
    public static List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> out = new ArrayList<>();
        buildSubsets(nums, 0, new ArrayList<>(), out);
        return out;
    }

    private static void buildSubsets(int[] nums, int idx,
                                     List<Integer> current,
                                     List<List<Integer>> out) {
        if (idx == nums.length) {
            out.add(new ArrayList<>(current));    // SNAPSHOT — see explanation
            return;
        }
        // Choice A: exclude nums[idx]
        buildSubsets(nums, idx + 1, current, out);

        // Choice B: include nums[idx]
        current.add(nums[idx]);
        buildSubsets(nums, idx + 1, current, out);
        current.remove(current.size() - 1);       // BACKTRACK — undo the choice
    }

    // ---------- 5. Tail-shaped recursion (converts to a loop) ----------

    /** Greatest common divisor, Euclid's algorithm. Depth O(log min(a,b)). */
    public static int gcd(int a, int b) {
        return (b == 0) ? Math.abs(a) : gcd(b, a % b);
    }

    // ---------- 6. Classic multi-move recursion ----------

    /** Towers of Hanoi. Prints the optimal 2^n - 1 move sequence. */
    public static void hanoi(int n, char from, char to, char via) {
        if (n == 0) return;
        hanoi(n - 1, from, via, to);                                   // move n-1 out of the way
        System.out.println("Move disk " + n + ": " + from + " -> " + to);
        hanoi(n - 1, via, to, from);                                   // bring them back on top
    }
}
```

## 4.7 Line-by-Line Code Explanation

**`if (n < 0) throw new IllegalArgumentException("n must be >= 0, got " + n);`**
Validate **before** recursing. If you validate inside the recursive case, you re-check the same condition n times. And note: without this, `factorial(-1)` recurses toward negative infinity → `StackOverflowError` with a useless stack trace. A clear exception at the boundary is worth a hundred debugging hours.

**`if (n > 20) throw new ArithmeticException("21! overflows long");`**
`20! = 2,432,902,008,176,640,000` fits in a `long` (max ≈ 9.22 × 10¹⁸). `21!` does not — it silently wraps to a wrong positive number. **Silent integer overflow is one of the nastiest bug classes in Java** because there's no exception; you just get garbage. Mentioning overflow unprompted is a strong senior signal. (`Math.multiplyExact` throws on overflow if you prefer runtime detection.)

**`if (n <= 1) return 1L;`**
`<=` not `==`. This single base case covers `n == 0` (0! = 1 by definition) *and* `n == 1`. **Merging base cases where mathematically sound reduces the surface area for bugs.**

**`boolean[] computed` alongside `long[] memo`**
Why not just check `memo[n] != 0`? Because **0 is a legitimate Fibonacci value** (`fib(0) = 0`). If `fib(0)` legitimately computes to 0, the sentinel check `memo[n] != 0` fails and we recompute forever. For Fibonacci we get lucky (n ≤ 1 is handled by the base case), but the *habit* is what matters. Options:
- a parallel `boolean[] computed` (used here — explicit and always correct),
- `Arrays.fill(memo, -1)` when −1 is impossible as an answer,
- `Long[]` and check `null`.

**Pick a sentinel that cannot be a valid answer.** This is a real bug that has cost real people real interviews.

**`computed[n] = true;` placed BEFORE the recursive calls**
Subtle and deliberate. For a pure tree recursion it doesn't matter, but marking before recursing is the pattern that also detects **cycles** in graph memoization. Building the habit now pays off in Module 14.

**`double half = power(x, n / 2);` — called ONCE**
This is the whole algorithm. Compare:
```java
return power(x, n/2) * power(x, n/2);   // WRONG: 2 calls -> T(n)=2T(n/2)+1 -> O(n)
double half = power(x, n/2);
return half * half;                     // RIGHT: 1 call  -> T(n)=T(n/2)+1  -> O(log n)
```
Both are "correct" in output. One is exponentially better. **Store the result of a recursive call in a variable rather than calling twice** — the single most common way people accidentally destroy a divide-and-conquer's complexity.

Why O(log n)? Each call halves `n`:
```
   power(x, 16) -> power(x,8) -> power(x,4) -> power(x,2) -> power(x,1) -> power(x,0)
   5 calls for n=16.  log2(16) = 4.  -> O(log n)
```

**`(n % 2 == 0) ? half * half : half * half * x`**
The mathematics: `x^n = (x^(n/2))²` when n is even. When n is odd, integer division loses the remainder, so `n = 2·(n/2) + 1` and we must multiply by one extra `x`. Example: `x^7 = (x^3)² · x`.

**`if (n < 0) return 1.0 / (power(x, -(n/2)) * power(x, -(n - n/2)));`**
This looks convoluted, and it's guarding a **real trap**. The obvious code is `return 1.0 / power(x, -n);`. But if `n == Integer.MIN_VALUE` (−2,147,483,648), then `-n` **overflows** — because `Integer.MAX_VALUE` is only 2,147,483,647. `-n` wraps back to `Integer.MIN_VALUE`, still negative, and you recurse forever.

Splitting into two halves before negating keeps every value in range. **Interviewers at Google and Amazon specifically test `Integer.MIN_VALUE` on this problem.** The general lesson: **`-Integer.MIN_VALUE == Integer.MIN_VALUE`.** Negation is not safe on `int`. Say that sentence in an interview.

**`out.add(new ArrayList<>(current));` — the snapshot**
The most important line in `subsets`. We add a **copy**, not `current` itself. Why?

`current` is a single mutable list reused across the entire recursion. If we added the reference, every entry in `out` would point at the *same* list object — and after backtracking emptied it, `out` would contain 2ⁿ references to one empty list.

```
   WRONG: out.add(current)
   out = [ ref, ref, ref, ref ]
            \    |    |    /
             \   |    |   /
              +--+----+--+
                    v
              current = []     <- after all backtracking, everything is empty!

   RIGHT: out.add(new ArrayList<>(current))
   out = [ [], [3], [1], [1,3] ]    <- independent snapshots, frozen in time
```

**This is the #1 bug in all of backtracking.** If your backtracking output is a list of identical empty lists, this is why.

**`current.remove(current.size() - 1);` — the backtrack**
After exploring the "include" branch, we must **undo** our modification so the parent frame sees `current` exactly as it left it. This restores the invariant: *every recursive call returns `current` in the state it received it.*

```
   depth 0: current = []
     -> exclude 3 -> depth 1: current = []            (unchanged, fine)
     -> include 3 -> current = [3]
                     depth 1 explores with [3]
                  <- MUST remove 3 here, or depth 0's parent sees [3] wrongly
   depth 0: current = []   <- invariant restored
```

Forget the `remove` and your results accumulate garbage from sibling branches. **State the invariant out loud when you write backtracking code** — it's how you avoid the bug and how you demonstrate rigour.

**`return (b == 0) ? Math.abs(a) : gcd(b, a % b);`**
Euclid's algorithm. The insight: `gcd(a, b) = gcd(b, a mod b)`, because any common divisor of `a` and `b` also divides `a mod b`. `Math.abs` handles negative inputs (gcd is conventionally non-negative). This is in **tail position** — the recursive call is the entire return expression with nothing pending — so it converts trivially to a loop:
```java
while (b != 0) { int t = b; b = a % b; a = t; }
return Math.abs(a);
```
Depth is O(log min(a,b)) — a beautiful result: consecutive Fibonacci numbers are the worst case.

**`hanoi(n-1, from, via, to);` then print, then `hanoi(n-1, via, to, from);`**
Note how the roles of the pegs **rotate** between the two calls. Read the logic as three English sentences:
1. "To move n disks from A to C, first move the top n−1 disks from A to B, using C as scratch space."
2. "Now the largest disk is alone — move it from A to C."
3. "Now move those n−1 disks from B to C, using A as scratch space."

That's it. Three lines of code for a problem that looks impossibly complex. **This is recursion's real superpower: it lets you express a solution you couldn't possibly write iteratively without pain.** The move count is `T(n) = 2T(n-1) + 1 = 2^n - 1` — provably optimal, and exponential, which is fine because the *output* is exponentially large.

## 4.8 Complexity Analysis

The universal method: **`Total time = (number of nodes in the recursion tree) × (work per node)`** and **`Space = (maximum depth) × (frame size)`**.

| Function | Time | Space | Reasoning |
|---|---|---|---|
| `factorial(n)` | O(n) | O(n) | n calls, O(1) each; n frames alive at max depth. |
| naive `fib(n)` | O(2^n) | O(n) | ~2^n nodes; depth only n because branches run sequentially. |
| memoized `fib(n)` | O(n) | O(n) | Each of n values computed once; memo array + stack. |
| `power(x,n)` | O(log n) | O(log n) | n halves each call → log n depth, 1 call per level. |
| `subsets(n)` | O(n · 2^n) | O(n) stack + O(n·2^n) output | 2^n subsets, each costing O(n) to copy. |
| `gcd(a,b)` | O(log min(a,b)) | O(log min) | Worst case is consecutive Fibonacci numbers. |
| `hanoi(n)` | O(2^n) | O(n) | 2^n − 1 moves; depth n. |

**Two things people consistently get wrong:**

**(a) Space for branching recursion is DEPTH, not node count.** For naive `fib(n)`, the tree has 2^n nodes but space is only **O(n)** — because `fib(n-1)` completes entirely and pops all its frames *before* `fib(n-2)` is called. Only one root-to-leaf path is ever alive.

```
   At any instant, the live stack is ONE PATH down the tree:

           fib(5)     <- alive
          /
       fib(4)         <- alive
      /
   fib(3)             <- alive
   ...                   (everything to the right hasn't started;
                          everything to the left already finished and popped)
```

**(b) Output space is often separate from working space.** `subsets` uses O(n) stack but returns O(n·2^n) of data. Distinguish **auxiliary space** (what your algorithm needs) from **output space** (what the problem demands). If asked "space complexity", clarify which — that question itself impresses.

## 4.9 Common Mistakes

1. **No base case, or an unreachable one.** `if (n == 0)` with `n` decreasing by 2 from an odd start → skips 0 forever.
2. **Not making progress.** `f(n)` calling `f(n)` — instant overflow.
3. **Calling the recursion twice instead of storing it** — §4.7, `power`. Silently converts O(log n) into O(n), or O(n) into O(2^n).
4. **Forgetting to backtrack** — polluted results across sibling branches.
5. **Adding a reference instead of a snapshot** — the empty-lists bug.
6. **A sentinel that's a legal answer** — `memo[n] != 0` when 0 is valid.
7. **Assuming Java optimises tail calls.** It does not. Depth still costs frames.
8. **`-n` on `Integer.MIN_VALUE`** — overflow, infinite recursion.
9. **Mutating shared state without restoring it** — a `visited` array set on the way down and never cleared, when the problem needs it cleared per-path.
10. **Trying to trace 5 levels deep mentally.** Trust the leap of faith. Verify with the base case and one level of the recursive case; that's what induction requires.

## 4.10 Interview Perspective

**Recursion is the gateway skill.** Trees, graphs, backtracking, divide-and-conquer, and all of DP are recursion wearing different hats. Interviewers know that a candidate who is fluent in recursion will pick up the rest fast, and one who isn't will struggle with half the question bank. So they test it deliberately, often through a tree or subset problem.

**What they're watching for:**

1. **Do you state the base case first?** Say "base case: when the index reaches the end, I'm done." Then write it. Then the recursive case.
2. **Can you justify correctness without tracing?** "Assume `subsets(idx+1)` correctly returns all subsets of the remaining elements. Then all subsets of the full array are exactly those, plus those with `nums[idx]` added." That's an induction argument, delivered in one sentence.
3. **Do you spot repeated subproblems?** The moment you draw a recursion tree with a duplicated node, say "there are overlapping subproblems here, so I'll memoize." That transition — brute-force recursion → memoized recursion → tabulation — *is* the DP interview.
4. **Can you convert to iterative when asked?** Have the answer ready: "linear recursion becomes a loop with an accumulator; tree recursion becomes a loop with an explicit `ArrayDeque` as a stack."
5. **Do you analyse the recursion tree, or guess?** Draw it. Count nodes per level. Multiply by work per node. Always.

**The mandatory habit: draw the recursion tree on the whiteboard.** Not because you need it — because it makes your reasoning visible, catches your own errors, and lets the interviewer follow you. Candidates who draw the tree get credit even when their code has a typo. Candidates who write code silently get penalised even when it's correct.

**The two follow-ups you will always get.** Prepare them:
- *"What's the space complexity?"* → "O(depth) for the call stack, which here is O(n)/O(log n) because..."
- *"Can you do it without recursion?"* → "Yes, with an explicit stack; the frames become objects I push manually. Same complexity, no `StackOverflowError` risk."

## 4.11 Practice Problems

### Easy — Reverse a String Recursively
Return the reverse of a string using recursion. State the base case and the depth.
```
"abc" -> "cba"
""    -> ""
```

### Medium — Generate All Valid Parentheses
Given `n` pairs of parentheses, generate all well-formed combinations.
```
n = 3 -> ["((()))","(()())","(())()","()(())","()()()"]
```

### Hard — Word Search in a Grid
Given a `char[][] board` and a `String word`, return true if the word can be built from sequentially adjacent cells (horizontally or vertically). **The same cell may not be used twice.**
```
board = [["A","B","C","E"],
         ["S","F","C","S"],
         ["A","D","E","E"]]
word = "ABCCED" -> true
word = "SEE"    -> true
word = "ABCB"   -> false   (would reuse the B)
```

## 4.12 Solution Walkthrough

### Easy — Reverse a String Recursively

**Three questions.**
1. Smallest input answerable instantly? A string of length 0 or 1 is its own reverse.
2. If I could reverse a smaller string, how do I build my answer? `reverse("abc")` = `reverse("bc")` + `"a"`. Peel off the first character and stick it on the **end** of the reversed rest.
3. Does it shrink? Yes — one character per call.

```java
public String reverse(String s) {
    if (s == null || s.length() <= 1) return s;      // base case
    return reverse(s.substring(1)) + s.charAt(0);    // recursive case
}
```

**Dry run on `"abc"`:**
```
reverse("abc") = reverse("bc") + 'a'
                     |
                 reverse("bc") = reverse("c") + 'b'
                                     |
                                 reverse("c") -> length 1 -> BASE, returns "c"
                                     |
                 reverse("bc") = "c" + 'b' = "cb"
                     |
reverse("abc") = "cb" + 'a' = "cba"   ✓
```

**Now the critical follow-up — and this is why I chose this problem.** What's the complexity?

Beginners say O(n). **It's O(n²).** Two reasons compounding:
- `s.substring(1)` **copies** n−1 characters (§3.3). Called at every level.
- `+` allocates a new string of growing length at every level.

Total: `n + (n-1) + ... + 1 = O(n²)` time and O(n²) allocation churn.

**The fix — recurse over indices on a `char[]`, never allocating:**
```java
public String reverse(String s) {
    if (s == null) return null;
    char[] c = s.toCharArray();
    reverseHelper(c, 0, c.length - 1);
    return new String(c);
}
private void reverseHelper(char[] c, int lo, int hi) {
    if (lo >= hi) return;                  // base: pointers met or crossed
    char t = c[lo]; c[lo] = c[hi]; c[hi] = t;
    reverseHelper(c, lo + 1, hi - 1);      // tail position
}
```
**O(n) time, O(n) space** (the char array; the stack is O(n/2) = O(n)). And since the recursive call is in tail position, this converts directly to the `while (lo < hi)` loop from §3.4 — giving **O(1) auxiliary space** beyond the array.

**The lesson, which generalises far beyond this problem:** the recursion structure was fine both times. The *data handling* was what made version one quadratic. **Recurse over indices, not over copies.** Say this in an interview and you have shown you think about allocation, not just algorithms.

### Medium — Generate All Valid Parentheses

**The naive idea:** generate all 2^(2n) strings of brackets and filter the valid ones. For n=3 that's 64 candidates for 5 answers. Wasteful — and it gets exponentially worse.

**The insight: prune invalid branches at the moment they become invalid.** Don't generate then filter; **refuse to generate garbage in the first place.** This is the essence of backtracking.

What makes a bracket string valid? Two conditions, and they're both *local*:
```
   1. You may add '(' only if you haven't used all n of them.
   2. You may add ')' only if there is an unmatched '(' waiting for it.
```

Condition 2 is the key. Track how many `(` and `)` we've placed:
```
   open  = number of '(' placed
   close = number of ')' placed

   Can add '('?  ->  open < n
   Can add ')'?  ->  close < open      <-- this is the pruning rule
```

`close < open` means "there's at least one unmatched open bracket." If `close == open`, everything is balanced and adding `)` would make it invalid immediately.

```java
public List<String> generateParenthesis(int n) {
    List<String> out = new ArrayList<>();
    if (n <= 0) return out;
    backtrack(new StringBuilder(), 0, 0, n, out);
    return out;
}

private void backtrack(StringBuilder sb, int open, int close, int n, List<String> out) {
    if (sb.length() == 2 * n) {           // base case: complete string
        out.add(sb.toString());           // toString() is already a snapshot
        return;
    }
    if (open < n) {                       // choice 1: add '('
        sb.append('(');
        backtrack(sb, open + 1, close, n, out);
        sb.deleteCharAt(sb.length() - 1); // BACKTRACK
    }
    if (close < open) {                   // choice 2: add ')'
        sb.append(')');
        backtrack(sb, open, close + 1, n, out);
        sb.deleteCharAt(sb.length() - 1); // BACKTRACK
    }
}
```

**Dry run for n = 2.** The full tree, showing pruned branches:

```
                              ""  (open=0, close=0)
                            /              \
              add '(' OK   /                \  add ')' ? close(0) < open(0)? NO -> PRUNED
                          /                     (this entire subtree never explored)
                     "("  (1,0)
                    /            \
      open<2? YES  /              \  close(0) < open(1)? YES
                  /                \
            "(("  (2,0)          "()"  (1,1)
                 |                    |         \
   open<2? 2<2 NO -> can't add '('    |          \ close(1)<open(1)? NO -> PRUNED
   close(0)<open(2)? YES              |
                 |          open<2? YES
            "(()" (2,1)               |
                 |                 "()(" (2,1)
   close(1)<open(2)? YES              |
                 |          close(1)<open(2)? YES
           "(())" (2,2)                |
           length == 4 -> ADD       "()()" (2,2)
                                    length == 4 -> ADD

Result: ["(())", "()()"]   ✓  (Catalan number C(2) = 2)
```

**Look at what the pruning bought us.** The full binary tree of depth 4 has 16 leaves. We visited a handful of nodes and produced exactly 2 answers, with **zero invalid strings ever constructed.** That's the difference between generate-and-filter and backtracking.

**Three implementation notes:**

**`out.add(sb.toString())`** — `toString()` creates a new immutable String, so this *is* a snapshot. No `new ArrayList<>(...)` needed here, unlike the `subsets` case. Understanding *why the snapshot is automatic here* (immutability) but *manual there* (mutable list) shows real command of the pattern.

**`sb.deleteCharAt(sb.length() - 1)`** — the backtrack. `StringBuilder` is mutable and shared across all frames, so we must restore it. Note we could instead pass `sb.toString() + "("` and skip backtracking — but that allocates at every node, turning this into the O(n²) mistake from the previous problem. **Mutate-and-restore is the efficient pattern.**

**Why no explicit validity check?** Because the two `if` guards make invalid states **unreachable**. There is nothing to check. This is the ideal form of backtracking: the constraints live in the branch conditions, not in a validation step. Point this out in an interview.

**Complexity.** The number of valid strings is the nth **Catalan number**, `C(n) = (1/(n+1))·C(2n,n) ≈ 4^n / (n^1.5·√π)`. Each costs O(n) to build and copy. → **O(4^n / √n) time**. Space: O(n) for the stack and builder, plus the output. Don't panic about the ugly bound — the honest interview answer is: *"The output size is the nth Catalan number, roughly 4^n/n^1.5, and each string costs O(n) to emit, so that's the lower bound too. This algorithm is output-optimal — it does O(n) work per result and never explores a dead branch."* **"Output-optimal"** is the phrase you want.

### Hard — Word Search in a Grid

This is DFS with backtracking on a 2D grid — the pattern behind dozens of interview questions (islands, flood fill, path counting, maze solving). Learn it properly here.

**The structure.** For each cell, try starting the word there. From a cell, if the character matches, recurse into the four neighbours looking for the *next* character.

**The hard part is the "can't reuse a cell" constraint.** We need a `visited` marker that is set on the way down and **cleared on the way up** — because a cell used in one path must be free for a different path.

```java
public boolean exist(char[][] board, String word) {
    if (board == null || board.length == 0 || word == null || word.isEmpty()) return false;
    int rows = board.length, cols = board[0].length;
    if (word.length() > rows * cols) return false;              // cheap impossibility check

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (dfs(board, word, r, c, 0)) return true;
        }
    }
    return false;
}

private boolean dfs(char[][] board, String word, int r, int c, int idx) {
    if (idx == word.length()) return true;                      // matched everything

    if (r < 0 || r >= board.length || c < 0 || c >= board[0].length) return false;  // off-grid
    if (board[r][c] != word.charAt(idx)) return false;           // char mismatch

    char original = board[r][c];
    board[r][c] = '#';                                           // MARK as visited

    boolean found = dfs(board, word, r + 1, c, idx + 1)
                 || dfs(board, word, r - 1, c, idx + 1)
                 || dfs(board, word, r, c + 1, idx + 1)
                 || dfs(board, word, r, c - 1, idx + 1);

    board[r][c] = original;                                      // UNMARK (backtrack)
    return found;
}
```

**Dry run: `word = "ABCCED"` on the sample board.** Let me trace the successful path.

```
   board:        c=0  c=1  c=2  c=3
          r=0:    A    B    C    E
          r=1:    S    F    C    S
          r=2:    A    D    E    E

Outer loop tries (0,0) first.

dfs(0,0, idx=0): board[0][0]='A', word[0]='A'  MATCH
                 mark (0,0) as '#'
                 grid:  #  B  C  E
                        S  F  C  S
                        A  D  E  E
   try DOWN (1,0), idx=1: board[1][0]='S', word[1]='B'. MISMATCH -> false
   try UP   (-1,0):       out of bounds -> false
   try RIGHT(0,1), idx=1: board[0][1]='B', word[1]='B'  MATCH
                          mark (0,1)
                          grid:  #  #  C  E
                                 S  F  C  S
                                 A  D  E  E
        try DOWN (1,1), idx=2: 'F' vs 'C'. MISMATCH
        try UP   (-1,1):       out of bounds
        try RIGHT(0,2), idx=2: 'C' vs 'C'  MATCH
                               mark (0,2)
                               grid:  #  #  #  E
                                      S  F  C  S
                                      A  D  E  E
             try DOWN (1,2), idx=3: 'C' vs 'C'  MATCH
                                    mark (1,2)
                                    grid:  #  #  #  E
                                           S  F  #  S
                                           A  D  E  E
                  try DOWN (2,2), idx=4: 'E' vs 'E'  MATCH
                                         mark (2,2)
                       try DOWN (3,2): out of bounds
                       try UP   (1,2): board[1][2] is '#' != 'D'. MISMATCH
                                       ^^^ THE MARK IS DOING ITS JOB — it blocks reuse
                       try RIGHT(2,3), idx=5: 'E' vs 'D'. MISMATCH
                       try LEFT (2,1), idx=5: 'D' vs 'D'  MATCH
                                              mark (2,1)
                            dfs(..., idx=6): idx == word.length()  ->  TRUE
                            unmark (2,1), return true
                       -> true propagates up
                  unmark (2,2), return true
             unmark (1,2), return true
        unmark (0,2), return true
   unmark (0,1), return true
unmark (0,0), return true

Result: true. Path found: A(0,0) -> B(0,1) -> C(0,2) -> C(1,2) -> E(2,2) -> D(2,1)
```

**Four things to notice, each an interview talking point:**

**1. `board[r][c] = '#'` — marking in the input instead of a separate `visited` array.** This is the **O(1) extra space** trick: we borrow the input as our bookkeeping and restore it afterward. Since `'#'` can never equal a letter in `word`, the mismatch check doubles as the visited check. Two purposes, one comparison. If the interviewer says the input must not be mutated, use `boolean[][] visited` — O(m·n) space but non-destructive. **Offer both and let them choose.**

**2. `board[r][c] = original;` — the unmark is mandatory.** Watch what breaks without it: after failing to find `"ABCB"` starting at (0,0), the cells stay marked as `'#'`, and every subsequent start position sees a corrupted board. The **invariant to state out loud** is: *"every call to `dfs` leaves the board exactly as it found it."*

**3. Short-circuit `||` is doing real work.** Java's `||` doesn't evaluate the right side if the left is true. So the moment one direction succeeds, the other three recursive calls are **never made**. That's automatic pruning — we stop searching as soon as we have an answer. Writing this with four separate `if (dfs(...)) return true;` statements is equivalent; the `||` chain is just more compact.

**4. The base case is checked BEFORE the bounds check.** `if (idx == word.length()) return true;` comes first. This matters: if the last character of the word sits at the grid edge, the recursive call goes out of bounds — but we return `true` before ever looking at `r` and `c`. Order the guards so success is detected before failure conditions are evaluated. Reversing these two lines is a real bug that only appears on edge cells.

**Complexity.**
- **Time:** we try each of `m·n` starting cells. From each, the search branches into at most 4 directions, but never backward (that cell is marked), so effectively **3 choices per step**, to depth `L = word.length()`. → **O(m · n · 3^L)** worst case.
- **Space:** **O(L)** for the recursion stack. The `'#'` marking is in-place, so no extra grid. (With a `visited` array it's O(m·n).)

**Why the bound is loose in practice:** the character-mismatch check prunes almost immediately. Real inputs run vastly faster than 3^L. Saying "the worst case is O(m·n·3^L), but the character check prunes so aggressively that typical performance is far better" is exactly the kind of nuanced complexity statement that distinguishes a strong candidate.

**The grid-DFS template to memorise** — you will reuse this verbatim:
```
dfs(r, c, state):
    if (goal reached)            return SUCCESS
    if (out of bounds)           return FAIL
    if (already visited)         return FAIL
    if (this cell doesn't fit)   return FAIL

    MARK (r, c)
    result = dfs(r+1,c) || dfs(r-1,c) || dfs(r,c+1) || dfs(r,c-1)
    UNMARK (r, c)                       // only if paths must be independent
    return result
```
Note the last comment: for *path* problems (like this one) you unmark. For *connected-component* problems (counting islands), you **don't** unmark — a visited cell should stay visited forever. **Knowing when to unmark is the single most important judgement call in grid DFS.**

---
---
