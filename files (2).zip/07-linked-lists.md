*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 7 — Linked Lists

## 7.1 Intuition

An array is a row of adjacent mailboxes. **A linked list is a treasure hunt.**

Each clue tells you where the next clue is. The clues can be scattered anywhere in the house — under the sofa, in the fridge, in the garden. There is no formula that gets you to clue #7. You must follow clues 1 through 6 first.

```
   ARRAY:  everything adjacent, position computable
   
   +----+----+----+----+
   | 10 | 20 | 30 | 40 |     arr[2]?  base + 2*4.  ONE STEP.
   +----+----+----+----+
   1000 1004 1008 1012


   LINKED LIST: everything scattered, position must be WALKED
   
   head
    |
    v
   +----+------+        +----+------+        +----+------+
   | 10 | 0x88 |------->| 20 | 0x14 |------->| 30 | null |
   +----+------+        +----+------+        +----+------+
   at 0x40               at 0x88              at 0x14
   
   node #2?  start at head, follow 2 pointers.  TWO STEPS.
   node #1000? follow 1000 pointers.
```

**So the linked list is worse. Why does it exist?**

Because of what the treasure hunt makes *easy*. To insert a new clue between clue 1 and clue 2, you don't move anything. You just rewrite two slips of paper:

```
   BEFORE:  [10] --------------------> [20] --> [30]

   INSERT 15 between them:

   Step 1: new node points to 20
            [15] ---> [20]
   Step 2: 10 points to 15
            [10] ---> [15] ---> [20] ---> [30]
            
   TOTAL WORK: two pointer assignments. O(1). Nothing moved.
```

Compare with the array (Module 2, §2.4), which had to shift every subsequent element. **That is the entire trade:**

```
   ARRAY:        O(1) access,  O(n) insert/delete in the middle
   LINKED LIST:  O(n) access,  O(1) insert/delete GIVEN A POINTER to the position
```

Read that last clause carefully — **"given a pointer to the position."** It's the caveat that catches everyone. Deleting the 500th node is O(n), because *finding* it is O(n). Only the pointer rewiring is O(1). Interviewers probe this constantly.

## 7.2 Mental Model

**Model 1 — "A linked list IS its head pointer."**

There is no list object. There is no length field. A linked list is a single reference to a first node, and each node knows only its successor. Lose the head and the entire list is unreachable garbage.

```java
Node head = ...;   // THIS variable is the list. That's all there is.
```

**Model 2 — "Draw the boxes and arrows. Always. Every time."**

I am completely serious about this. Linked list problems are pointer-rewiring puzzles, and pointer-rewiring puzzles are impossible to hold in your head and trivial on paper. In an interview, draw four nodes and physically redraw the arrows for each line of code you write. Candidates who draw solve these problems; candidates who don't produce off-by-one pointer bugs and lose the thread.

**Model 3 — "Order of assignment is everything."**

```java
// WRONG — you just leaked the rest of the list
prev.next = newNode;        // prev's old successor is now unreachable
newNode.next = prev.next;   // ...and this now points newNode at ITSELF

// RIGHT — attach forward first, then attach backward
newNode.next = prev.next;   // newNode now knows the rest of the list
prev.next = newNode;        // NOW it's safe to overwrite prev.next
```

**The universal rule: before you overwrite a pointer, make sure something else still points at what it pointed to.** This is the same "copy away from the direction you're moving" principle as array shifting (§2.4), and it is the single most common linked-list bug.

**Model 4 — "Almost every linked list problem is solved by one of five techniques."**
```
   1. Dummy head node       -> eliminates all "what if it's the first node?" cases
   2. Two pointers, offset  -> nth from end, middle of list
   3. Two pointers, speed   -> cycle detection (Floyd's tortoise & hare)
   4. Three-pointer walk    -> in-place reversal (prev, curr, next)
   5. Recursion             -> natural, since a list IS a node plus a smaller list
```
Learn these five and you can solve virtually any linked list interview question. We'll build all five.

## 7.3 Internal Working — memory, and why linked lists are slower than the math suggests

### What a node actually costs in Java

```java
class Node {
    int val;
    Node next;
}
```

That looks like 4 bytes of data plus an 8-byte pointer. Here's the reality on a 64-bit HotSpot JVM with compressed oops:

```
   +--------------------------------------+
   |  Mark word            8 bytes        |  GC state, hash, lock bits
   |  Class pointer        4 bytes        |  (compressed)
   |  int val              4 bytes        |  <-- THE ACTUAL DATA
   |  Node next            4 bytes        |  (compressed reference)
   +--------------------------------------+
   |  TOTAL: 20 bytes -> padded to 24     |  (8-byte alignment)
   +--------------------------------------+

   4 bytes of payload in a 24-byte object.  ~17% efficiency.
   
   Compare:  int[] of n elements = 16 bytes header + 4n bytes payload.
             For n = 1000:  4016 bytes.
             LinkedList of 1000 ints: 24,000 bytes + boxing if Integer.
             SIX TIMES the memory. And that's before boxing.
```

### The real killer: cache locality

This is the part that textbooks skip and that separates people who have measured things from people who have only read about them.

```
   ARRAY in memory (one contiguous block):
   
   [10][20][30][40][50][60][70][80][90][A0][B0][C0][D0][E0][F0][100]
   |<---------------- one 64-byte cache line ------------------>|
   
   Reading arr[0] pulls SIXTEEN ints into cache for free.
   The CPU prefetcher then speculatively loads the NEXT line.
   Iterating an array is essentially free after the first miss.


   LINKED LIST in memory (nodes allocated at different times, scattered by GC):
   
   [node3]......[node1]...........[node5]...[node2]......[node4]
      ^            ^                 ^         ^            ^
   Reading node1 pulls in node1's cache line — which contains
   nothing else useful. Following .next JUMPS to a different line.
   
   EVERY step is potentially a cache miss (~100-300 CPU cycles).
   The prefetcher CANNOT help: it cannot predict where .next points
   until it has already loaded the current node.
```

**The practical consequence:** iterating a `LinkedList<Integer>` of a million elements can be **10 to 50 times slower** than iterating an `int[]` of the same size, despite both being O(n). Same complexity class, wildly different wall-clock time.

**This is why `LinkedList` is almost never the right choice in production Java.** Even for "many insertions in the middle," `ArrayList` usually wins, because `System.arraycopy` is a vectorised block move that the hardware loves, while `LinkedList` pays a cache miss per node *just to find the insertion point*.

**What to say in an interview:** *"Asymptotically, LinkedList gives O(1) insertion at a known position versus ArrayList's O(n). But in practice ArrayList almost always wins, because finding the position is O(n) anyway, and the O(n) shift is a cache-friendly block copy while the O(n) traversal is a chain of cache misses. I'd use ArrayDeque over LinkedList for queue/deque behaviour, and I'd only reach for a linked structure when I already hold node references — like an LRU cache, where the HashMap gives me O(1) access to the node."*

That answer is honest, specific, and reflects real engineering. It's a genuinely strong thing to say.

### Where linked lists genuinely win

1. **LRU cache** — `HashMap<K, Node>` + doubly linked list. The map gives O(1) node lookup, so the O(1) unlink/relink is *actually* O(1). This is the canonical correct use, and it's a top interview question.
2. **Anything where you already hold the node.** Java's own `LinkedHashMap`, iterator-based removal, intrusive lists in kernels.
3. **You must never invalidate references.** An `ArrayList` resize moves all the data; a linked list's nodes never move addresses. Critical for structures holding external pointers.
4. **Splicing whole sublists in O(1).** Concatenating two linked lists is one pointer assignment; concatenating two arrays is O(n).
5. **Unknown, unbounded growth with no resize spikes.** An `ArrayList` growing to 1 GB momentarily needs 2.5 GB (§2.6). A linked list never does.

## 7.4 Visual Explanation — the four core operations

### Traversal

```
   head
    |
    v
   +----+---+     +----+---+     +----+------+
   | 10 | *-|---->| 20 | *-|---->| 30 | null |
   +----+---+     +----+---+     +----+------+
    ^
   curr           curr           curr           curr = null -> STOP

   Node curr = head;
   while (curr != null) { visit(curr.val); curr = curr.next; }
   
   Explaining every arrow:
     head -> node(10)      the list's single entry point
     node(10).next -> node(20)   the '*' box holds the ADDRESS of node(20)
     node(30).next = null        null is the TERMINATOR. It means "no successor."
                                 Every singly linked list ends in null.
```

### Insert at head — O(1)

```
   BEFORE:
   head ---> [10] ---> [20] ---> null

   Step 1: create the node, point it at the current head
           [5] ---> [10] ---> [20] ---> null
            ^
           newNode                    (head still points at 10)

   Step 2: move head
   head ---> [5] ---> [10] ---> [20] ---> null

   CODE:
     Node n = new Node(5);
     n.next = head;      // FORWARD link first
     head = n;           // THEN move head
   
   Reverse those two lines and n.next points at itself -> infinite list.
```

### Insert after a given node — O(1)

```
   BEFORE:
   ... ---> [10] ---> [20] ---> ...
             ^
            prev

   Step 1: newNode.next = prev.next     (grab the rest of the list FIRST)
   
             [10] ---> [20] ---> ...
                        ^
             [15] ------+
              ^
             newNode

   Step 2: prev.next = newNode
   
   ... ---> [10] ---> [15] ---> [20] ---> ...
   
   Two assignments. O(1). Nothing else in the list was touched.
```

### Delete a node — O(1) given prev

```
   BEFORE:
   ... ---> [10] ---> [20] ---> [30] ---> ...
             ^         ^
            prev     target

   Step 1: prev.next = target.next
   
             [10] --------------> [30] ---> ...
                       [20] ---> [30]
                        ^ still points forward, but NOTHING points AT it
                          -> unreachable -> eligible for GC

   Step 2 (good hygiene): target.next = null
             Breaks the outgoing link too. Prevents the deleted node from
             keeping [30] and everything after it alive if some external
             reference to [20] still exists. This is a real memory-leak
             prevention step; java.util.LinkedList does exactly this.

   AFTER:
   ... ---> [10] ---> [30] ---> ...
```

**Notice what's missing: no shifting.** Deleting from the middle of an array moves every subsequent element. Deleting from a linked list moves nothing.

## 7.5 Step-by-Step Dry Run — reversing a singly linked list

This is *the* fundamental linked-list operation. Every interview touches it. Let's trace it with total precision.

```java
Node reverse(Node head) {
    Node prev = null;
    Node curr = head;
    while (curr != null) {
        Node next = curr.next;   // 1. SAVE the rest before we destroy the link
        curr.next = prev;        // 2. REVERSE this node's pointer
        prev = curr;             // 3. ADVANCE prev
        curr = next;             // 4. ADVANCE curr
    }
    return prev;                 // prev is the new head
}
```

**Trace on `1 -> 2 -> 3 -> null`:**

```
INITIAL STATE
   prev = null
   curr -> [1] -> [2] -> [3] -> null
   
   null      [1] ---> [2] ---> [3] ---> null
    ^         ^
   prev     curr


=== ITERATION 1 ===
 Line 1:  next = curr.next  ->  next points at [2]
          
          null      [1] ---> [2] ---> [3] ---> null
           ^         ^        ^
          prev     curr     next

 Line 2:  curr.next = prev  ->  [1].next = null
          
          null <--- [1]      [2] ---> [3] ---> null
           ^         ^        ^
          prev     curr     next
          
          [1] is now DETACHED from [2]. This is why we saved 'next' first!
          Without line 1, we would have lost [2] and everything after it.

 Line 3:  prev = curr  ->  prev points at [1]
 Line 4:  curr = next  ->  curr points at [2]
 
          null <--- [1]      [2] ---> [3] ---> null
                     ^        ^
                    prev     curr
          
          Reversed portion: [1] -> null
          Remaining portion: [2] -> [3] -> null


=== ITERATION 2 ===
 Line 1:  next = curr.next  ->  next points at [3]
 
          null <--- [1]      [2] ---> [3] ---> null
                     ^        ^        ^
                    prev     curr     next

 Line 2:  curr.next = prev  ->  [2].next = [1]
 
          null <--- [1] <--- [2]      [3] ---> null
                     ^        ^        ^
                    prev     curr     next

 Line 3-4: prev -> [2],  curr -> [3]
 
          null <--- [1] <--- [2]      [3] ---> null
                              ^        ^
                             prev     curr
          
          Reversed: [2] -> [1] -> null
          Remaining: [3] -> null


=== ITERATION 3 ===
 Line 1:  next = curr.next  ->  next = null
 Line 2:  curr.next = prev  ->  [3].next = [2]
 
          null <--- [1] <--- [2] <--- [3]
                              ^        ^
                             prev     curr    next = null

 Line 3-4: prev -> [3],  curr -> null
 
          null <--- [1] <--- [2] <--- [3]
                                       ^
                                      prev      curr = null


=== LOOP CONDITION: curr == null  ->  EXIT ===

 return prev  ->  returns [3]

FINAL LIST:  [3] ---> [2] ---> [1] ---> null    ✓
```

**Three things to burn in:**

1. **`next` must be saved before `curr.next` is overwritten.** Line 2 destroys the only link to the rest of the list. Line 1 is the insurance. Swap lines 1 and 2 and you lose the entire tail on the first iteration.

2. **Return `prev`, not `curr`.** When the loop exits, `curr` is `null` and `prev` points at the last node processed — which is the *original* tail, i.e. the *new* head. Returning `curr` returns null and the classic "my reverse returns an empty list" bug.

3. **The invariant** (say this in interviews): *"At the top of each iteration, `prev` is the head of the fully reversed prefix, and `curr` is the head of the untouched suffix."* State the invariant and the code writes itself.

**The recursive version, for contrast:**

```java
Node reverseRecursive(Node head) {
    if (head == null || head.next == null) return head;   // base: 0 or 1 node
    Node newHead = reverseRecursive(head.next);            // reverse the REST
    head.next.next = head;                                 // make the next node point back
    head.next = null;                                      // sever the forward link
    return newHead;                                        // propagate the new head up
}
```

The pivotal line is `head.next.next = head;`. Read it as: *"my successor's successor should be me."* On the way back up the stack, `head.next` is still the old successor (we haven't touched it), and after the recursive call it is the *tail* of the reversed sublist — so appending `head` after it is exactly right.

```
   reverseRecursive([1,2,3]):
     recurse on [2,3]:
       recurse on [3]:  base case, return [3]
       head=[2], head.next=[3].  [3].next = [2].  [2].next = null.
       list is now: [3] -> [2] -> null.  return [3]
     head=[1], head.next=[2].  [2].next = [1].  [1].next = null.
     list is now: [3] -> [2] -> [1] -> null.  return [3]
```

**Iterative: O(n) time, O(1) space. Recursive: O(n) time, O(n) stack space.** In an interview, write the iterative version and *mention* the recursive one. The iterative version is strictly better here, and choosing the better of two correct solutions is the signal.

## 7.6 Java Implementation

### Singly linked list

```java
package com.dsa.linkedlist;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringJoiner;

/** A singly linked list with a size field and tail pointer for O(1) append. */
public final class SinglyLinkedList<T> implements Iterable<T> {

    /** Static nested class: does NOT hold a reference to the outer instance. */
    private static final class Node<T> {
        T val;
        Node<T> next;
        Node(T val, Node<T> next) { this.val = val; this.next = next; }
    }

    private Node<T> head;
    private Node<T> tail;          // enables O(1) addLast
    private int size;
    private int modCount;          // for fail-fast iteration

    // ---------- O(1) operations ----------

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    /** Insert at the front. O(1). */
    public void addFirst(T val) {
        Node<T> n = new Node<>(val, head);   // forward link set in the constructor
        head = n;
        if (tail == null) tail = n;          // first element: head AND tail
        size++;
        modCount++;
    }

    /** Append. O(1) thanks to the tail pointer. */
    public void addLast(T val) {
        Node<T> n = new Node<>(val, null);
        if (tail == null) {
            head = tail = n;                 // empty list
        } else {
            tail.next = n;
            tail = n;
        }
        size++;
        modCount++;
    }

    /** Remove and return the front element. O(1). */
    public T removeFirst() {
        if (head == null) throw new NoSuchElementException("list is empty");
        Node<T> old = head;
        head = head.next;
        old.next = null;                     // help GC; avoid stale outgoing links
        if (head == null) tail = null;       // list became empty
        size--;
        modCount++;
        return old.val;
    }

    public T getFirst() {
        if (head == null) throw new NoSuchElementException("list is empty");
        return head.val;
    }

    // ---------- O(n) operations ----------

    /** Insert at an arbitrary index. O(n). */
    public void add(int index, T val) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
        if (index == 0)    { addFirst(val); return; }
        if (index == size) { addLast(val);  return; }

        Node<T> prev = nodeAt(index - 1);
        prev.next = new Node<>(val, prev.next);   // forward link, then backward
        size++;
        modCount++;
    }

    /** Remove by index. O(n). */
    public T remove(int index) {
        checkIndex(index);
        if (index == 0) return removeFirst();

        Node<T> prev = nodeAt(index - 1);
        Node<T> target = prev.next;
        prev.next = target.next;
        if (target == tail) tail = prev;      // deleted the last node
        target.next = null;
        size--;
        modCount++;
        return target.val;
    }

    public T get(int index) {
        checkIndex(index);
        return nodeAt(index).val;
    }

    /** Reverse in place, iteratively. O(n) time, O(1) space. */
    public void reverse() {
        Node<T> prev = null, curr = head;
        tail = head;                          // the old head becomes the new tail
        while (curr != null) {
            Node<T> next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        head = prev;
        modCount++;
    }

    // ---------- internals ----------

    private Node<T> nodeAt(int index) {
        Node<T> curr = head;
        for (int i = 0; i < index; i++) curr = curr.next;
        return curr;
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index + ", size: " + size);
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> curr = head;
            private final int expectedModCount = modCount;

            @Override public boolean hasNext() { return curr != null; }
            @Override public T next() {
                if (modCount != expectedModCount) {
                    throw new java.util.ConcurrentModificationException();
                }
                if (curr == null) throw new NoSuchElementException();
                T v = curr.val;
                curr = curr.next;
                return v;
            }
        };
    }

    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(" -> ", "[", " -> null]");
        for (T v : this) sj.add(String.valueOf(v));
        return size == 0 ? "[]" : sj.toString();
    }
}
```

### Doubly linked list

```java
/** Doubly linked list with sentinel head and tail. Every operation is uniform. */
public final class DoublyLinkedList<T> implements Iterable<T> {

    private static final class Node<T> {
        T val;
        Node<T> prev, next;
        Node(T val) { this.val = val; }
    }

    private final Node<T> sentinelHead = new Node<>(null);   // never holds data
    private final Node<T> sentinelTail = new Node<>(null);   // never holds data
    private int size;

    public DoublyLinkedList() {
        sentinelHead.next = sentinelTail;
        sentinelTail.prev = sentinelHead;
    }

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    public void addFirst(T val) { insertAfter(sentinelHead, val); }
    public void addLast(T val)  { insertAfter(sentinelTail.prev, val); }

    /** Insert a new node immediately after 'prev'. O(1). Four pointer writes. */
    private void insertAfter(Node<T> prev, T val) {
        Node<T> next = prev.next;
        Node<T> n = new Node<>(val);
        n.prev = prev;          // 1
        n.next = next;          // 2
        prev.next = n;          // 3
        next.prev = n;          // 4
        size++;
    }

    /** Unlink a node. O(1) — no traversal, no null checks, thanks to sentinels. */
    private T unlink(Node<T> n) {
        n.prev.next = n.next;
        n.next.prev = n.prev;
        n.prev = n.next = null;         // help GC
        size--;
        return n.val;
    }

    public T removeFirst() {
        if (isEmpty()) throw new NoSuchElementException("list is empty");
        return unlink(sentinelHead.next);
    }

    public T removeLast() {
        if (isEmpty()) throw new NoSuchElementException("list is empty");
        return unlink(sentinelTail.prev);
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            private Node<T> curr = sentinelHead.next;
            @Override public boolean hasNext() { return curr != sentinelTail; }
            @Override public T next() {
                if (curr == sentinelTail) throw new NoSuchElementException();
                T v = curr.val;
                curr = curr.next;
                return v;
            }
        };
    }
}
```

### Circular linked list

```java
/** Circular singly linked list. Keeps only a 'tail' pointer — head is tail.next. */
public final class CircularLinkedList<T> {

    private static final class Node<T> {
        T val;
        Node<T> next;
        Node(T val) { this.val = val; }
    }

    private Node<T> tail;      // tail.next IS the head
    private int size;

    public int size()        { return size; }
    public boolean isEmpty() { return size == 0; }

    /** O(1). */
    public void addLast(T val) {
        Node<T> n = new Node<>(val);
        if (tail == null) {
            n.next = n;                 // single node points to ITSELF
            tail = n;
        } else {
            n.next = tail.next;         // new node points to the head
            tail.next = n;              // old tail points to the new node
            tail = n;                   // the new node becomes the tail
        }
        size++;
    }

    /**
     * O(1). Insert after tail WITHOUT moving tail — so the new node
     * becomes tail.next, which is the head. This is why we keep tail.
     */
    public void addFirst(T val) {
        Node<T> n = new Node<>(val);
        if (tail == null) {
            n.next = n;
            tail = n;
        } else {
            n.next = tail.next;         // point at the old head
            tail.next = n;              // tail now points at us -> we ARE the head
        }                               // tail deliberately UNCHANGED
        size++;
    }

    public T removeFirst() {
        if (tail == null) throw new NoSuchElementException("list is empty");
        Node<T> head = tail.next;
        if (head == tail) {              // exactly one node
            tail = null;
        } else {
            tail.next = head.next;
        }
        head.next = null;
        size--;
        return head.val;
    }

    /** Josephus-style rotation: advance the "start" position by one. O(1). */
    public void rotate() {
        if (tail != null) tail = tail.next;
    }

    /** Traversal MUST use a do-while or a counter — there is no null terminator. */
    @Override
    public String toString() {
        if (tail == null) return "[]";
        StringBuilder sb = new StringBuilder("[");
        Node<T> curr = tail.next;        // start at head
        do {
            sb.append(curr.val);
            curr = curr.next;
            if (curr != tail.next) sb.append(" -> ");
        } while (curr != tail.next);     // stop when we come back around
        return sb.append(" -> (back to head)]").toString();
    }
}
```

*(Note the asymmetry: `addLast` and `addFirst` share almost identical code and differ in exactly one line — whether `tail` moves. That is the whole trick, and it works because **on a singly linked circular list you can never step backward**, so any O(1) operation must be expressible as "insert after the node I already hold.")*

## 7.7 Line-by-Line Code Explanation

**`private static final class Node<T>`**

Three modifiers, three reasons:
- **`static`** — a *static* nested class does **not** hold an implicit reference to the enclosing `SinglyLinkedList` instance. A non-static inner class would add a hidden 4–8 byte field to every single node *and* keep the whole list alive as long as any node is referenced. For a class you allocate millions of, this matters enormously. **Always make node classes static.** This is a real, measurable Java memory bug and an excellent interview point.
- **`final`** — nobody subclasses a node.
- **`private`** — the node type is an implementation detail. Callers see only `T`.

**`Node(T val, Node<T> next) { ... }` — a two-arg constructor**

This lets us write `new Node<>(val, head)` in `addFirst`, which sets the forward link *at construction time*. That structurally eliminates the "wrong order of assignment" bug from §7.2 — you cannot forget to set `next` because the constructor demands it. **Designing the API so the bug is unrepresentable is better than remembering not to write the bug.**

**`private Node<T> tail;` — why keep a tail pointer**

Without it, `addLast` must walk the entire list to find the end: O(n). With it: O(1). The cost is that *every* structural operation must maintain it, and forgetting to update `tail` in one branch is the classic bug. Note the three places we handle it:
- `addFirst`: `if (tail == null) tail = n;` — the empty-list case.
- `removeFirst`: `if (head == null) tail = null;` — the became-empty case.
- `remove(index)`: `if (target == tail) tail = prev;` — deleted the last node.

Miss any one of those and you get a dangling `tail` that either points at a removed node or is null when it shouldn't be. **When an interviewer asks you to add a tail pointer, immediately enumerate these three cases out loud.**

**`private int size;`**

`java.util.LinkedList` keeps one too. Without it, `size()` is O(n). This is a pure space-for-time trade: 4 bytes for O(1) size queries. Note that `size` must be updated in *every* mutating method — another invariant to maintain.

**`old.next = null;` in `removeFirst`**

Not strictly necessary for correctness — the node is already unreachable from `head`. But if any external code still holds a reference to the removed node, that reference would keep the *entire remainder of the list* alive through `old.next`. Nulling it breaks the chain. `java.util.LinkedList.unlink()` does exactly this, with the comment "help GC". **This is a real memory-leak class**, and mentioning it demonstrates you think about object lifetimes.

**`if (index == 0) { addFirst(val); return; }` in `add(int, T)`**

The head is special because there is no `prev` node to rewire — we must modify the `head` field itself. Delegating to `addFirst` keeps the special case in exactly one place. (The sentinel/dummy-node technique in §7.9 removes this special case entirely; see the Medium problem.)

**`if (index < 0 || index > size)` — `>` not `>=`**

Same distinction as Module 2, §2.6: inserting *at* `size` means appending, which is legal. Reading at `size` is not. **This asymmetry between insert-bounds and access-bounds catches people constantly.**

**`prev.next = new Node<>(val, prev.next);` — a one-liner that's safe by construction**

Java evaluates the right-hand side first. So `prev.next` is read (giving the old successor) and passed to the constructor, and only *then* is `prev.next` assigned. The order-of-assignment hazard is gone. Elegant, and worth pointing out.

**`tail = head;` at the start of `reverse()`**

The old head becomes the new tail. Must be captured **before** the loop destroys the structure. Forgetting this leaves `tail` pointing at what is now the head — so the next `addLast` appends to the wrong end and silently corrupts the list. **A classic bug in "reverse an in-house list class."**

**`private int modCount;` and the iterator's `expectedModCount`**

The **fail-fast** pattern from the JDK. Every structural modification bumps `modCount`. The iterator snapshots it at creation and compares on every `next()`. If they diverge, someone modified the list during iteration and we throw `ConcurrentModificationException`.

Why bother? Because modifying a list while iterating it produces *undefined behaviour* — you might skip elements, see them twice, or follow a pointer into a removed node. **Failing loudly and immediately is vastly better than silently wrong results.** This is why `for (T x : list) list.remove(x);` throws instead of corrupting. Implementing `modCount` in your own collection is a strong signal of Java maturity.

### The sentinel technique in `DoublyLinkedList`

This is the most important design idea in the module, so let's be explicit.

**Without sentinels**, `insertAfter` needs branches:
```java
if (prev == null)      { /* inserting at head */ }
if (prev.next == null) { /* inserting at tail */ }
if (head == null)      { /* empty list */ }
```
Three special cases, each a place to write a bug.

**With sentinels**, the list is *never* empty:
```
   EMPTY list:
   
   [SH] <----> [ST]
    ^           ^
    sentinelHead, sentinelTail — permanent, never removed, hold no data


   After addLast(10), addLast(20):
   
   [SH] <----> [10] <----> [20] <----> [ST]
   
   Every real node ALWAYS has a non-null prev and a non-null next.
```

Now look at `unlink`:
```java
n.prev.next = n.next;
n.next.prev = n.prev;
```
**Two lines. Zero null checks. Zero special cases.** It works identically for the first node, the last node, and the only node — because `n.prev` and `n.next` are guaranteed non-null (worst case they're the sentinels).

Compare `java.util.LinkedList.unlink()`, which does *not* use sentinels and consequently needs:
```java
if (prev == null) first = next; else { prev.next = next; ... }
if (next == null) last = prev;  else { next.prev = prev; ... }
```
Four branches instead of two assignments.

**The cost:** two extra node objects, forever. **The benefit:** every operation loses its edge cases. For an LRU cache or any structure doing heavy unlinking, this is unambiguously worth it. **"I'd use sentinel nodes so that insertion and deletion have no special cases at the boundaries"** is one of the most efficient sentences you can say in a linked-list interview.

### Why `CircularLinkedList` keeps `tail`, not `head`

Counterintuitive at first, then obvious:
```
   Keep HEAD:  addFirst is O(1)  (head = new node)
               addLast  is O(n)  (must walk to find the last node)

   Keep TAIL:  head IS tail.next, so it's O(1) to reach
               addLast  is O(1)  (insert after tail, move tail)
               addFirst is O(1)  (insert after tail, DON'T move tail)
```
**Keeping `tail` gives O(1) at both ends with a single pointer.** That's the whole reason circular lists are used for round-robin schedulers and buffers.

**`n.next = n;` for the single-node case** — a one-element circular list points at itself. This is the base case that makes everything else uniform.

**`do { ... } while (curr != tail.next);` — you MUST use do-while**

A circular list has **no null terminator**. A `while (curr != head)` loop would exit immediately, because `curr` starts *at* head. The `do-while` guarantees at least one iteration before checking. **Forgetting this is either an infinite loop or a zero-iteration loop, and both are classic circular-list bugs.** The alternative is to iterate `size` times with a counter.

## 7.8 Complexity Analysis

| Operation | Singly | Doubly | Circular (tail-kept) | ArrayList |
|---|---|---|---|---|
| `get(i)` / random access | O(n) | O(n) | O(n) | **O(1)** |
| `addFirst` | **O(1)** | **O(1)** | **O(1)** | O(n) |
| `addLast` (with tail) | **O(1)** | **O(1)** | **O(1)** | **O(1)** amortized |
| `removeFirst` | **O(1)** | **O(1)** | **O(1)** | O(n) |
| `removeLast` | **O(n)** | **O(1)** | O(n) | **O(1)** |
| `add(i, x)` | O(n) | O(n) | O(n) | O(n) |
| Delete a node **given the node** | O(n)* | **O(1)** | O(n)* | O(n) |
| Search | O(n) | O(n) | O(n) | O(n) |
| Reverse | O(n), O(1) space | O(n) | O(n) | O(n) |
| Memory per element | ~24 B | ~32 B | ~24 B | ~4–16 B |

\* **The single most important cell in this table.** On a *singly* linked list, deleting a node you hold a pointer to is **O(n)**, not O(1) — because you need its **predecessor**, and finding that requires walking from the head. On a *doubly* linked list it's genuinely O(1), because `node.prev` is right there.

**This is exactly why `LinkedHashMap` and every LRU cache implementation use a doubly linked list.** Interviewers ask this specific question. Have the answer ready:

> *"Deleting a known node is O(1) on a doubly linked list and O(n) on a singly linked list, because the singly linked version has to find the predecessor. That's why LRU caches pair a HashMap with a doubly linked list — the map gives O(1) node lookup and the double links give O(1) unlinking."*

**`removeLast` on singly is O(n)** even with a tail pointer, for the same reason: after removing the tail you need to set `tail = secondToLast`, which requires a full traversal. Doubly linked: `tail.prev` — O(1).

## 7.9 Common Mistakes

1. **Wrong assignment order** — `prev.next = n; n.next = prev.next;` creates a self-loop and leaks the tail. §7.2.
2. **Losing the head** — reassigning `head` before saving it. The list becomes unreachable garbage.
3. **Not saving `next` before rewiring** in reverse. Loses the entire remainder.
4. **Returning `curr` instead of `prev`** from reverse. Returns null.
5. **Forgetting to update `tail`** in one of the three cases from §7.7.
6. **Forgetting to update `size`.**
7. **`while (curr.next != null)` when you meant `while (curr != null)`** — the first throws `NullPointerException` on an empty list, and stops one node early on a non-empty one. Choose deliberately: use `curr != null` to visit every node, `curr.next != null` to visit every node *that has a successor* (e.g. when you need pairs).
8. **Not handling the empty list or single-node list.** Always test n = 0 and n = 1. Most linked-list bugs live there.
9. **Non-static inner Node class** — hidden outer reference on every node. §7.7.
10. **Using `while (curr != head)` on a circular list** — zero iterations. Use `do-while`.
11. **Assuming `LinkedList.get(i)` is fast.** It's O(n). A `for (int i = 0; i < list.size(); i++) list.get(i)` loop over a `LinkedList` is **O(n²)**. Use the iterator or a for-each. This is a real production bug that shows up in profilers constantly.
12. **Modifying a list while iterating it** — `ConcurrentModificationException`, or silent corruption if you rolled your own.

## 7.10 Interview Perspective

Linked lists are pure **pointer-manipulation** tests. Unlike arrays, you can't fake your way through with library calls — you either understand references or you don't. That's exactly why interviewers like them.

**The four things they're evaluating:**

1. **Do you draw?** Draw four boxes. Redraw the arrows for each line. Candidates who draw succeed; candidates who don't lose track by line four. This is not optional advice.
2. **Do you handle n = 0 and n = 1 without being asked?** Say it upfront: *"Let me handle the empty list and single-node list first."* Then write the guards.
3. **Do you reach for a dummy head?** The moment a problem involves possibly-deleting-the-head, a dummy node eliminates the special case. Using it unprompted is a strong signal.
4. **Do you get O(1) space?** Most linked-list problems have an in-place pointer-rewiring solution. If you copied values into an `ArrayList`, expect *"now do it in O(1) space."*

**The five techniques, with the problems they unlock:**

**(1) Dummy head node.** Allocate a fake node before the real head. Now the real head has a predecessor, so *no* operation needs a special case.
```java
Node dummy = new Node(0);
dummy.next = head;
// ... work with dummy.next as "the head" ...
return dummy.next;    // the possibly-changed real head
```
Unlocks: *Remove Nth From End*, *Remove Elements*, *Merge Two Sorted Lists*, *Partition List*, *Remove Duplicates*.

**(2) Two pointers with a fixed offset.** Advance `fast` by `k`, then move both until `fast` hits the end. `slow` is now `k` from the end.
Unlocks: *Nth Node From End* in one pass.

**(3) Two pointers with different speeds (Floyd's tortoise & hare).** `slow` moves 1, `fast` moves 2.
```
   If they ever meet -> there is a CYCLE.
   When fast reaches the end -> slow is at the MIDDLE.
```
Unlocks: *Detect Cycle*, *Find Cycle Start*, *Find Middle*, *Palindrome List*, *Reorder List*.

**(4) Three-pointer walk (`prev`, `curr`, `next`).** In-place reversal. §7.5.
Unlocks: *Reverse List*, *Reverse Between Positions*, *Reverse in k-Groups*, *Swap Pairs*, *Add Two Numbers* (reversed digits).

**(5) Recursion.** A list *is* a node plus a smaller list — perfectly recursive.
Unlocks: *Merge Two Lists*, *Reverse*, *Flatten Multilevel List*. Just remember it's O(n) stack.

**The must-know question list** (each is a real, frequently-asked problem):
```
   Reverse a linked list                        -> three-pointer walk
   Detect a cycle                               -> Floyd's
   Find where the cycle starts                  -> Floyd's + reset one pointer to head
   Find the middle node                         -> slow/fast
   Merge two sorted lists                       -> dummy head + two pointers
   Remove the nth node from the end             -> offset two pointers
   Check if a list is a palindrome               -> find middle, reverse half, compare
   Intersection of two lists                    -> length difference, or two-pass switch
   Reverse in groups of k                       -> nested three-pointer walk
   LRU cache                                    -> HashMap + doubly linked list + sentinels
   Copy a list with random pointers             -> interleave nodes, or HashMap
   Add two numbers as lists                     -> carry propagation, dummy head
   Flatten a multilevel doubly linked list      -> stack or recursion
```

**What to say when asked "array or linked list?"**

> *"Almost always array — specifically `ArrayList` or `ArrayDeque`. Arrays win on random access, memory footprint, and cache locality, which in practice dominates. Linked lists win in one narrow but real case: when I already hold a reference to the node I want to modify. That's why LRU caches use a HashMap plus a doubly linked list. Also worth noting `LinkedList.get(i)` is O(n), so index-based loops over it are accidentally O(n²) — a bug I've seen in real code."*

## 7.11 Practice Problems

### Easy — Merge Two Sorted Linked Lists
Given the heads of two sorted linked lists, merge them into one sorted list and return its head. Splice the existing nodes; don't allocate new ones.
```
1 -> 2 -> 4
1 -> 3 -> 4
-> 1 -> 1 -> 2 -> 3 -> 4 -> 4
```

### Medium — Remove Nth Node From End of List
Given a list and an integer `n`, remove the nth node from the end and return the head. **One pass.**
```
1 -> 2 -> 3 -> 4 -> 5,  n = 2   ->  1 -> 2 -> 3 -> 5
1,                      n = 1   ->  (empty list)
```

### Hard — Detect a Cycle and Return Its Starting Node
Given a list that may contain a cycle, return the node where the cycle begins, or `null` if there is none. **O(1) space.**
```
3 -> 2 -> 0 -> -4
     ^          |
     +----------+
   -> returns the node with value 2
```

## 7.12 Solution Walkthrough

### Easy — Merge Two Sorted Lists

**The insight:** this is the `merge` step of merge sort (§6.6), except we relink pointers instead of copying into a buffer — so it's **O(1) space**.

**Why a dummy head?** Because the first node of the result could come from either list, and without a dummy you'd need a special case to initialise the head:
```java
// WITHOUT dummy — ugly
if (a.val <= b.val) { head = a; a = a.next; } else { head = b; b = b.next; }
Node curr = head;
// ... plus a null check on a and b before even that
```
With a dummy, there is no "first node" case at all. The loop handles everything.

```java
public Node mergeTwoLists(Node a, Node b) {
    Node dummy = new Node(0);       // fake node — never part of the answer
    Node curr = dummy;              // the "write cursor"

    while (a != null && b != null) {
        if (a.val <= b.val) {       // <= keeps it STABLE (a's nodes come first on ties)
            curr.next = a;
            a = a.next;
        } else {
            curr.next = b;
            b = b.next;
        }
        curr = curr.next;           // advance the write cursor
    }

    curr.next = (a != null) ? a : b;   // attach whichever list still has nodes

    return dummy.next;              // skip the dummy; return the real head
}
```

**Dry run on `a = 1->2->4`, `b = 1->3->4`:**

```
dummy -> null
curr = dummy
a -> [1a] -> [2] -> [4a]
b -> [1b] -> [3] -> [4b]

--- Iteration 1 ---
   a.val=1, b.val=1.  1 <= 1  ->  take from A (stability: A's node first)
   curr.next = [1a]
   dummy -> [1a]
   a -> [2] -> [4a]
   curr = [1a]

--- Iteration 2 ---
   a.val=2, b.val=1.  2 <= 1 is FALSE  ->  take from B
   curr.next = [1b]
   dummy -> [1a] -> [1b]
   b -> [3] -> [4b]
   curr = [1b]

--- Iteration 3 ---
   a.val=2, b.val=3.  2 <= 3  ->  take from A
   dummy -> [1a] -> [1b] -> [2]
   a -> [4a]
   curr = [2]

--- Iteration 4 ---
   a.val=4, b.val=3.  4 <= 3 FALSE  ->  take from B
   dummy -> [1a] -> [1b] -> [2] -> [3]
   b -> [4b]
   curr = [3]

--- Iteration 5 ---
   a.val=4, b.val=4.  4 <= 4  ->  take from A
   dummy -> [1a] -> [1b] -> [2] -> [3] -> [4a]
   a -> null
   curr = [4a]

--- Loop exits: a == null ---

   curr.next = b  ->  attaches [4b] AND everything after it in ONE assignment
   dummy -> [1a] -> [1b] -> [2] -> [3] -> [4a] -> [4b] -> null

return dummy.next = [1a]

FINAL: 1 -> 1 -> 2 -> 3 -> 4 -> 4    ✓
```

**Four details worth articulating:**

**1. `curr.next = (a != null) ? a : b;` — one line, not a loop.**
This is the linked-list advantage over arrays. In array merge sort we had to *copy* the remaining elements one by one. Here, attaching the rest of a list is a **single pointer assignment**, because the remaining nodes are already correctly linked to each other. O(1), not O(k). **Point this out** — it demonstrates you understand what linked lists are actually good at.

**2. `return dummy.next`, never `return dummy`.** The dummy is scaffolding. Returning it prepends a bogus 0 to the answer.

**3. `<=` preserves stability.** On ties, take from `a`. If these lists came from splitting a larger list, that maintains original relative order — exactly the same reasoning as merge sort's `<=` (§6.6).

**4. We allocated exactly one node** (the dummy), and it's discarded. The answer reuses all the original nodes. So **O(1) auxiliary space.** If an interviewer asks whether the dummy violates O(1), the answer is no — one node is a constant.

**Complexity:** **O(m + n) time** — each node is visited exactly once. **O(1) space.**

**The recursive version, for completeness:**
```java
public Node mergeTwoLists(Node a, Node b) {
    if (a == null) return b;
    if (b == null) return a;
    if (a.val <= b.val) { a.next = mergeTwoLists(a.next, b); return a; }
    else                { b.next = mergeTwoLists(a, b.next); return b; }
}
```
Beautiful — four lines, and it reads exactly like the definition. But **O(m + n) stack space**, which risks `StackOverflowError` on long lists. Present the iterative version as your answer and offer the recursive one as "more elegant but O(n) stack." Naming the trade-off is the point.

### Medium — Remove Nth Node From End (one pass)

**The naive two-pass approach:** walk once to count the length `L`, then walk again to node `L - n - 1` and unlink. Correct, O(n), but two passes. The interviewer wants one.

**The insight: a fixed gap between two pointers.**

If `fast` is exactly `n` nodes ahead of `slow`, then when `fast` reaches the end, `slow` is exactly `n` from the end. The gap does the counting for us — no length needed.

```
   List: 1 -> 2 -> 3 -> 4 -> 5 -> null,  n = 2

   Set up a gap of n = 2:
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
     ^              ^
   slow            fast          gap = 2

   Now advance BOTH until fast hits null:
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
             ^              ^
            slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                    ^              ^
                   slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                           ^              ^
                          slow           fast

   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                                  ^              ^
                                 slow           fast = null -> STOP
                                 
   Hmm — slow is at [4], but we want to DELETE [4] (2nd from end).
   To delete a node we need its PREDECESSOR. So we need slow to stop at [3].
   
   FIX: start slow at dummy and use a gap of n+1, OR equivalently
        advance fast n+1 times from dummy. Let's redo it properly.
```

Let me set it up correctly — and note that **getting this offset right is the whole problem**:

```java
public Node removeNthFromEnd(Node head, int n) {
    Node dummy = new Node(0);
    dummy.next = head;

    Node fast = dummy;
    Node slow = dummy;

    // Advance fast by n + 1 steps, so the gap between slow and fast is n + 1.
    for (int i = 0; i <= n; i++) {
        if (fast == null) return head;   // n is larger than the list length
        fast = fast.next;
    }

    // Move both until fast falls off the end.
    while (fast != null) {
        fast = fast.next;
        slow = slow.next;
    }

    // slow is now the PREDECESSOR of the node to delete.
    Node target = slow.next;
    slow.next = target.next;
    target.next = null;                  // help GC

    return dummy.next;
}
```

**Corrected dry run: `1 -> 2 -> 3 -> 4 -> 5`, n = 2.**

```
dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null

--- Setup: advance fast n+1 = 3 times from dummy ---
   i=0: fast = dummy.next = [1]
   i=1: fast = [2]
   i=2: fast = [3]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
     ^                     ^
   slow                   fast          gap = 3 = n+1

--- Advance both until fast == null ---
   Step 1: fast = [4], slow = [1]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
             ^                     ^
            slow                  fast

   Step 2: fast = [5], slow = [2]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                    ^                     ^
                   slow                  fast

   Step 3: fast = null, slow = [3]
   
   dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> null
                           ^                        ^
                          slow                    fast=null

--- fast is null -> stop. slow = [3]. ---

   target = slow.next = [4]        <-- the 2nd node from the end. CORRECT.
   slow.next = target.next = [5]
   
   dummy -> [1] -> [2] -> [3] --------> [5] -> null
   
   target.next = null   (detach [4] fully)

return dummy.next = [1]

FINAL: 1 -> 2 -> 3 -> 5    ✓
```

**Now the edge case that breaks naive solutions: `head = [1]`, n = 1** (delete the only node).

```
dummy -> [1] -> null

Setup: advance fast n+1 = 2 times from dummy:
   i=0: fast = [1]
   i=1: fast = null
   
   dummy -> [1] -> null
     ^              ^
   slow           fast = null

Loop doesn't execute (fast is already null). slow = dummy.

   target = slow.next = [1]
   slow.next = target.next = null
   
   dummy -> null

return dummy.next = null    ✓  correct: the list is now empty
```

**This is exactly why the dummy node is essential.** Without it, deleting the head requires a special branch (`if (target == head) return head.next;`). With it, `slow` can legitimately *be* the dummy, and the same two lines of unlinking code work. **State this out loud:** *"I'll use a dummy head so that deleting the actual head needs no special case."*

**Three details:**

**1. Why `n + 1` and not `n`?** Because to delete a node you need its **predecessor** (this is a singly linked list — §7.8). A gap of `n` puts `slow` *on* the target; a gap of `n + 1` puts it one before. Get this wrong and you delete the neighbour. **Verify the offset with the smallest case (`n = 1`, single node) — that's how you catch it in an interview.**

**2. `for (int i = 0; i <= n; i++)`** — note `<=`, giving `n + 1` iterations. Equivalent to `for (i = 0; i < n + 1; i++)`. Either is fine; be deliberate about which.

**3. `if (fast == null) return head;`** — defensive guard for `n > length`. The problem usually guarantees valid `n`, but volunteering the check shows you think about malformed input. In production you'd throw `IllegalArgumentException` instead of silently doing nothing — say that too.

**Complexity:** **O(L) time** — `fast` traverses the list once; `slow` traverses part of it. One pass. **O(1) space** — two pointers plus one dummy node.

### Hard — Detect a Cycle and Find Its Start (Floyd's Algorithm)

Two parts. Part 1 is well known; Part 2 has a genuinely surprising proof that interviewers love.

**Part 1 — detection. Why do slow and fast necessarily meet?**

`slow` moves 1 step per iteration; `fast` moves 2.

```
   NO CYCLE:  fast reaches null and we exit. Simple.

   CYCLE:     Once BOTH pointers are inside the loop, consider the
              GAP between them (measured forward, along the cycle).
              
              Each iteration:  slow advances 1, fast advances 2
                            -> fast gains exactly 1 on slow
                            -> the gap SHRINKS BY EXACTLY 1 each iteration
              
              A gap that decreases by exactly 1 must eventually reach 0.
              It can never "jump over" zero, because the step is exactly 1.
              
              -> They MUST meet.  Guaranteed, in at most (cycle length) iterations.
```

**This is why the speeds must be 1 and 2.** With speeds 1 and 3, the gap shrinks by 2 each step and could skip from +1 to −1 without ever being 0 — for cycles of even length, they may never meet. **"Why 2x and not 3x?" is a real interview follow-up.** The answer: a relative speed of exactly 1 guarantees the gap hits zero.

**Part 2 — finding the start. The result that looks like magic.**

Set up the geometry:

```
   head                    cycle start (S)
    |                            |
    v                            v
   [A]--->[B]--->...--->[C]--->[ S ]--->[X]--->[Y]
                                 ^               |
                                 |               v
                                [W]<---[V]<-----[Z]

   Let:
     F = distance from head to the cycle start S
     a = distance from S to the MEETING POINT M (going forward around the cycle)
     C = total cycle length

   +----------- F -----------+---- a ----+
   head                      S           M
                             |           |
                             +--- C - a -+  (rest of the way around)
```

**Now the algebra.** Say they meet after `k` iterations. Then:
```
   slow has travelled:  k        steps
   fast has travelled:  2k       steps
```

`slow` walked `F` to reach `S`, then `a` more to reach `M`. It may have looped some whole number of times too, but for the *first* meeting it won't have:
```
   k = F + a
```

`fast` walked `F` to reach `S`, then went around the cycle some number of full times `m`, then `a` more:
```
   2k = F + m·C + a
```

Substitute `k = F + a`:
```
   2(F + a) = F + m·C + a
   2F + 2a  = F + m·C + a
   F + a    = m·C
   F        = m·C - a
   F        = (m - 1)·C + (C - a)
```

**Read that last line.** `C - a` is the distance from the meeting point `M` forward around the cycle back to `S`. And `(m-1)·C` is just some whole number of extra laps, which changes nothing about where you end up.

> **So: the distance from the head to the cycle start equals the distance from the meeting point, going forward, back to the cycle start (plus whole laps).**

Therefore: **put one pointer back at `head`, leave the other at the meeting point, and advance both one step at a time. They will meet exactly at the cycle start.**

```
   Verify with a concrete example:
   
   List: 3 -> 2 -> 0 -> -4, with -4 pointing back to 2
   
   Indices: [0]=3, [1]=2, [2]=0, [3]=-4.  Cycle start = index 1.
   F = 1 (head to index 1),  C = 3 (nodes 1,2,3)
   
   slow/fast trace:
     start:  slow=[0], fast=[0]
     iter 1: slow=[1], fast=[2]
     iter 2: slow=[2], fast=[1]      (fast went [2]->[3]->[1])
     iter 3: slow=[3], fast=[3]      (fast went [1]->[2]->[3])   MEET at index 3
   
   So M = index 3, a = distance from S(index 1) to M(index 3) = 2
   Check: F = 1,  C - a = 3 - 2 = 1.   F == C - a.  ✓
   
   Phase 2: p1 = head = [0], p2 = M = [3]
     step 1: p1 = [1], p2 = [1]     (index 3's next IS index 1)
     They meet at index 1 = the cycle start.  ✓  Value 2.
```

```java
public Node detectCycleStart(Node head) {
    if (head == null || head.next == null) return null;

    // PHASE 1: detect whether a cycle exists, and find the meeting point.
    Node slow = head, fast = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;              // 1 step
        fast = fast.next.next;         // 2 steps
        if (slow == fast) break;       // met -> cycle exists
    }

    // If fast ran off the end, there is no cycle.
    if (fast == null || fast.next == null) return null;

    // PHASE 2: reset one pointer to head; advance both at the SAME speed.
    slow = head;
    while (slow != fast) {
        slow = slow.next;
        fast = fast.next;              // NOTE: 1 step now, not 2
    }
    return slow;                       // == the cycle start
}
```

**Four details that matter:**

**1. `while (fast != null && fast.next != null)` — both checks, in this order.**
`fast` advances two steps, so we must confirm *both* hops are legal before taking them. If `fast.next` were null and we wrote `fast.next.next`, that's a `NullPointerException`. And `fast != null` must come first, or `fast.next` itself throws. **Short-circuit `&&` order is load-bearing** — the same pattern as insertion sort's `j >= 0 &&` (§6.5) and binary search's bounds checks.

**2. `if (slow == fast)` uses reference equality, deliberately.**
We're asking *"are these the same node?"*, not *"do they hold equal values?"* A list can legitimately contain duplicate values without a cycle. `==` on references is exactly right here — one of the few places in Java where `==` is the correct comparison (contrast with strings, §3.3).

**3. Checking `slow == fast` AFTER moving, not before.**
Both start at `head`, so checking before the first move would report a cycle immediately on every list. Move first, then compare.

**4. In Phase 2, `fast` moves ONE step, not two.**
This trips people up because the variable is named `fast`. After Phase 1, `fast` is just "the pointer sitting at the meeting point." The proof requires both pointers to move at **equal** speed so that they cover `F` and `C - a` respectively in the same number of steps. Leave it at 2 and it overshoots. **A well-named refactor (`meetingPoint` instead of `fast`) would prevent this bug** — worth saying, since interviewers appreciate candidates who think about readability.

**Complexity.**
- **Phase 1:** `slow` travels at most `F + C` steps before the meeting (it enters the cycle after `F`, then meets within one lap). → O(n).
- **Phase 2:** exactly `F` steps. → O(n).
- **Total: O(n) time, O(1) space.**

**The alternative, and why Floyd's is better.** A `HashSet<Node>` of visited nodes detects the cycle in O(n) time — but **O(n) space**. The first node you see twice *is* the cycle start, which is arguably simpler. **Present both:** *"A HashSet gives O(n) time and O(n) space and is very simple. Floyd's gives O(n) time and O(1) space, at the cost of a non-obvious proof. If space matters, Floyd's; if readability matters and n is small, the HashSet."* Showing that you know both, and can articulate when each is preferable, is the complete answer.

**Where Floyd's turns up beyond linked lists.** The algorithm is really about **cycle detection in any functional graph** — any sequence where `xₙ₊₁ = f(xₙ)`. That includes:
- *Find the Duplicate Number* — treat `nums[i]` as a pointer to index `nums[i]`; the duplicate creates a cycle. O(n) time, O(1) space, without modifying the array.
- *Happy Number* — the digit-square-sum sequence either reaches 1 or cycles.
- Detecting cycles in pseudorandom number generators, and in Pollard's rho factorisation algorithm.

**Recognising that "sequence defined by repeated function application" means "Floyd's applies"** is a genuinely transferable insight, and it's the kind of connection that makes an interviewer sit up.

---
---
