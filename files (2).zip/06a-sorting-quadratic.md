*(Part of **The Complete DSA Course in Java**. Modules are split into separate files so each one loads quickly.)*

---

# MODULE 6 — Sorting

## 6.1 Intuition — why sorting is the most important algorithm you'll learn

Sorting is not really about producing ordered data. It's about **creating structure you can exploit.**

Look at what sortedness buys you:
```
   Unsorted array                    Sorted array
   --------------                    ------------
   search: O(n)                      search: O(log n)      <- binary search
   find duplicates: O(n) w/ hashing  find duplicates: O(n)  <- adjacent comparison
   find median: O(n) (quickselect)   find median: O(1)      <- middle index
   find kth smallest: O(n)           find kth smallest: O(1)
   two-sum: O(n) w/ hashing          two-sum: O(n) w/ two pointers, O(1) space
   group equal items: O(n) w/ map    group equal items: O(n) in-place
```

Sorting costs O(n log n) **once**, and then a dozen problems become easy. That's why *"sort it first"* is the single most productive first thought in interview problem-solving. If you're stuck, ask: **"would sorting help?"** It often does.

**And there's a deeper reason to study sorting.** Every major algorithmic paradigm shows up here in miniature:
```
   Bubble / Selection / Insertion  ->  incremental construction, invariants
   Merge sort                      ->  divide and conquer
   Quick sort                      ->  partitioning, randomisation
   Heap sort                       ->  a data structure doing the work
   Counting / Radix                ->  trading space for time, non-comparison tricks
```
Learning eight sorts isn't about memorising eight sorts. It's about learning five ways to think.

## 6.2 Mental Model — the classification that organises everything

Before any code, learn these four axes. Interviewers ask about all of them.

**Axis 1 — Comparison vs Non-comparison**
```
   Comparison sorts: only ever ask "is a < b?"
       Bubble, Selection, Insertion, Merge, Quick, Heap
       PROVABLE LOWER BOUND: Ω(n log n). Cannot be beaten. (Proof in §6.12.)

   Non-comparison sorts: exploit the structure of the values themselves
       Counting, Radix, Bucket
       Can achieve O(n) — but only under restrictions on the input.
```

**Axis 2 — Stable vs Unstable**

A sort is **stable** if equal elements keep their original relative order.

```
   Input (sort by grade only):
       (Amit, B)  (Bina, A)  (Chetan, B)  (Divya, A)

   STABLE result:    (Bina,A) (Divya,A) (Amit,B) (Chetan,B)
                              ^^^^^^^ Bina still before Divya, Amit still before Chetan

   UNSTABLE result:  (Divya,A) (Bina,A) (Chetan,B) (Amit,B)
                     ^^^^^^^^ order among equals was scrambled
```

**Why stability matters in the real world:** it lets you sort by multiple keys sequentially. Sort by name, then stably sort by department — and within each department, names remain sorted. That's how spreadsheet multi-column sorting works. It's also why `Collections.sort` (TimSort) is guaranteed stable while `Arrays.sort(int[])` (dual-pivot quicksort) is not — **and that distinction is a favourite Java interview question.** Primitives have no identity beyond their value, so stability is meaningless for them; objects do, so stability is guaranteed.

**Axis 3 — In-place vs Out-of-place**
```
   In-place:      O(1) or O(log n) extra space.  Bubble, Selection, Insertion, Heap, Quick*
   Out-of-place:  O(n) extra space.              Merge, Counting, Radix
   
   * Quicksort is "in-place" for the partitioning but uses O(log n) stack for recursion.
```

**Axis 4 — Adaptive vs Non-adaptive**
```
   Adaptive:     runs faster on partially-sorted input.   Insertion (O(n) on sorted!), Bubble w/ flag, TimSort
   Non-adaptive: same cost regardless.                    Selection, Merge, Heap
```
Real data is often nearly sorted. This is exactly why the JDK uses TimSort (adaptive) for objects.

**The summary table — memorise this. It is asked directly.**

| Algorithm | Best | Average | Worst | Space | Stable | Adaptive | In-place |
|---|---|---|---|---|---|---|---|
| Bubble | O(n) | O(n²) | O(n²) | O(1) | ✅ | ✅ (with flag) | ✅ |
| Selection | O(n²) | O(n²) | O(n²) | O(1) | ❌ | ❌ | ✅ |
| Insertion | **O(n)** | O(n²) | O(n²) | O(1) | ✅ | ✅ | ✅ |
| Merge | O(n log n) | O(n log n) | **O(n log n)** | O(n) | ✅ | ❌ | ❌ |
| Quick | O(n log n) | O(n log n) | **O(n²)** | O(log n) | ❌ | ❌ | ✅ |
| Heap | O(n log n) | O(n log n) | **O(n log n)** | **O(1)** | ❌ | ❌ | ✅ |
| Counting | O(n+k) | O(n+k) | O(n+k) | O(n+k) | ✅ | ❌ | ❌ |
| Radix | O(d(n+k)) | O(d(n+k)) | O(d(n+k)) | O(n+k) | ✅ | ❌ | ❌ |

**The three cells that matter most in interviews:**
- **Insertion sort's O(n) best case** — the only comparison sort here that is linear on sorted input.
- **Quicksort's O(n²) worst case** — and why we still use it (better constants, cache locality, in-place).
- **Heap sort's O(1) space with guaranteed O(n log n)** — the only algorithm with both. Yet rarely used in practice, because its cache behaviour is poor.

---

## 6.3 Bubble Sort

### Intuition

Repeatedly walk through the array comparing **adjacent pairs**, swapping any that are out of order. Large values "bubble" to the right like air rising through water.

**The key invariant:** after pass `k`, the largest `k` elements are correctly placed at the end and never move again.

### Visual Explanation — every pass on `[5, 4, 3, 2]`

```
INITIAL:  5  4  3  2

=== PASS 1 (compare adjacent pairs, j = 0..2) ===
j=0: compare 5,4  ->  5 > 4, SWAP
     4  5  3  2
     ^^^^
j=1: compare 5,3  ->  5 > 3, SWAP
     4  3  5  2
        ^^^^
j=2: compare 5,2  ->  5 > 2, SWAP
     4  3  2  5
           ^^^^
PASS 1 DONE:  4  3  2 | 5
                       ^^^ 5 is HOME. Largest element found. Never touched again.

=== PASS 2 (j = 0..1, we skip the sorted tail) ===
j=0: compare 4,3  ->  4 > 3, SWAP
     3  4  2 | 5
     ^^^^
j=1: compare 4,2  ->  4 > 2, SWAP
     3  2  4 | 5
        ^^^^
PASS 2 DONE:  3  2 | 4  5
                     ^^^^^^ two largest are HOME

=== PASS 3 (j = 0 only) ===
j=0: compare 3,2  ->  3 > 2, SWAP
     2  3 | 4  5
     ^^^^
PASS 3 DONE:  2 | 3  4  5

=== PASS 4: only one element left, trivially sorted ===

FINAL:  2  3  4  5    ✓

Total comparisons: 3 + 2 + 1 = 6 = n(n-1)/2
Total swaps:       6 (worst case — the input was fully reversed)
```

**Notice the shrinking boundary.** Pass 1 examines indices 0–3, pass 2 examines 0–2, pass 3 examines 0–1. That's why the inner loop bound is `n - 1 - i`:

```
   The array during sorting:

   +--------------------------------+----------------+
   |     UNSORTED (still working)   | SORTED, FINAL  |
   +--------------------------------+----------------+
    0                     n-1-i     n-i          n-1
                                    ^
                       the boundary marches LEFT each pass
```

### Java Implementation

```java
/** Bubble sort with early-exit optimisation. */
public static void bubbleSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    for (int i = 0; i < n - 1; i++) {          // n-1 passes suffice
        boolean swapped = false;               // adaptivity flag

        for (int j = 0; j < n - 1 - i; j++) {  // shrinking boundary
            if (arr[j] > arr[j + 1]) {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
                swapped = true;
            }
        }

        if (!swapped) return;                  // already sorted -> stop early
    }
}
```

### Line-by-Line

**`for (int i = 0; i < n - 1; i++)`** — `n - 1` passes, not `n`. After placing `n-1` elements, the last one is necessarily in place (there's nowhere else for it to be). One free pass saved.

**`for (int j = 0; j < n - 1 - i; j++)`** — the `- 1` prevents `arr[j+1]` from going out of bounds; the `- i` skips the already-sorted tail. **Both subtractions are load-bearing.** Omit `- i` and it still sorts correctly but does 2× the work.

**`if (arr[j] > arr[j + 1])`** — strict `>`. Using `>=` would swap **equal** elements, destroying stability. **This single character is the difference between a stable and unstable sort.** Interviewers ask "how would you make bubble sort unstable?" — the answer is "change `>` to `>=`."

**`boolean swapped` and `if (!swapped) return;`** — the adaptivity. If a full pass makes zero swaps, the array is sorted by definition (no adjacent pair is out of order → the whole thing is ordered). This gives bubble sort an **O(n) best case** on already-sorted input: one pass, no swaps, return. Without this flag, bubble sort is O(n²) even on sorted input. **Always include the flag** — it's free and it's what the interviewer is checking for.

### Complexity
- **Worst / Average: O(n²)** — `n(n-1)/2 ≈ n²/2` comparisons.
- **Best: O(n)** — one pass with the flag.
- **Space: O(1)**, **Stable: yes**, **In-place: yes.**

### Interview Perspective
Bubble sort is **never** the right answer to "sort this." Its only interview roles:
1. As the brute force you mention and immediately discard: *"bubble sort would be O(n²); let me do better."*
2. To test whether you know the early-exit flag and the stability point.
3. Its one genuine virtue: **it detects sortedness in O(n)** and requires no extra memory. Essentially never useful in practice.

---

## 6.4 Selection Sort

### Intuition

Find the **minimum** of the unsorted region and swap it into the front. Repeat.

Where bubble sort does many small swaps, selection sort does **many comparisons but exactly `n-1` swaps** — one per pass, no matter what.

### Visual Explanation — every pass on `[64, 25, 12, 22, 11]`

```
INITIAL:  64  25  12  22  11
          ^^ all unsorted

=== PASS i=0: scan [0..4] for the minimum ===
   j=1: 25 < 64  -> minIdx = 1
   j=2: 12 < 25  -> minIdx = 2
   j=3: 22 > 12  -> no change
   j=4: 11 < 12  -> minIdx = 4
   minimum is 11 at index 4.  SWAP arr[0] <-> arr[4]:

   11 | 25  12  22  64
   ^^   ^^^^^^^^^^^^^^  sorted | unsorted

=== PASS i=1: scan [1..4] for the minimum ===
   j=2: 12 < 25  -> minIdx = 2
   j=3: 22 > 12  -> no change
   j=4: 64 > 12  -> no change
   minimum is 12 at index 2.  SWAP arr[1] <-> arr[2]:

   11  12 | 22  25  64
   ^^^^^^   ^^^^^^^^^^

=== PASS i=2: scan [2..4] ===
   j=3: 25 > 22.  j=4: 64 > 22.  minIdx stays 2.
   minimum is already at index 2. SWAP arr[2] <-> arr[2] (no-op):

   11  12  22 | 25  64

=== PASS i=3: scan [3..4] ===
   j=4: 64 > 25. minIdx stays 3. No-op swap.

   11  12  22  25 | 64

=== Done: last element is necessarily in place ===

FINAL:  11  12  22  25  64   ✓

Comparisons: 4 + 3 + 2 + 1 = 10 = n(n-1)/2   (ALWAYS, regardless of input)
Swaps:       4 = n - 1                        (ALWAYS)
```

### Java Implementation

```java
/** Selection sort. Minimises SWAPS at the cost of always doing n²/2 comparisons. */
public static void selectionSort(int[] arr) {
    if (arr == null || arr.length < 2) return;
    int n = arr.length;

    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;                        // assume the first unsorted element is smallest
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;                    // track the INDEX, not the value
            }
        }
        if (minIdx != i) {                     // skip pointless self-swaps
            int tmp = arr[i];
            arr[i] = arr[minIdx];
            arr[minIdx] = tmp;
        }
    }
}
```

### Line-by-Line

**`int minIdx = i;`** — track the **index**, not the value. If you tracked only the minimum value you couldn't swap it, because you wouldn't know where it lives. Beginners write `int minVal = arr[i]` and then get stuck.

**`for (int j = i + 1; j < n; j++)`** — start at `i + 1`, because `arr[i]` is already our candidate. Scan to the very end (`j < n`), because the minimum could be anywhere in the unsorted region. **Contrast with bubble sort, whose inner loop *shrinks* from the right; selection sort's inner loop shrinks from the *left*.**

**`if (minIdx != i)`** — a micro-optimisation, but it also documents intent. Swapping an element with itself is harmless but wasteful, and on an already-sorted array this check reduces swaps from `n-1` to `0`.

**Why is selection sort NOT stable?** The long-distance swap is the culprit:
```
   [ (4,a)  (4,b)  (1,c) ]     two 4s: 'a' before 'b'
   
   Pass 0: minimum is (1,c) at index 2. Swap index 0 and 2:
   [ (1,c)  (4,b)  (4,a) ]     'b' is now before 'a'  ->  ORDER BROKEN
```
One swap jumped over `(4,b)` and reversed the two equal elements. **This is why selection sort is unstable, and stating this example is exactly how to answer "why is selection sort unstable?"**

### Complexity
- **All cases: O(n²)** — the inner scan always runs to the end. **Not adaptive at all**; sorted input costs the same as reversed input.
- **Swaps: exactly O(n)** — its one genuine advantage.
- **Space: O(1)**, **Stable: no**, **In-place: yes.**

### Interview Perspective
The one situation where selection sort is genuinely the right choice: **when writes are far more expensive than reads.** Think EEPROM/flash memory with limited write cycles, or sorting records so large that moving them dominates. Selection sort does the theoretical minimum number of moves (n−1). Mentioning this specific niche shows you understand *why* algorithms exist rather than just what they do.

Also: selection sort is the conceptual ancestor of **heap sort**. Heap sort is "selection sort, but find the minimum in O(log n) instead of O(n) by using a heap." Understanding that link makes heap sort trivial to remember.

---

## 6.5 Insertion Sort

### Intuition

**How you actually sort a hand of playing cards.**

Hold a sorted hand on the left. Pick up the next card. Slide it leftward past every card larger than it, until it lands in the right spot. Repeat.

```
   Sorted hand: [3, 7, 9]      new card: 5
   
   Compare 5 with 9: 9 > 5, slide 9 right   [3, 7, _, 9]
   Compare 5 with 7: 7 > 5, slide 7 right   [3, _, 7, 9]
   Compare 5 with 3: 3 < 5, STOP            [3, 5, 7, 9]  <- insert here
```

This is the most *natural* sorting algorithm — you already know it — and it's genuinely useful in production.

### Visual Explanation — every pass on `[12, 11, 13, 5, 6]`

```
INITIAL:  12 | 11  13   5   6
          ^^^ a 1-element region is trivially sorted

=== i=1, key = 11 ===
   Compare with 12: 12 > 11  ->  shift 12 right
        12 |  _  13  5  6      (position 1 is now a hole)
        _  12 |  13  5  6
   j reaches -1  ->  insert key at index 0
   
   11  12 | 13   5   6

=== i=2, key = 13 ===
   Compare with 12: 12 < 13  ->  no shift needed, key is already in place
   
   11  12  13 |  5   6

=== i=3, key = 5 ===
   Compare with 13: 13 > 5  -> shift          11  12   _  13 |  6
   Compare with 12: 12 > 5  -> shift          11   _  12  13 |  6
   Compare with 11: 11 > 5  -> shift           _  11  12  13 |  6
   j reaches -1  ->  insert 5 at index 0
   
    5  11  12  13 |  6
   ^^^ 5 travelled 3 positions left. THREE shifts for ONE element.

=== i=4, key = 6 ===
   Compare with 13: 13 > 6  -> shift           5  11  12   _  13
   Compare with 12: 12 > 6  -> shift           5  11   _  12  13
   Compare with 11: 11 > 6  -> shift           5   _  11  12  13
   Compare with  5:  5 < 6  -> STOP            insert 6 at index 1
   
    5   6  11  12  13    ✓

FINAL:  5  6  11  12  13
```

**Now the crucial contrast — insertion sort on ALREADY SORTED input `[1,2,3,4,5]`:**

```
   i=1, key=2: compare with 1.  1 < 2  ->  STOP IMMEDIATELY. Zero shifts.
   i=2, key=3: compare with 2.  2 < 3  ->  STOP. Zero shifts.
   i=3, key=4: compare with 3.  3 < 4  ->  STOP. Zero shifts.
   i=4, key=5: compare with 4.  4 < 5  ->  STOP. Zero shifts.
   
   Total: 4 comparisons, 0 shifts.  ->  O(n)
```

**That is the O(n) best case, and it's why insertion sort matters.** Compare with selection sort, which would still do 10 comparisons on the same input. Insertion sort *notices* that the data is sorted; selection sort cannot.

### Java Implementation

```java
/** Insertion sort. O(n) on nearly-sorted data. Stable. The best O(n²) sort. */
public static void insertionSort(int[] arr) {
    if (arr == null || arr.length < 2) return;

    for (int i = 1; i < arr.length; i++) {     // start at 1: arr[0] alone is sorted
        int key = arr[i];                      // SAVE the element being inserted
        int j = i - 1;

        // Shift every element greater than key one slot to the right
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];               // shift right (NOT a swap — one write)
            j--;
        }
        arr[j + 1] = key;                      // drop key into the hole
    }
}

/** Insertion sort on a subrange — used by hybrid sorts like TimSort. */
public static void insertionSort(int[] arr, int lo, int hi) {
    for (int i = lo + 1; i <= hi; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= lo && arr[j] > key) { arr[j + 1] = arr[j]; j--; }
        arr[j + 1] = key;
    }
}
```

### Line-by-Line

**`int key = arr[i];`** — **you must save the value first.** The shifting loop is about to overwrite `arr[i]`. Forget this line and you'll duplicate an element and lose another. This is the #1 bug in insertion sort.

**`while (j >= 0 && arr[j] > key)`** — two conditions, and **the order matters.** `j >= 0` must come first: Java's `&&` short-circuits, so when `j` reaches `-1` we never evaluate `arr[-1]`. Reverse the order and you get `ArrayIndexOutOfBoundsException` on every element that belongs at index 0. **Short-circuit evaluation is doing real work here** — point this out in an interview.

**`arr[j + 1] = arr[j];` — a SHIFT, not a swap.**
```
   Swap:  3 writes (tmp = a; a = b; b = tmp)
   Shift: 1 write  (a = b)
```
Insertion sort does one write per displaced element; bubble sort does three per swap. Same asymptotic complexity, **~3× better constant factor.** This is precisely why insertion sort is the fastest of the three O(n²) sorts in practice, and why real libraries use it (not bubble sort) for small arrays.

**`arr[j + 1] = key;` — why `j + 1`?** The `while` loop exits when `arr[j] <= key` (or `j < 0`). At that moment `arr[j]` should stay put, and the hole is at `j + 1`. Off-by-one here is the second most common bug; trace the `[12, 11]` case by hand if it feels unclear.

**`arr[j] > key`, strictly greater** — again the stability guarantee. With `>=`, an equal element would be shifted past, reversing equal pairs.

### Complexity

Let's derive it honestly, because the derivation is the interview answer.

**Worst case (reverse-sorted input):** element `i` must travel all the way to index 0, requiring `i` shifts.
```
   Total shifts = 1 + 2 + 3 + ... + (n-1) = n(n-1)/2 = O(n²)
```
**Best case (sorted input):** the `while` condition fails immediately every time.
```
   Total = (n-1) comparisons, 0 shifts = O(n)
```
**Average case:** each element travels about half the distance → `n²/4` → still **O(n²)**.

**The property that makes it valuable: for an array where each element is at most `k` positions from its final place, insertion sort runs in O(n·k).** For nearly-sorted data (`k` small and constant), that's **effectively O(n)** — faster than merge sort's O(n log n). This is a real, exploitable fact.

- **Space: O(1)**, **Stable: yes**, **Adaptive: yes**, **In-place: yes.**

### Interview Perspective

**Insertion sort is the O(n²) sort you should actually know cold**, because it appears inside real production sorts:

- **`java.util.Arrays.sort(int[])`** uses dual-pivot quicksort, but **switches to insertion sort for subarrays under 47 elements.**
- **`java.util.Arrays.sort(Object[])`** uses TimSort, which **builds "runs" using binary insertion sort** on segments under 32 elements, then merges them.
- **C++'s `std::sort`** (introsort) switches to insertion sort below ~16 elements.

**Why do all of these switch?** Because for small `n`, O(n²) with tiny constants beats O(n log n) with recursion overhead, cache misses, and function-call cost. `n²/4 < n log n × C` when `n` is small. **Explaining this in an interview — that real sorts are hybrids, and why — is a genuinely strong answer to "which sort would you use?"**

The other must-know use: **insertion sort is the natural choice for an online algorithm** — one where data arrives one element at a time and you must maintain a sorted structure. Merge sort and quicksort need the whole array upfront; insertion sort doesn't.

---
